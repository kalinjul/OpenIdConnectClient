#import <Foundation/NSArray.h>
#import <Foundation/NSDictionary.h>
#import <Foundation/NSError.h>
#import <Foundation/NSObject.h>
#import <Foundation/NSSet.h>
#import <Foundation/NSString.h>
#import <Foundation/NSValue.h>

@class AccessTokenResponse, AccessTokenResponseCompanion, AuthCodeRequest, AuthCodeRequestCompanion, AuthCodeResult, AuthCodeResultCompanion, CodeAuthFlow, CodeChallengeMethod, EndSessionRequest, EndSessionRequestCompanion, Endpoints, EndpointsCompanion, IdToken, Jwt, JwtCompanion, JwtHeader, JwtHeaderCompanion, JwtParser, OICCFlowWrapper<__covariant T>, OICCHttpException, OICCKotlinAbstractCoroutineContextElement, OICCKotlinAbstractCoroutineContextKey<B, E>, OICCKotlinArray<T>, OICCKotlinByteArray, OICCKotlinByteIterator, OICCKotlinCancellationException, OICCKotlinEnum<E>, OICCKotlinEnumCompanion, OICCKotlinException, OICCKotlinIllegalStateException, OICCKotlinInstant, OICCKotlinInstantCompanion, OICCKotlinKTypeProjection, OICCKotlinKTypeProjectionCompanion, OICCKotlinKVariance, OICCKotlinNothing, OICCKotlinRuntimeException, OICCKotlinThrowable, OICCKotlinUnit, OICCKotlinx_coroutines_coreCoroutineDispatcher, OICCKotlinx_coroutines_coreCoroutineDispatcherKey, OICCKotlinx_io_coreBuffer, OICCKotlinx_serialization_coreSerialKind, OICCKotlinx_serialization_coreSerializersModule, OICCKotlinx_serialization_jsonClassDiscriminatorMode, OICCKotlinx_serialization_jsonJson, OICCKotlinx_serialization_jsonJsonConfiguration, OICCKotlinx_serialization_jsonJsonDefault, OICCKotlinx_serialization_jsonJsonElement, OICCKotlinx_serialization_jsonJsonElementCompanion, OICCKtor_client_coreHttpClient, OICCKtor_client_coreHttpClientCall, OICCKtor_client_coreHttpClientCallCompanion, OICCKtor_client_coreHttpClientConfig<T>, OICCKtor_client_coreHttpClientEngineConfig, OICCKtor_client_coreHttpReceivePipeline, OICCKtor_client_coreHttpReceivePipelinePhases, OICCKtor_client_coreHttpRequestBuilder, OICCKtor_client_coreHttpRequestBuilderCompanion, OICCKtor_client_coreHttpRequestData, OICCKtor_client_coreHttpRequestPipeline, OICCKtor_client_coreHttpRequestPipelinePhases, OICCKtor_client_coreHttpResponse, OICCKtor_client_coreHttpResponseContainer, OICCKtor_client_coreHttpResponseData, OICCKtor_client_coreHttpResponsePipeline, OICCKtor_client_coreHttpResponsePipelinePhases, OICCKtor_client_coreHttpSendPipeline, OICCKtor_client_coreHttpSendPipelinePhases, OICCKtor_client_coreHttpStatement, OICCKtor_client_coreProxyConfig, OICCKtor_eventsEventDefinition<T>, OICCKtor_eventsEvents, OICCKtor_httpContentType, OICCKtor_httpContentTypeCompanion, OICCKtor_httpHeaderValueParam, OICCKtor_httpHeaderValueWithParameters, OICCKtor_httpHeaderValueWithParametersCompanion, OICCKtor_httpHeadersBuilder, OICCKtor_httpHttpMethod, OICCKtor_httpHttpMethodCompanion, OICCKtor_httpHttpProtocolVersion, OICCKtor_httpHttpProtocolVersionCompanion, OICCKtor_httpHttpStatusCode, OICCKtor_httpHttpStatusCodeCompanion, OICCKtor_httpOutgoingContent, OICCKtor_httpURLBuilder, OICCKtor_httpURLBuilderCompanion, OICCKtor_httpURLProtocol, OICCKtor_httpURLProtocolCompanion, OICCKtor_httpUrl, OICCKtor_httpUrlCompanion, OICCKtor_utilsAttributeKey<T>, OICCKtor_utilsGMTDate, OICCKtor_utilsGMTDateCompanion, OICCKtor_utilsMonth, OICCKtor_utilsMonthCompanion, OICCKtor_utilsPipeline<TSubject, TContext>, OICCKtor_utilsPipelinePhase, OICCKtor_utilsStringValuesBuilderImpl, OICCKtor_utilsTypeInfo, OICCKtor_utilsWeekDay, OICCKtor_utilsWeekDayCompanion, OICCOauthTokens, OICCOidc_preferencesPreferencesFactory, OICCOidc_preferencesPreferencesSingletonFactory, OICCOidc_preferencesPreferencesSingletonFactoryCompanion, OICCOpenIdConnectConfiguration, OICCOpenIdConnectConfigurationCompanion, OICCPreferencesCodeAuthFlow, OICCPreferencesEndSessionFlow, OICCSettingsKey, OICCSettingsTokenStore, OICCTokenExpirationPolicy, OICCTokenExpirationPolicyCompanion, OpenIdConnectClient, OpenIdConnectClientCompanion, OpenIdConnectClientConfig, OpenIdConnectClientConfigCompanion, OpenIdConnectErrorResponse, OpenIdConnectErrorResponseCompanion, OpenIdConnectErrorResponseError, OpenIdConnectErrorResponseErrorCompanion, OpenIdConnectException, OpenIdConnectExceptionAuthenticationCancelled, OpenIdConnectExceptionAuthenticationFailure, OpenIdConnectExceptionDiscoveryFailure, OpenIdConnectExceptionInvalidConfiguration, OpenIdConnectExceptionInvalidUrl, OpenIdConnectExceptionTechnicalFailure, OpenIdConnectExceptionTokenExpired, OpenIdConnectExceptionUnsuccessfulTokenRequest, OpenIdConnectExceptionUnsupportedFormat, PKCE, TokenRefreshHandler, TokenRequest, TokenStoreProtocol;

@protocol AbstractCodeAuthFlow, CodeAuthFlowFactoryProtocol, OICCEndSessionFlow, OICCKotlinAnnotation, OICCKotlinAutoCloseable, OICCKotlinComparable, OICCKotlinContinuation, OICCKotlinContinuationInterceptor, OICCKotlinCoroutineContext, OICCKotlinCoroutineContextElement, OICCKotlinCoroutineContextKey, OICCKotlinFunction, OICCKotlinIterator, OICCKotlinKAnnotatedElement, OICCKotlinKClass, OICCKotlinKClassifier, OICCKotlinKDeclarationContainer, OICCKotlinKType, OICCKotlinMapEntry, OICCKotlinSequence, OICCKotlinSuspendFunction1, OICCKotlinSuspendFunction2, OICCKotlinx_coroutines_coreCancellableContinuation, OICCKotlinx_coroutines_coreChildHandle, OICCKotlinx_coroutines_coreChildJob, OICCKotlinx_coroutines_coreCoroutineScope, OICCKotlinx_coroutines_coreDisposableHandle, OICCKotlinx_coroutines_coreFlow, OICCKotlinx_coroutines_coreFlowCollector, OICCKotlinx_coroutines_coreJob, OICCKotlinx_coroutines_coreMutex, OICCKotlinx_coroutines_coreParentJob, OICCKotlinx_coroutines_coreRunnable, OICCKotlinx_coroutines_coreSelectClause, OICCKotlinx_coroutines_coreSelectClause0, OICCKotlinx_coroutines_coreSelectClause2, OICCKotlinx_coroutines_coreSelectInstance, OICCKotlinx_io_coreRawSink, OICCKotlinx_io_coreRawSource, OICCKotlinx_io_coreSink, OICCKotlinx_io_coreSource, OICCKotlinx_serialization_coreCompositeDecoder, OICCKotlinx_serialization_coreCompositeEncoder, OICCKotlinx_serialization_coreDecoder, OICCKotlinx_serialization_coreDeserializationStrategy, OICCKotlinx_serialization_coreEncoder, OICCKotlinx_serialization_coreKSerializer, OICCKotlinx_serialization_coreSerialDescriptor, OICCKotlinx_serialization_coreSerialFormat, OICCKotlinx_serialization_coreSerializationStrategy, OICCKotlinx_serialization_coreSerializersModuleCollector, OICCKotlinx_serialization_coreStringFormat, OICCKotlinx_serialization_jsonJsonNamingStrategy, OICCKtor_client_coreHttpClientEngine, OICCKtor_client_coreHttpClientEngineCapability, OICCKtor_client_coreHttpClientPlugin, OICCKtor_client_coreHttpRequest, OICCKtor_httpHeaders, OICCKtor_httpHttpMessage, OICCKtor_httpHttpMessageBuilder, OICCKtor_httpParameters, OICCKtor_httpParametersBuilder, OICCKtor_ioByteReadChannel, OICCKtor_ioCloseable, OICCKtor_ioJvmSerializable, OICCKtor_utilsAttributes, OICCKtor_utilsStringValues, OICCKtor_utilsStringValuesBuilder, OICCPreferences, OICCTokenRefresher, OpenIdConnectClientProtocol;

NS_ASSUME_NONNULL_BEGIN
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunknown-warning-option"
#pragma clang diagnostic ignored "-Wincompatible-property-type"
#pragma clang diagnostic ignored "-Wnullability"

#pragma push_macro("_Nullable_result")
#if !__has_feature(nullability_nullable_result)
#undef _Nullable_result
#define _Nullable_result _Nullable
#endif

__attribute__((swift_name("KotlinBase")))
@interface OICCBase : NSObject
- (instancetype)init __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
+ (void)initialize __attribute__((objc_requires_super));
@end

@interface OICCBase (OICCBaseCopying) <NSCopying>
@end

__attribute__((swift_name("KotlinMutableSet")))
@interface OICCMutableSet<ObjectType> : NSMutableSet<ObjectType>
@end

__attribute__((swift_name("KotlinMutableDictionary")))
@interface OICCMutableDictionary<KeyType, ObjectType> : NSMutableDictionary<KeyType, ObjectType>
@end

@interface NSError (NSErrorOICCKotlinException)
@property (readonly) id _Nullable kotlinException;
@end

__attribute__((swift_name("KotlinNumber")))
@interface OICCNumber : NSNumber
- (instancetype)initWithChar:(char)value __attribute__((unavailable));
- (instancetype)initWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
- (instancetype)initWithShort:(short)value __attribute__((unavailable));
- (instancetype)initWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
- (instancetype)initWithInt:(int)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
- (instancetype)initWithLong:(long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
- (instancetype)initWithLongLong:(long long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
- (instancetype)initWithFloat:(float)value __attribute__((unavailable));
- (instancetype)initWithDouble:(double)value __attribute__((unavailable));
- (instancetype)initWithBool:(BOOL)value __attribute__((unavailable));
- (instancetype)initWithInteger:(NSInteger)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
+ (instancetype)numberWithChar:(char)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
+ (instancetype)numberWithShort:(short)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
+ (instancetype)numberWithInt:(int)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
+ (instancetype)numberWithLong:(long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
+ (instancetype)numberWithLongLong:(long long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
+ (instancetype)numberWithFloat:(float)value __attribute__((unavailable));
+ (instancetype)numberWithDouble:(double)value __attribute__((unavailable));
+ (instancetype)numberWithBool:(BOOL)value __attribute__((unavailable));
+ (instancetype)numberWithInteger:(NSInteger)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
@end

__attribute__((swift_name("KotlinByte")))
@interface OICCByte : OICCNumber
- (instancetype)initWithChar:(char)value;
+ (instancetype)numberWithChar:(char)value;
@end

__attribute__((swift_name("KotlinUByte")))
@interface OICCUByte : OICCNumber
- (instancetype)initWithUnsignedChar:(unsigned char)value;
+ (instancetype)numberWithUnsignedChar:(unsigned char)value;
@end

__attribute__((swift_name("KotlinShort")))
@interface OICCShort : OICCNumber
- (instancetype)initWithShort:(short)value;
+ (instancetype)numberWithShort:(short)value;
@end

__attribute__((swift_name("KotlinUShort")))
@interface OICCUShort : OICCNumber
- (instancetype)initWithUnsignedShort:(unsigned short)value;
+ (instancetype)numberWithUnsignedShort:(unsigned short)value;
@end

__attribute__((swift_name("KotlinInt")))
@interface OICCInt : OICCNumber
- (instancetype)initWithInt:(int)value;
+ (instancetype)numberWithInt:(int)value;
@end

__attribute__((swift_name("KotlinUInt")))
@interface OICCUInt : OICCNumber
- (instancetype)initWithUnsignedInt:(unsigned int)value;
+ (instancetype)numberWithUnsignedInt:(unsigned int)value;
@end

__attribute__((swift_name("KotlinLong")))
@interface OICCLong : OICCNumber
- (instancetype)initWithLongLong:(long long)value;
+ (instancetype)numberWithLongLong:(long long)value;
@end

__attribute__((swift_name("KotlinULong")))
@interface OICCULong : OICCNumber
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value;
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value;
@end

__attribute__((swift_name("KotlinFloat")))
@interface OICCFloat : OICCNumber
- (instancetype)initWithFloat:(float)value;
+ (instancetype)numberWithFloat:(float)value;
@end

__attribute__((swift_name("KotlinDouble")))
@interface OICCDouble : OICCNumber
- (instancetype)initWithDouble:(double)value;
+ (instancetype)numberWithDouble:(double)value;
@end

__attribute__((swift_name("KotlinBoolean")))
@interface OICCBoolean : OICCNumber
- (instancetype)initWithBool:(BOOL)value;
+ (instancetype)numberWithBool:(BOOL)value;
@end

@protocol OpenIdConnectClientProtocol
@required

/**
 * Create an Access Token Request.
 * You should use [OpenIdConnectClient.exchangeToken] for creating and executing a request instead.
 *
 * @param authCodeRequest the original request for auth code
 * @param code the authcode received via redirect
 * @param configure configuration closure for the HTTP request
 *
 * @return [TokenRequest]
 *
 * @note This method converts instances of OpenIdConnectException, CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)createAccessTokenRequestAuthCodeRequest:(AuthCodeRequest *)authCodeRequest code:(NSString *)code configure:(void (^ _Nullable)(OICCKtor_client_coreHttpRequestBuilder *))configure completionHandler:(void (^)(TokenRequest * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("createAccessTokenRequest(authCodeRequest:code:configure:completionHandler:)")));

/**
 * Creates an Authorization Code Request which can then be executed by the
 * [CodeAuthFlow][org.publicvalue.multiplatform.oidc.flows.CodeAuthFlow].
 *
 * @note This method converts instances of OpenIdConnectException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (AuthCodeRequest * _Nullable)createAuthorizationCodeRequestAndReturnError:(NSError * _Nullable * _Nullable)error configure:(void (^ _Nullable)(OICCKtor_httpURLBuilder *))configure __attribute__((swift_name("createAuthorizationCodeRequest(configure:)")));

/**
 * Creates an End Session Request which can then be executed by the
 * [CodeAuthFlow][org.publicvalue.multiplatform.oidc.flows.CodeAuthFlow].
 *
 * @param idToken used for id_token_hint, recommended by openid spec, optional
 *
 * @note This method converts instances of OpenIdConnectException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (EndSessionRequest * _Nullable)createEndSessionRequestIdToken:(NSString * _Nullable)idToken error:(NSError * _Nullable * _Nullable)error configure:(void (^ _Nullable)(OICCKtor_httpURLBuilder *))configure __attribute__((swift_name("createEndSessionRequest(idToken:configure:)")));

/**
 * Create a Refresh Token Request.
 * You should use [OpenIdConnectClient.refreshToken] for creating and executing a request instead.
 *
 * @param refreshToken the refresh token
 * @param configure configuration closure for the HTTP request (will _not_  be used for
 * discovery if necessary)
 *
 * @return [TokenRequest]
 *
 * @note This method converts instances of OpenIdConnectException, CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)createRefreshTokenRequestRefreshToken:(NSString *)refreshToken configure:(void (^ _Nullable)(OICCKtor_client_coreHttpRequestBuilder *))configure completionHandler:(void (^)(TokenRequest * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("createRefreshTokenRequest(refreshToken:configure:completionHandler:)")));

/**
 * Discover OpenID Connect Configuration using the discovery endpoint.
 * Updates the configuration, but will keep any existing configuration.
 *
 * See: [OpenID Connect Discovery](https://openid.net/specs/openid-connect-discovery-1_0.html)
 *
 * @param configure configuration closure to configure the http request builder with
 *
 * @note This method converts instances of OpenIdConnectException, CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)discoverConfigure:(void (^ _Nullable)(OICCKtor_client_coreHttpRequestBuilder *))configure completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("discover(configure:completionHandler:)")));

/**
 * RP-initiated logout.
 * Performs the POST request for logout.
 *
 * See: [OpenID Spec](https://openid.net/specs/openid-connect-rpinitiated-1_0.html)
 *
 * @param configure configuration closure to configure the http request builder with (will _not_
 * be used for discovery if necessary)
 *
 * @note This method converts instances of OpenIdConnectException, CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)endSessionIdToken:(NSString *)idToken configure:(void (^ _Nullable)(OICCKtor_client_coreHttpRequestBuilder *))configure completionHandler:(void (^)(OICCKtor_httpHttpStatusCode * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("endSession(idToken:configure:completionHandler:)")));

/**
 * Create and send an Access Token Request following
 * [RFC6749: OAuth](https://datatracker.ietf.org/doc/html/rfc6749#section-4.1.3) and
 * [RFC7636: PKCE](https://datatracker.ietf.org/doc/html/rfc7636#section-4.5)
 *
 * @param authCodeRequest the original request for auth code
 * @param code the authcode received via redirect
 * @param configure configuration closure for the HTTP request (will _not_  be used for
 * discovery if necessary)
 *
 * @return [AccessTokenResponse]
 *
 * @note This method converts instances of OpenIdConnectException, CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)exchangeTokenAuthCodeRequest:(AuthCodeRequest *)authCodeRequest code:(NSString *)code configure:(void (^ _Nullable)(OICCKtor_client_coreHttpRequestBuilder *))configure completionHandler:(void (^)(AccessTokenResponse * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("exchangeToken(authCodeRequest:code:configure:completionHandler:)")));

/**
 * Create and send a Refresh Token Request.
 * [RFC6749](https://datatracker.ietf.org/doc/html/rfc6749#section-6)
 *
 * @param refreshToken the refresh token
 * @param configure configuration closure for the HTTP request (will _not_  be used for
 * discovery if necessary)
 *
 * @return [AccessTokenResponse]
 *
 * @note This method converts instances of OpenIdConnectException, CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)refreshTokenRefreshToken:(NSString *)refreshToken configure:(void (^ _Nullable)(OICCKtor_client_coreHttpRequestBuilder *))configure completionHandler:(void (^)(AccessTokenResponse * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("refreshToken(refreshToken:configure:completionHandler:)")));

/**
 * Revoke Refresh or Access token.
 * [RFC7009: Token Revocation](https://datatracker.ietf.org/doc/html/rfc7009)
 *
 * @param token refresh token or access token
 * @param configure configuration closure to configure the http request builder with (will _not_
 * be used for discovery if necessary)
 *
 * @note This method converts instances of OpenIdConnectException, CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)revokeTokenToken:(NSString *)token configure:(void (^ _Nullable)(OICCKtor_client_coreHttpRequestBuilder *))configure completionHandler:(void (^)(OICCKtor_httpHttpStatusCode * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("revokeToken(token:configure:completionHandler:)")));
@property (readonly) OpenIdConnectClientConfig *config __attribute__((swift_name("config")));
@property (readonly) OICCOpenIdConnectConfiguration * _Nullable discoverDocument __attribute__((swift_name("discoverDocument")));
@end


/**
 * OpenIdConnectClient implements the basic methods used to perform OpenID Connect Authentication.
 * A client may also be constructed using the [Builder method][org.publicvalue.multiplatform.oidc.OpenIdConnectClient]
 *
 * @param httpClient The (ktor) HTTP client to be used for code <-> token exchange and endSession requests.
 * Authentication is performed using [CodeAuthFlow][org.publicvalue.multiplatform.oidc.flows.CodeAuthFlow]
 *
 * @param config [Configuration][org.publicvalue.multiplatform.oidc.OpenIdConnectClientConfig] for this client
 */
__attribute__((objc_subclassing_restricted))
@interface OpenIdConnectClient : OICCBase <OpenIdConnectClientProtocol>

/**
 * Swift convenience constructor
 * @suppress
 */
- (instancetype)initWithConfig:(OpenIdConnectClientConfig *)config __attribute__((swift_name("init(config:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithHttpClient:(OICCKtor_client_coreHttpClient *)httpClient config:(OpenIdConnectClientConfig *)config __attribute__((swift_name("init(httpClient:config:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) OpenIdConnectClientCompanion *companion __attribute__((swift_name("companion")));

/**
 * @note This method converts instances of OpenIdConnectException, CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)createAccessTokenRequestAuthCodeRequest:(AuthCodeRequest *)authCodeRequest code:(NSString *)code configure:(void (^ _Nullable)(OICCKtor_client_coreHttpRequestBuilder *))configure completionHandler:(void (^)(TokenRequest * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("createAccessTokenRequest(authCodeRequest:code:configure:completionHandler:)")));

/**
 * @note This method converts instances of OpenIdConnectException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (AuthCodeRequest * _Nullable)createAuthorizationCodeRequestAndReturnError:(NSError * _Nullable * _Nullable)error configure:(void (^ _Nullable)(OICCKtor_httpURLBuilder *))configure __attribute__((swift_name("createAuthorizationCodeRequest(configure:)")));

/**
 * @note This method converts instances of OpenIdConnectException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (EndSessionRequest * _Nullable)createEndSessionRequestIdToken:(NSString * _Nullable)idToken error:(NSError * _Nullable * _Nullable)error configure:(void (^ _Nullable)(OICCKtor_httpURLBuilder *))configure __attribute__((swift_name("createEndSessionRequest(idToken:configure:)")));

/**
 * @note This method converts instances of OpenIdConnectException, CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)createRefreshTokenRequestRefreshToken:(NSString *)refreshToken configure:(void (^ _Nullable)(OICCKtor_client_coreHttpRequestBuilder *))configure completionHandler:(void (^)(TokenRequest * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("createRefreshTokenRequest(refreshToken:configure:completionHandler:)")));

/**
 * @note This method converts instances of OpenIdConnectException, CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)discoverConfigure:(void (^ _Nullable)(OICCKtor_client_coreHttpRequestBuilder *))configure completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("discover(configure:completionHandler:)")));

/**
 * @note This method converts instances of OpenIdConnectException, CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)endSessionIdToken:(NSString *)idToken configure:(void (^ _Nullable)(OICCKtor_client_coreHttpRequestBuilder *))configure completionHandler:(void (^)(OICCKtor_httpHttpStatusCode * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("endSession(idToken:configure:completionHandler:)")));

/**
 * @note This method converts instances of OpenIdConnectException, CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)exchangeTokenAuthCodeRequest:(AuthCodeRequest *)authCodeRequest code:(NSString *)code configure:(void (^ _Nullable)(OICCKtor_client_coreHttpRequestBuilder *))configure completionHandler:(void (^)(AccessTokenResponse * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("exchangeToken(authCodeRequest:code:configure:completionHandler:)")));

/**
 * @note This method converts instances of OpenIdConnectException, CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)refreshTokenRefreshToken:(NSString *)refreshToken configure:(void (^ _Nullable)(OICCKtor_client_coreHttpRequestBuilder *))configure completionHandler:(void (^)(AccessTokenResponse * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("refreshToken(refreshToken:configure:completionHandler:)")));

/**
 * @note This method converts instances of OpenIdConnectException, CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)revokeTokenToken:(NSString *)token configure:(void (^ _Nullable)(OICCKtor_client_coreHttpRequestBuilder *))configure completionHandler:(void (^)(OICCKtor_httpHttpStatusCode * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("revokeToken(token:configure:completionHandler:)")));
@property (readonly) OpenIdConnectClientConfig *config __attribute__((swift_name("config")));
@property OICCOpenIdConnectConfiguration * _Nullable discoverDocument __attribute__((swift_name("discoverDocument")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("OpenIdConnectClient.Companion")))
@interface OpenIdConnectClientCompanion : OICCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) OpenIdConnectClientCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) OICCKtor_client_coreHttpClient *DefaultHttpClient __attribute__((swift_name("DefaultHttpClient")));
@end


/**
 * Endpoint configuration
 *
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
@interface Endpoints : OICCBase
- (instancetype)initWithTokenEndpoint:(NSString * _Nullable)tokenEndpoint authorizationEndpoint:(NSString * _Nullable)authorizationEndpoint userInfoEndpoint:(NSString * _Nullable)userInfoEndpoint endSessionEndpoint:(NSString * _Nullable)endSessionEndpoint revocationEndpoint:(NSString * _Nullable)revocationEndpoint __attribute__((swift_name("init(tokenEndpoint:authorizationEndpoint:userInfoEndpoint:endSessionEndpoint:revocationEndpoint:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) EndpointsCompanion *companion __attribute__((swift_name("companion")));

/**
 * Set a baseUrl that is applied for all endpoints.
 * E.g. baseUrl("http://localhost/oauth/") {
 *      tokenEndpoint = "token"
 * }
 */
- (void)baseUrlBaseUrl:(NSString *)baseUrl block:(void (^)(Endpoints *))block __attribute__((swift_name("baseUrl(baseUrl:block:)")));
- (Endpoints *)doCopyTokenEndpoint:(NSString * _Nullable)tokenEndpoint authorizationEndpoint:(NSString * _Nullable)authorizationEndpoint userInfoEndpoint:(NSString * _Nullable)userInfoEndpoint endSessionEndpoint:(NSString * _Nullable)endSessionEndpoint revocationEndpoint:(NSString * _Nullable)revocationEndpoint __attribute__((swift_name("doCopy(tokenEndpoint:authorizationEndpoint:userInfoEndpoint:endSessionEndpoint:revocationEndpoint:)")));

/**
 * Endpoint configuration
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * Endpoint configuration
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * Endpoint configuration
 */
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString * _Nullable authorizationEndpoint __attribute__((swift_name("authorizationEndpoint")));
@property NSString * _Nullable endSessionEndpoint __attribute__((swift_name("endSessionEndpoint")));
@property NSString * _Nullable revocationEndpoint __attribute__((swift_name("revocationEndpoint")));
@property NSString * _Nullable tokenEndpoint __attribute__((swift_name("tokenEndpoint")));
@property NSString * _Nullable userInfoEndpoint __attribute__((swift_name("userInfoEndpoint")));
@end


/**
 * Endpoint configuration
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Endpoints.Companion")))
@interface EndpointsCompanion : OICCBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Endpoint configuration
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) EndpointsCompanion *shared __attribute__((swift_name("shared")));

/**
 * Endpoint configuration
 */
- (id<OICCKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end

__attribute__((swift_name("KotlinThrowable")))
@interface OICCKotlinThrowable : OICCBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(OICCKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(OICCKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));

/**
 * @note annotations
 *   kotlin.experimental.ExperimentalNativeApi
*/
- (OICCKotlinArray<NSString *> *)getStackTrace __attribute__((swift_name("getStackTrace()")));
- (void)printStackTrace __attribute__((swift_name("printStackTrace()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) OICCKotlinThrowable * _Nullable cause __attribute__((swift_name("cause")));
@property (readonly) NSString * _Nullable message __attribute__((swift_name("message")));
- (NSError *)asError __attribute__((swift_name("asError()")));
@end

__attribute__((swift_name("KotlinException")))
@interface OICCKotlinException : OICCKotlinThrowable
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(OICCKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(OICCKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("HttpException")))
@interface OICCHttpException : OICCKotlinException
- (instancetype)initWithMessage:(NSString *)message statusCode:(OICCKtor_httpHttpStatusCode *)statusCode body:(NSString * _Nullable)body errorResponse:(OpenIdConnectErrorResponse * _Nullable)errorResponse __attribute__((swift_name("init(message:statusCode:body:errorResponse:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithCause:(OICCKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(OICCKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (readonly) NSString * _Nullable body __attribute__((swift_name("body")));
@property (readonly) OpenIdConnectErrorResponse * _Nullable errorResponse __attribute__((swift_name("errorResponse")));
@property (readonly) NSString *message __attribute__((swift_name("message")));
@property (readonly) OICCKtor_httpHttpStatusCode *statusCode __attribute__((swift_name("statusCode")));
@end


/**
 * Configuration for an [OpenIdConnectClient].
 * A configuration can also be built using [OpenIdConnectClient] builder function with block
 * argument.
 *
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
@interface OpenIdConnectClientConfig : OICCBase
- (instancetype)initWithDiscoveryUri:(NSString * _Nullable)discoveryUri endpoints:(Endpoints * _Nullable)endpoints clientId:(NSString * _Nullable)clientId clientSecret:(NSString * _Nullable)clientSecret scope:(NSString * _Nullable)scope codeChallengeMethod:(CodeChallengeMethod *)codeChallengeMethod redirectUri:(NSString * _Nullable)redirectUri postLogoutRedirectUri:(NSString * _Nullable)postLogoutRedirectUri disableNonce:(BOOL)disableNonce __attribute__((swift_name("init(discoveryUri:endpoints:clientId:clientSecret:scope:codeChallengeMethod:redirectUri:postLogoutRedirectUri:disableNonce:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) OpenIdConnectClientConfigCompanion *companion __attribute__((swift_name("companion")));
- (OpenIdConnectClientConfig *)doCopyDiscoveryUri:(NSString * _Nullable)discoveryUri endpoints:(Endpoints * _Nullable)endpoints clientId:(NSString * _Nullable)clientId clientSecret:(NSString * _Nullable)clientSecret scope:(NSString * _Nullable)scope codeChallengeMethod:(CodeChallengeMethod *)codeChallengeMethod redirectUri:(NSString * _Nullable)redirectUri postLogoutRedirectUri:(NSString * _Nullable)postLogoutRedirectUri disableNonce:(BOOL)disableNonce __attribute__((swift_name("doCopy(discoveryUri:endpoints:clientId:clientSecret:scope:codeChallengeMethod:redirectUri:postLogoutRedirectUri:disableNonce:)")));

/**
 * Configure the endpoints.
 *
 * Either [discoveryUri] or both [authorizationEndpoint][Endpoints.authorizationEndpoint] and
 * [tokenEndpoint][Endpoints.tokenEndpoint] are required.
 *
 * [endSessionEndpoint][Endpoints.endSessionEndpoint] is required if you wish to logout.
 */
- (void)endpointsBlock:(void (^)(Endpoints *))block __attribute__((swift_name("endpoints(block:)")));

/**
 * Configuration for an [OpenIdConnectClient].
 * A configuration can also be built using [OpenIdConnectClient] builder function with block
 * argument.
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * Configuration for an [OpenIdConnectClient].
 * A configuration can also be built using [OpenIdConnectClient] builder function with block
 * argument.
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * Configuration for an [OpenIdConnectClient].
 * A configuration can also be built using [OpenIdConnectClient] builder function with block
 * argument.
 */
- (NSString *)description __attribute__((swift_name("description()")));

/**
 * Update this client config with discovery document.
 * Will NOT override already set properties in config.
 */
- (void)updateWithDiscoveryConfig:(OICCOpenIdConnectConfiguration *)config __attribute__((swift_name("updateWithDiscovery(config:)")));

/**
 * REQUIRED
 *
 * [RFC6749](https://datatracker.ietf.org/doc/html/rfc6749#section-2.2)
 */
@property NSString * _Nullable clientId __attribute__((swift_name("clientId")));
@property NSString * _Nullable clientSecret __attribute__((swift_name("clientSecret")));

/**
 * The Code Challenge Method to use for PKCE.
 *
 * Default is [S256][CodeChallengeMethod.S256]).
 * Set to [off][CodeChallengeMethod.off]) to disable PKCE.
 */
@property CodeChallengeMethod *codeChallengeMethod __attribute__((swift_name("codeChallengeMethod")));

/**
 * Disables sending nonce in the authentication request.
 * This is not recommended as [nonce is used to mitigate replay attacks](https://openid.net/specs/openid-connect-core-1_0.html#NonceNotes).
 */
@property BOOL disableNonce __attribute__((swift_name("disableNonce")));

/**
 * If set, no further endpoints have to be configured.
 * You can override discovered endpoints in [endpoints]
 */
@property (readonly) NSString * _Nullable discoveryUri __attribute__((swift_name("discoveryUri")));
@property Endpoints * _Nullable endpoints __attribute__((swift_name("endpoints")));

/**
 * Url that is used for redirecting back to the app after logout request.
 * Is only used if endSession is called on an [EndSessionFlow][org.publicvalue.multiplatform.oidc.flows.EndSessionFlow].
 *
 * [OpenID Spec](https://openid.net/specs/openid-connect-rpinitiated-1_0.html)
 */
@property NSString * _Nullable postLogoutRedirectUri __attribute__((swift_name("postLogoutRedirectUri")));

/**
 * [rfc6749](https://datatracker.ietf.org/doc/html/rfc6749#section-3.1.2)
 */
@property NSString * _Nullable redirectUri __attribute__((swift_name("redirectUri")));

/**
 * OPTIONAL
 *
 * [RFC6749](https://datatracker.ietf.org/doc/html/rfc6749#section-3.3)
 */
@property NSString * _Nullable scope __attribute__((swift_name("scope")));
@end


/**
 * Configuration for an [OpenIdConnectClient].
 * A configuration can also be built using [OpenIdConnectClient] builder function with block
 * argument.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("OpenIdConnectClientConfig.Companion")))
@interface OpenIdConnectClientConfigCompanion : OICCBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Configuration for an [OpenIdConnectClient].
 * A configuration can also be built using [OpenIdConnectClient] builder function with block
 * argument.
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) OpenIdConnectClientConfigCompanion *shared __attribute__((swift_name("shared")));

/**
 * Configuration for an [OpenIdConnectClient].
 * A configuration can also be built using [OpenIdConnectClient] builder function with block
 * argument.
 */
- (id<OICCKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end

@interface OpenIdConnectException : OICCKotlinException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithCause:(OICCKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(OICCKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (readonly) OICCKotlinThrowable * _Nullable cause __attribute__((swift_name("cause")));
@property (readonly) NSString *message __attribute__((swift_name("message")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("OpenIdConnectException.AuthenticationCancelled")))
@interface OpenIdConnectExceptionAuthenticationCancelled : OpenIdConnectException
- (instancetype)initWithMessage:(NSString *)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (OpenIdConnectExceptionAuthenticationCancelled *)doCopyMessage:(NSString *)message __attribute__((swift_name("doCopy(message:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *message __attribute__((swift_name("message")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("OpenIdConnectException.AuthenticationFailure")))
@interface OpenIdConnectExceptionAuthenticationFailure : OpenIdConnectException
- (instancetype)initWithMessage:(NSString *)message cause:(OICCKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
- (OpenIdConnectExceptionAuthenticationFailure *)doCopyMessage:(NSString *)message cause:(OICCKotlinThrowable * _Nullable)cause __attribute__((swift_name("doCopy(message:cause:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) OICCKotlinThrowable * _Nullable cause __attribute__((swift_name("cause")));
@property (readonly) NSString *message __attribute__((swift_name("message")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("OpenIdConnectException.DiscoveryFailure")))
@interface OpenIdConnectExceptionDiscoveryFailure : OpenIdConnectException
- (instancetype)initWithMessage:(NSString *)message cause:(OICCKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
- (OpenIdConnectExceptionDiscoveryFailure *)doCopyMessage:(NSString *)message cause:(OICCKotlinThrowable * _Nullable)cause __attribute__((swift_name("doCopy(message:cause:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) OICCKotlinThrowable * _Nullable cause __attribute__((swift_name("cause")));
@property (readonly) NSString *message __attribute__((swift_name("message")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("OpenIdConnectException.InvalidConfiguration")))
@interface OpenIdConnectExceptionInvalidConfiguration : OpenIdConnectException
- (instancetype)initWithMessage:(NSString *)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (OpenIdConnectExceptionInvalidConfiguration *)doCopyMessage:(NSString *)message __attribute__((swift_name("doCopy(message:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *message __attribute__((swift_name("message")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("OpenIdConnectException.InvalidUrl")))
@interface OpenIdConnectExceptionInvalidUrl : OpenIdConnectException
- (instancetype)initWithUrl:(NSString * _Nullable)url cause:(OICCKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(url:cause:)"))) __attribute__((objc_designated_initializer));
- (OpenIdConnectExceptionInvalidUrl *)doCopyUrl:(NSString * _Nullable)url cause:(OICCKotlinThrowable * _Nullable)cause __attribute__((swift_name("doCopy(url:cause:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) OICCKotlinThrowable * _Nullable cause __attribute__((swift_name("cause")));
@property (readonly) NSString * _Nullable url __attribute__((swift_name("url")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("OpenIdConnectException.TechnicalFailure")))
@interface OpenIdConnectExceptionTechnicalFailure : OpenIdConnectException
- (instancetype)initWithMessage:(NSString *)message cause:(OICCKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
- (OpenIdConnectExceptionTechnicalFailure *)doCopyMessage:(NSString *)message cause:(OICCKotlinThrowable * _Nullable)cause __attribute__((swift_name("doCopy(message:cause:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) OICCKotlinThrowable * _Nullable cause __attribute__((swift_name("cause")));
@property (readonly) NSString *message __attribute__((swift_name("message")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("OpenIdConnectException.TokenExpired")))
@interface OpenIdConnectExceptionTokenExpired : OpenIdConnectException
- (instancetype)initWithMessage:(NSString *)message cause:(OICCKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
- (OpenIdConnectExceptionTokenExpired *)doCopyMessage:(NSString *)message cause:(OICCKotlinThrowable * _Nullable)cause __attribute__((swift_name("doCopy(message:cause:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) OICCKotlinThrowable * _Nullable cause __attribute__((swift_name("cause")));
@property (readonly) NSString *message __attribute__((swift_name("message")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("OpenIdConnectException.UnsuccessfulTokenRequest")))
@interface OpenIdConnectExceptionUnsuccessfulTokenRequest : OpenIdConnectException
- (instancetype)initWithMessage:(NSString *)message statusCode:(OICCKtor_httpHttpStatusCode *)statusCode errorResponse:(OpenIdConnectErrorResponse * _Nullable)errorResponse cause:(OICCKotlinException *)cause __attribute__((swift_name("init(message:statusCode:errorResponse:cause:)"))) __attribute__((objc_designated_initializer));
- (OpenIdConnectExceptionUnsuccessfulTokenRequest *)doCopyMessage:(NSString *)message statusCode:(OICCKtor_httpHttpStatusCode *)statusCode errorResponse:(OpenIdConnectErrorResponse * _Nullable)errorResponse cause:(OICCKotlinException *)cause __attribute__((swift_name("doCopy(message:statusCode:errorResponse:cause:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) OICCKotlinException *cause __attribute__((swift_name("cause")));
@property (readonly) OpenIdConnectErrorResponse * _Nullable errorResponse __attribute__((swift_name("errorResponse")));
@property (readonly) NSString *message __attribute__((swift_name("message")));
@property (readonly) OICCKtor_httpHttpStatusCode *statusCode __attribute__((swift_name("statusCode")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("OpenIdConnectException.UnsupportedFormat")))
@interface OpenIdConnectExceptionUnsupportedFormat : OpenIdConnectException
- (instancetype)initWithMessage:(NSString *)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (OpenIdConnectExceptionUnsupportedFormat *)doCopyMessage:(NSString *)message __attribute__((swift_name("doCopy(message:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *message __attribute__((swift_name("message")));
@end

@protocol CodeAuthFlowFactoryProtocol
@required

/**
 * Create an auth flow to perform authorization.
 */
- (id<AbstractCodeAuthFlow>)createAuthFlowClient:(id<OpenIdConnectClientProtocol>)client __attribute__((swift_name("createAuthFlow(client:)")));

/**
 * Create a flow to perform session termination.
 */
- (id<OICCEndSessionFlow>)createEndSessionFlowClient:(id<OpenIdConnectClientProtocol>)client __attribute__((swift_name("createEndSessionFlow(client:)")));
@end

__attribute__((objc_subclassing_restricted))
@interface CodeAuthFlowFactory : OICCBase <CodeAuthFlowFactoryProtocol>
- (instancetype)initWithEphemeralBrowserSession:(BOOL)ephemeralBrowserSession __attribute__((swift_name("init(ephemeralBrowserSession:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithEphemeralBrowserSession:(BOOL)ephemeralBrowserSession preferencesFactory:(OICCOidc_preferencesPreferencesFactory *)preferencesFactory __attribute__((swift_name("init(ephemeralBrowserSession:preferencesFactory:)"))) __attribute__((objc_designated_initializer));
- (CodeAuthFlow *)createAuthFlowClient:(id<OpenIdConnectClientProtocol>)client __attribute__((swift_name("createAuthFlow(client:)")));
- (id<OICCEndSessionFlow>)createEndSessionFlowClient:(id<OpenIdConnectClientProtocol>)client __attribute__((swift_name("createEndSessionFlow(client:)")));
@end


/**
 * Implements the OAuth 2.0 Code Authorization Flow.
 * See: [RFC6749](https://datatracker.ietf.org/doc/html/rfc6749#section-4.1)
 *
 * Implementations have to provide their own method [startLoginFlow]
 * as this requires user interaction (e.g. via browser).
 */
@protocol AbstractCodeAuthFlow
@required

/**
 * Check whether continueLogin can safely be called.
 *
 * @return true if startLogin() was called before and continueLogin() was not yet called.
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)canContinueLoginWithCompletionHandler:(void (^)(OICCBoolean * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("canContinueLogin(completionHandler:)")));

/**
 * Continue login flow.
 *
 * @throws OpenIdConnectException if canContinueLogin() returns false or if token exchange fails.
 *
 * @param configureTokenExchange configuration closure to configure the http request builder with (will _not_
 * be used for discovery if necessary)
 *
 * @note This method converts instances of OpenIdConnectException, CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)continueLoginConfigureTokenExchange:(void (^ _Nullable)(OICCKtor_client_coreHttpRequestBuilder *))configureTokenExchange completionHandler:(void (^)(AccessTokenResponse * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("continueLogin(configureTokenExchange:completionHandler:)")));

/**
 * Start the authorization flow to request an access token.
 *
 * This may not return in some cases on Android if the application is terminated while the login website is shown.
 * In this cases, call continueLogin() manually after your application restarts.
 *
 * @return the AccessTokenResponse.
 *
 * @param configureAuthUrl configuration closure to configure the auth url passed to browser
 * @param configureTokenExchange configuration closure to configure the http request builder with (will _not_
 * be used for discovery if necessary)
 *
 * @note This method converts instances of CancellationException, OpenIdConnectException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getAccessTokenConfigureAuthUrl:(void (^ _Nullable)(OICCKtor_httpURLBuilder *))configureAuthUrl configureTokenExchange:(void (^ _Nullable)(OICCKtor_client_coreHttpRequestBuilder *))configureTokenExchange completionHandler:(void (^)(AccessTokenResponse * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getAccessToken(configureAuthUrl:configureTokenExchange:completionHandler:)")));

/**
 * Start the authorization flow.
 *
 * @return the Authorization Code Request
 *
 * @param configureAuthUrl configuration closure to configure the auth url passed to browser
 *
 * @note This method converts instances of CancellationException, OpenIdConnectException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)startLoginConfigureAuthUrl:(void (^ _Nullable)(OICCKtor_httpURLBuilder *))configureAuthUrl completionHandler:(void (^)(AuthCodeRequest * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("startLogin(configureAuthUrl:completionHandler:)")));
@end

__attribute__((swift_name("PreferencesCodeAuthFlow")))
@interface OICCPreferencesCodeAuthFlow : OICCBase <AbstractCodeAuthFlow>
- (instancetype)initWithClient:(id<OpenIdConnectClientProtocol>)client preferences:(id<OICCPreferences>)preferences __attribute__((swift_name("init(client:preferences:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)canContinueLoginWithCompletionHandler:(void (^)(OICCBoolean * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("canContinueLogin(completionHandler:)")));

/**
 * @note This method converts instances of OpenIdConnectException, CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)continueLoginConfigureTokenExchange:(void (^ _Nullable)(OICCKtor_client_coreHttpRequestBuilder *))configureTokenExchange completionHandler:(void (^)(AccessTokenResponse * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("continueLogin(configureTokenExchange:completionHandler:)")));

/**
 * Uses the request URL to open a browser and perform authorization.
 * Should return the Authorization Code.
 *
 * @note This method converts instances of CancellationException, OpenIdConnectException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getAuthorizationCodeRequest:(AuthCodeRequest *)request completionHandler:(void (^)(id _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("getAuthorizationCode(request:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException, OpenIdConnectException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)startLoginConfigureAuthUrl:(void (^ _Nullable)(OICCKtor_httpURLBuilder *))configureAuthUrl completionHandler:(void (^)(AuthCodeRequest * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("startLogin(configureAuthUrl:completionHandler:)")));

/**
 * Uses the request URL to open a browser and perform authorization.
 * Call [continueLogin] after returning to your app to receive tokens.
 *
 * @param request The request containing the url and relevant state information
 *
 * @note This method converts instances of CancellationException, OpenIdConnectException to errors.
 * Other uncaught Kotlin exceptions are fatal.
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)startLoginFlowRequest:(AuthCodeRequest *)request completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("startLoginFlow(request:completionHandler:)")));
@property (readonly) id<OpenIdConnectClientProtocol> client __attribute__((swift_name("client")));
@property (readonly) id<OICCPreferences> preferences __attribute__((swift_name("preferences")));
@end


/**
 * Implements the OAuth 2.0 Code Authorization Flow.
 * See: https://datatracker.ietf.org/doc/html/rfc6749#section-4.1
 *
 * Implementations have to provide their own method to get the authorization code,
 * as this requires user interaction (e.g. via browser).
 */
__attribute__((objc_subclassing_restricted))
@interface CodeAuthFlow : OICCPreferencesCodeAuthFlow
- (instancetype)initWithClient:(id<OpenIdConnectClientProtocol>)client preferences:(id<OICCPreferences>)preferences __attribute__((swift_name("init(client:preferences:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));

/**
 * @note This method converts instances of CancellationException, OpenIdConnectException to errors.
 * Other uncaught Kotlin exceptions are fatal.
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)startLoginFlowRequest:(AuthCodeRequest *)request completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("startLoginFlow(request:completionHandler:)")));
@end


/**
 * Flow that implements endSession call via HTTP Get Request in a Browser.
 * Uses the [postLogoutRedirectUri][org.publicvalue.multiplatform.oidc.OpenIdConnectClientConfig.postLogoutRedirectUri]
 * to request redirection after logout to return to the app.
 */
__attribute__((swift_name("EndSessionFlow")))
@protocol OICCEndSessionFlow
@required

/**
 * Check whether continueLogout can safely be called.
 *
 * @return true if startLogout() was called before and continueLogout() was not yet called.
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)canContinueLogoutWithCompletionHandler:(void (^)(OICCBoolean * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("canContinueLogout(completionHandler:)")));

/**
 * Continue logout flow.
 *
 * @throws OpenIdConnectException if canContinueLogout() returns false or if there was an error during logout.
 *
 *
 * @note This method converts instances of CancellationException, OpenIdConnectException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)continueLogoutWithCompletionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("continueLogout(completionHandler:)")));

/**
 * End session using a GET-Request in a WebView.
 * This supports redirecting to the app after logout if post_logout_redirect_uri is set.
 *
 * @param idToken used for id_token_hint, recommended by openid spec, optional
 * @param configureEndSessionUrl configuration closure to configure the http request builder with
 *
 * @note This method converts instances of CancellationException, OpenIdConnectException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)endSessionIdToken:(NSString * _Nullable)idToken configureEndSessionUrl:(void (^ _Nullable)(OICCKtor_httpURLBuilder *))configureEndSessionUrl completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("endSession(idToken:configureEndSessionUrl:completionHandler:)")));

/**
 * Start end session flow using a GET-Request in a WebView.
 * This supports redirecting to the app after logout if post_logout_redirect_uri is set.
 *
 * Call [continueLogout] after returning to your app to check for errors during logout.
 *
 * @param idToken used for id_token_hint, recommended by openid spec, optional
 * @param configureEndSessionUrl configuration closure to configure the http request builder with
 *
 * @note This method converts instances of CancellationException, OpenIdConnectException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)startLogoutIdToken:(NSString * _Nullable)idToken configureEndSessionUrl:(void (^ _Nullable)(OICCKtor_httpURLBuilder *))configureEndSessionUrl completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("startLogout(idToken:configureEndSessionUrl:completionHandler:)")));
@end

__attribute__((swift_name("PreferencesEndSessionFlow")))
@interface OICCPreferencesEndSessionFlow : OICCBase <OICCEndSessionFlow>
- (instancetype)initWithClient:(id<OpenIdConnectClientProtocol>)client preferences:(id<OICCPreferences>)preferences __attribute__((swift_name("init(client:preferences:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)canContinueLogoutWithCompletionHandler:(void (^)(OICCBoolean * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("canContinueLogout(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException, OpenIdConnectException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)continueLogoutWithCompletionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("continueLogout(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException, OpenIdConnectException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)startLogoutIdToken:(NSString * _Nullable)idToken configureEndSessionUrl:(void (^ _Nullable)(OICCKtor_httpURLBuilder *))configureEndSessionUrl completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("startLogout(idToken:configureEndSessionUrl:completionHandler:)")));

/**
 * Start end session flow using a GET-Request in a WebView.
 * This supports redirecting to the app after logout if post_logout_redirect_uri is set.
 *
 * Call [continueLogout] after returning to your app to check for errors during logout.
 *
 * @param request The request containing the url with relevant parameters
 *
 * @note This method converts instances of CancellationException, OpenIdConnectException to errors.
 * Other uncaught Kotlin exceptions are fatal.
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)startLogoutFlowRequest:(EndSessionRequest *)request completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("startLogoutFlow(request:completionHandler:)")));
@property (readonly) id<OpenIdConnectClientProtocol> client __attribute__((swift_name("client")));
@property (readonly) id<OICCPreferences> preferences __attribute__((swift_name("preferences")));
@end


/**
 * Implements the OAuth 2.0 Code Authorization Flow.
 * See: https://datatracker.ietf.org/doc/html/rfc6749#section-4.1
 *
 * Implementations have to provide their own method to get the authorization code,
 * as this requires user interaction (e.g. via browser).
 */
__attribute__((objc_subclassing_restricted))
@interface CodeAuthFlow_ : OICCPreferencesEndSessionFlow
- (instancetype)initWithClient:(id<OpenIdConnectClientProtocol>)client preferences:(id<OICCPreferences>)preferences __attribute__((swift_name("init(client:preferences:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));

/**
 * @note This method converts instances of CancellationException, OpenIdConnectException to errors.
 * Other uncaught Kotlin exceptions are fatal.
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)startLogoutFlowRequest:(EndSessionRequest *)request completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("startLogoutFlow(request:completionHandler:)")));
@end


/**
 * Basic OpenID Connect Discovery implementation.
 * For supported json keys, see [OpenIdConnectConfiguration].
 */
__attribute__((objc_subclassing_restricted))
@interface OpenIdConnectDiscover : OICCBase
- (instancetype)initWithHttpClient:(OICCKtor_client_coreHttpClient *)httpClient __attribute__((swift_name("init(httpClient:)"))) __attribute__((objc_designated_initializer));

/**
 * Retrieve configuration document from url.
 *
 * @param configurationUrl the url
 * @param configure configuration closure to configure the http request builder with
 * @return [OpenIdConnectConfiguration]
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)downloadConfigurationConfigurationUrl:(OICCKtor_httpUrl *)configurationUrl configure:(void (^ _Nullable)(OICCKtor_client_coreHttpRequestBuilder *))configure completionHandler:(void (^)(OICCOpenIdConnectConfiguration * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("downloadConfiguration(configurationUrl:configure:completionHandler:)")));

/**
 * Retrieve configuration document from url.
 *
 * @param configurationUrl the url
 * @param configure configuration closure to configure the http request builder with
 * @return [OpenIdConnectConfiguration]
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)downloadConfigurationConfigurationUrl:(NSString *)configurationUrl configure:(void (^ _Nullable)(OICCKtor_client_coreHttpRequestBuilder *))configure completionHandler_:(void (^)(OICCOpenIdConnectConfiguration * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("downloadConfiguration(configurationUrl:configure:completionHandler_:)")));
@end


/**
 * Result of an Auth Code Request
 *
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
@interface AuthCodeResult : OICCBase
- (instancetype)initWithCode:(NSString * _Nullable)code state:(NSString * _Nullable)state __attribute__((swift_name("init(code:state:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) AuthCodeResultCompanion *companion __attribute__((swift_name("companion")));
- (AuthCodeResult *)doCopyCode:(NSString * _Nullable)code state:(NSString * _Nullable)state __attribute__((swift_name("doCopy(code:state:)")));

/**
 * Result of an Auth Code Request
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * Result of an Auth Code Request
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * Result of an Auth Code Request
 */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable code __attribute__((swift_name("code")));
@property (readonly) NSString * _Nullable state __attribute__((swift_name("state")));
@end


/**
 * Result of an Auth Code Request
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AuthCodeResult.Companion")))
@interface AuthCodeResultCompanion : OICCBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Result of an Auth Code Request
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) AuthCodeResultCompanion *shared __attribute__((swift_name("shared")));

/**
 * Result of an Auth Code Request
 */
- (id<OICCKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * Proof Key for Code Exchange [RFC7636](https://datatracker.ietf.org/doc/html/rfc7636) implementation.
 *
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
@interface PKCE : OICCBase
- (instancetype)initWithCodeVerifier:(NSString *)codeVerifier codeChallenge:(NSString *)codeChallenge __attribute__((swift_name("init(codeVerifier:codeChallenge:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCodeChallengeMethod:(CodeChallengeMethod *)codeChallengeMethod codeVerifier:(NSString *)codeVerifier __attribute__((swift_name("init(codeChallengeMethod:codeVerifier:)"))) __attribute__((objc_designated_initializer));
- (PKCE *)doCopyCodeVerifier:(NSString *)codeVerifier codeChallenge:(NSString *)codeChallenge __attribute__((swift_name("doCopy(codeVerifier:codeChallenge:)")));

/**
 * Proof Key for Code Exchange [RFC7636](https://datatracker.ietf.org/doc/html/rfc7636) implementation.
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * Proof Key for Code Exchange [RFC7636](https://datatracker.ietf.org/doc/html/rfc7636) implementation.
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * Proof Key for Code Exchange [RFC7636](https://datatracker.ietf.org/doc/html/rfc7636) implementation.
 */
- (NSString *)description __attribute__((swift_name("description()")));

/** For authorization **/
@property (readonly) NSString *codeChallenge __attribute__((swift_name("codeChallenge")));

/** For token request **/
@property (readonly) NSString *codeVerifier __attribute__((swift_name("codeVerifier")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FlowWrapper")))
@interface OICCFlowWrapper<__covariant T> : OICCBase

/**
 *  Cancels the flow
 */
- (void)cancel __attribute__((swift_name("cancel()")));

/**
 * Starts the flow
 * @param onEach callback called on each emission
 * @param onCompletion callback called when flow completes. It will be provided with a non
 * nullable Throwable if it completes abnormally
 */
- (void)collectOnEach:(void (^)(T _Nullable))onEach onCompletion:(void (^)(OICCKotlinThrowable * _Nullable))onCompletion __attribute__((swift_name("collect(onEach:onCompletion:)")));
@end

__attribute__((swift_name("Preferences")))
@protocol OICCPreferences
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)clearWithCompletionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("clear(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getKey:(NSString *)key completionHandler:(void (^)(NSString * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("get(key:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)putKey:(NSString *)key value:(NSString *)value completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("put(key:value:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)removeKey:(NSString *)key completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("remove(key:completionHandler:)")));
@end


/**
 * Concurrency-safe Token Store implementations.
 *
 * Android Implementation: [org.publicvalue.multiplatform.oidc.tokenstore.AndroidSettingsTokenStore]
 * iOS implementation: [KeychainTokenStore]
 */
@interface TokenStoreProtocol : OICCBase

/**
 * Concurrency-safe Token Store implementations.
 *
 * Android Implementation: [org.publicvalue.multiplatform.oidc.tokenstore.AndroidSettingsTokenStore]
 * iOS implementation: [KeychainTokenStore]
 */
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));

/**
 * Concurrency-safe Token Store implementations.
 *
 * Android Implementation: [org.publicvalue.multiplatform.oidc.tokenstore.AndroidSettingsTokenStore]
 * iOS implementation: [KeychainTokenStore]
 */
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getAccessTokenWithCompletionHandler:(void (^)(NSString * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("getAccessToken(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getIdTokenWithCompletionHandler:(void (^)(NSString * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("getIdToken(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getRefreshTokenWithCompletionHandler:(void (^)(NSString * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("getRefreshToken(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getTokenResponseWithCompletionHandler:(void (^)(AccessTokenResponse * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("getTokenResponse(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)removeTokensWithCompletionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("removeTokens(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)saveTokensTokens:(AccessTokenResponse *)tokens completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("saveTokens(tokens:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)saveTokensAccessToken:(NSString *)accessToken refreshToken:(NSString * _Nullable)refreshToken idToken:(NSString * _Nullable)idToken completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("saveTokens(accessToken:refreshToken:idToken:completionHandler:)")));
@property (readonly) id<OICCKotlinx_coroutines_coreFlow> accessTokenFlow __attribute__((swift_name("accessTokenFlow"))) __attribute__((deprecated("Use tokenResponseFlow instead")));
@property (readonly) id<OICCKotlinx_coroutines_coreFlow> idTokenFlow __attribute__((swift_name("idTokenFlow"))) __attribute__((deprecated("Use tokenResponseFlow instead")));
@property (readonly) id<OICCKotlinx_coroutines_coreFlow> refreshTokenFlow __attribute__((swift_name("refreshTokenFlow"))) __attribute__((deprecated("Use tokenResponseFlow instead")));
@property (readonly) id<OICCKotlinx_coroutines_coreFlow> tokenResponseFlow __attribute__((swift_name("tokenResponseFlow")));
@end


/**
 * Android Implementation: [org.publicvalue.multiplatform.oidc.tokenstore.AndroidSettingsTokenStore]
 * iOS implementation: [KeychainTokenStore]
 */
__attribute__((swift_name("SettingsTokenStore")))
@interface OICCSettingsTokenStore : TokenStoreProtocol
- (instancetype)initWithSettings:(id)settings __attribute__((swift_name("init(settings:)"))) __attribute__((objc_designated_initializer));

/**
 * Concurrency-safe Token Store implementations.
 *
 * Android Implementation: [org.publicvalue.multiplatform.oidc.tokenstore.AndroidSettingsTokenStore]
 * iOS implementation: [KeychainTokenStore]
 */
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getAccessTokenWithCompletionHandler:(void (^)(NSString * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("getAccessToken(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getIdTokenWithCompletionHandler:(void (^)(NSString * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("getIdToken(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getRefreshTokenWithCompletionHandler:(void (^)(NSString * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("getRefreshToken(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getTokenResponseWithCompletionHandler:(void (^)(AccessTokenResponse * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("getTokenResponse(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)removeTokensWithCompletionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("removeTokens(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)saveTokensTokens:(AccessTokenResponse *)tokens completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("saveTokens(tokens:completionHandler:)")));
@property (readonly) id<OICCKotlinx_coroutines_coreFlow> accessTokenFlow __attribute__((swift_name("accessTokenFlow"))) __attribute__((deprecated("Use tokenResponseFlow instead")));
@property (readonly) id<OICCKotlinx_coroutines_coreFlow> idTokenFlow __attribute__((swift_name("idTokenFlow"))) __attribute__((deprecated("Use tokenResponseFlow instead")));
@property (readonly) id<OICCKotlinx_coroutines_coreFlow> refreshTokenFlow __attribute__((swift_name("refreshTokenFlow"))) __attribute__((deprecated("Use tokenResponseFlow instead")));
@property (readonly) id<OICCKotlinx_coroutines_coreFlow> tokenResponseFlow __attribute__((swift_name("tokenResponseFlow")));
@end


/**
 * Uses the keychain to save and retrieve tokens.
 */
__attribute__((objc_subclassing_restricted))
@interface KeychainTokenStore : OICCSettingsTokenStore

/**
 * Uses the keychain to save and retrieve tokens.
 */
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));

/**
 * Uses the keychain to save and retrieve tokens.
 */
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithSettings:(id)settings __attribute__((swift_name("init(settings:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("OauthTokens")))
@interface OICCOauthTokens : OICCBase
- (instancetype)initWithAccessToken:(NSString *)accessToken refreshToken:(NSString * _Nullable)refreshToken idToken:(NSString * _Nullable)idToken __attribute__((swift_name("init(accessToken:refreshToken:idToken:)"))) __attribute__((objc_designated_initializer));
- (OICCOauthTokens *)doCopyAccessToken:(NSString *)accessToken refreshToken:(NSString * _Nullable)refreshToken idToken:(NSString * _Nullable)idToken __attribute__((swift_name("doCopy(accessToken:refreshToken:idToken:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *accessToken __attribute__((swift_name("accessToken")));
@property (readonly) NSString * _Nullable idToken __attribute__((swift_name("idToken")));
@property (readonly) NSString * _Nullable refreshToken __attribute__((swift_name("refreshToken")));
@end

__attribute__((swift_name("KotlinComparable")))
@protocol OICCKotlinComparable
@required
- (int32_t)compareToOther:(id _Nullable)other __attribute__((swift_name("compareTo(other:)")));
@end

__attribute__((swift_name("KotlinEnum")))
@interface OICCKotlinEnum<E> : OICCBase <OICCKotlinComparable>
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) OICCKotlinEnumCompanion *companion __attribute__((swift_name("companion")));
- (int32_t)compareToOther:(E)other __attribute__((swift_name("compareTo(other:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) int32_t ordinal __attribute__((swift_name("ordinal")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SettingsKey")))
@interface OICCSettingsKey : OICCKotlinEnum<OICCSettingsKey *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) OICCSettingsKey *accesstoken __attribute__((swift_name("accesstoken")));
@property (class, readonly) OICCSettingsKey *refreshtoken __attribute__((swift_name("refreshtoken")));
@property (class, readonly) OICCSettingsKey *idtoken __attribute__((swift_name("idtoken")));
@property (class, readonly) OICCSettingsKey *tokens __attribute__((swift_name("tokens")));
+ (OICCKotlinArray<OICCSettingsKey *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<OICCSettingsKey *> *entries __attribute__((swift_name("entries")));
@end


/**
 * Concurrency-safe Token Refresh Handler.
 */
__attribute__((objc_subclassing_restricted))
@interface TokenRefreshHandler : OICCBase
- (instancetype)initWithTokenStore:(TokenStoreProtocol *)tokenStore expirationPolicy:(OICCTokenExpirationPolicy *)expirationPolicy __attribute__((swift_name("init(tokenStore:expirationPolicy:)"))) __attribute__((objc_designated_initializer));

/**
 * Thread-safe refresh the tokens and save to store.
 * @return The new tokens
 *
 * @note This method converts instances of OpenIdConnectException, CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)refreshAndSaveTokenClient:(id<OpenIdConnectClientProtocol>)client oldAccessToken:(NSString *)oldAccessToken completionHandler:(void (^)(OICCOauthTokens * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("refreshAndSaveToken(client:oldAccessToken:completionHandler:)")));
@end


/**
 * For iOS because we cannot accept lambdas as parameters yet
 */
__attribute__((swift_name("TokenRefresher")))
@protocol OICCTokenRefresher
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)refreshTokenRefreshToken:(NSString *)refreshToken completionHandler:(void (^)(AccessTokenResponse * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("refreshToken(refreshToken:completionHandler:)")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
@interface AuthCodeRequest : OICCBase
- (instancetype)initWithUrl:(OICCKtor_httpUrl *)url config:(OpenIdConnectClientConfig *)config pkce:(PKCE *)pkce state:(NSString *)state nonce:(NSString * _Nullable)nonce __attribute__((swift_name("init(url:config:pkce:state:nonce:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) AuthCodeRequestCompanion *companion __attribute__((swift_name("companion")));
- (AuthCodeRequest *)doCopyUrl:(OICCKtor_httpUrl *)url config:(OpenIdConnectClientConfig *)config pkce:(PKCE *)pkce state:(NSString *)state nonce:(NSString * _Nullable)nonce __attribute__((swift_name("doCopy(url:config:pkce:state:nonce:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) OpenIdConnectClientConfig *config __attribute__((swift_name("config")));
@property (readonly) NSString * _Nullable nonce __attribute__((swift_name("nonce")));
@property (readonly) PKCE *pkce __attribute__((swift_name("pkce")));
@property (readonly) NSString *state __attribute__((swift_name("state")));
@property (readonly) OICCKtor_httpUrl *url __attribute__((swift_name("url")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AuthCodeRequest.Companion")))
@interface AuthCodeRequestCompanion : OICCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) AuthCodeRequestCompanion *shared __attribute__((swift_name("shared")));
- (id<OICCKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * Code Challenge Methods defined by [RFC7636: PKCE](https://datatracker.ietf.org/doc/html/rfc7636)
 */
__attribute__((objc_subclassing_restricted))
@interface CodeChallengeMethod : OICCKotlinEnum<CodeChallengeMethod *>
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Code Challenge Methods defined by [RFC7636: PKCE](https://datatracker.ietf.org/doc/html/rfc7636)
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) CodeChallengeMethod *s256 __attribute__((swift_name("s256")));
@property (class, readonly) CodeChallengeMethod *plain __attribute__((swift_name("plain")));
@property (class, readonly) CodeChallengeMethod *off __attribute__((swift_name("off")));
+ (OICCKotlinArray<CodeChallengeMethod *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<CodeChallengeMethod *> *entries __attribute__((swift_name("entries")));
@property (readonly) NSString * _Nullable queryString __attribute__((swift_name("queryString")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
@interface EndSessionRequest : OICCBase
- (instancetype)initWithUrl:(OICCKtor_httpUrl *)url __attribute__((swift_name("init(url:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) EndSessionRequestCompanion *companion __attribute__((swift_name("companion")));
- (EndSessionRequest *)doCopyUrl:(OICCKtor_httpUrl *)url __attribute__((swift_name("doCopy(url:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) OICCKtor_httpUrl *url __attribute__((swift_name("url")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EndSessionRequest.Companion")))
@interface EndSessionRequestCompanion : OICCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) EndSessionRequestCompanion *shared __attribute__((swift_name("shared")));
- (id<OICCKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * https://openid.net/specs/openid-connect-core-1_0.html#IDToken
 */
__attribute__((objc_subclassing_restricted))
@interface IdToken : OICCBase
- (instancetype)initWithIss:(NSString * _Nullable)iss sub:(NSString * _Nullable)sub aud:(NSArray<NSString *> * _Nullable)aud exp:(OICCLong * _Nullable)exp iat:(OICCLong * _Nullable)iat auth_time:(OICCLong * _Nullable)auth_time nonce:(NSString * _Nullable)nonce acr:(NSString * _Nullable)acr amr:(NSArray<NSString *> * _Nullable)amr azp:(NSString * _Nullable)azp alg:(NSString * _Nullable)alg kid:(NSString * _Nullable)kid at_hash:(NSString * _Nullable)at_hash additionalClaims:(NSDictionary<NSString *, id> *)additionalClaims __attribute__((swift_name("init(iss:sub:aud:exp:iat:auth_time:nonce:acr:amr:azp:alg:kid:at_hash:additionalClaims:)"))) __attribute__((objc_designated_initializer));
- (IdToken *)doCopyIss:(NSString * _Nullable)iss sub:(NSString * _Nullable)sub aud:(NSArray<NSString *> * _Nullable)aud exp:(OICCLong * _Nullable)exp iat:(OICCLong * _Nullable)iat auth_time:(OICCLong * _Nullable)auth_time nonce:(NSString * _Nullable)nonce acr:(NSString * _Nullable)acr amr:(NSArray<NSString *> * _Nullable)amr azp:(NSString * _Nullable)azp alg:(NSString * _Nullable)alg kid:(NSString * _Nullable)kid at_hash:(NSString * _Nullable)at_hash additionalClaims:(NSDictionary<NSString *, id> *)additionalClaims __attribute__((swift_name("doCopy(iss:sub:aud:exp:iat:auth_time:nonce:acr:amr:azp:alg:kid:at_hash:additionalClaims:)")));

/**
 * https://openid.net/specs/openid-connect-core-1_0.html#IDToken
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * https://openid.net/specs/openid-connect-core-1_0.html#IDToken
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * https://openid.net/specs/openid-connect-core-1_0.html#IDToken
 */
- (NSString *)description __attribute__((swift_name("description()")));

/** Optional: Authentication Context Class Reference **/
@property (readonly) NSString * _Nullable acr __attribute__((swift_name("acr")));
@property (readonly) NSDictionary<NSString *, id> *additionalClaims __attribute__((swift_name("additionalClaims")));
@property (readonly) NSString * _Nullable alg __attribute__((swift_name("alg")));

/** Optional: Authentication Methods References**/
@property (readonly) NSArray<NSString *> * _Nullable amr __attribute__((swift_name("amr")));

/** Optional: Access Token hash **/
@property (readonly) NSString * _Nullable at_hash __attribute__((swift_name("at_hash")));

/** Required: Audience (must contain client_id) **/
@property (readonly) NSArray<NSString *> * _Nullable aud __attribute__((swift_name("aud")));

/** Optional time of user auth **/
@property (readonly) OICCLong * _Nullable auth_time __attribute__((swift_name("auth_time")));

/** Optional: Authorized Party **/
@property (readonly) NSString * _Nullable azp __attribute__((swift_name("azp")));

/** Required: Expiration time **/
@property (readonly) OICCLong * _Nullable exp __attribute__((swift_name("exp")));

/** Required: Issued at **/
@property (readonly) OICCLong * _Nullable iat __attribute__((swift_name("iat")));

/** Required: Issuer (must match the discovery document) **/
@property (readonly) NSString * _Nullable iss __attribute__((swift_name("iss")));
@property (readonly) NSString * _Nullable kid __attribute__((swift_name("kid")));

/** Optional, if present, must match request nonce **/
@property (readonly) NSString * _Nullable nonce __attribute__((swift_name("nonce")));

/** Required: Subject identifier **/
@property (readonly) NSString * _Nullable sub __attribute__((swift_name("sub")));
@end

__attribute__((objc_subclassing_restricted))
@interface Jwt : OICCBase
- (instancetype)initWithHeader:(JwtHeader *)header payload:(IdToken *)payload signature:(NSString * _Nullable)signature __attribute__((swift_name("init(header:payload:signature:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) JwtCompanion *companion __attribute__((swift_name("companion")));
- (Jwt *)doCopyHeader:(JwtHeader *)header payload:(IdToken *)payload signature:(NSString * _Nullable)signature __attribute__((swift_name("doCopy(header:payload:signature:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) JwtHeader *header __attribute__((swift_name("header")));
@property (readonly) IdToken *payload __attribute__((swift_name("payload")));
@property (readonly) NSString * _Nullable signature __attribute__((swift_name("signature")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Jwt.Companion")))
@interface JwtCompanion : OICCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) JwtCompanion *shared __attribute__((swift_name("shared")));
@end


/**
 * https://datatracker.ietf.org/doc/html/rfc7515#section-4.1
 *
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
@interface JwtHeader : OICCBase
- (instancetype)initWithAlg:(NSString *)alg jku:(NSString * _Nullable)jku jwk:(NSString * _Nullable)jwk kid:(NSString * _Nullable)kid x5u:(NSString * _Nullable)x5u x5c:(NSString * _Nullable)x5c x5t:(NSString * _Nullable)x5t x5tS256:(NSString * _Nullable)x5tS256 typ:(NSString * _Nullable)typ cty:(NSString * _Nullable)cty crit:(NSString * _Nullable)crit __attribute__((swift_name("init(alg:jku:jwk:kid:x5u:x5c:x5t:x5tS256:typ:cty:crit:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) JwtHeaderCompanion *companion __attribute__((swift_name("companion")));
- (JwtHeader *)doCopyAlg:(NSString *)alg jku:(NSString * _Nullable)jku jwk:(NSString * _Nullable)jwk kid:(NSString * _Nullable)kid x5u:(NSString * _Nullable)x5u x5c:(NSString * _Nullable)x5c x5t:(NSString * _Nullable)x5t x5tS256:(NSString * _Nullable)x5tS256 typ:(NSString * _Nullable)typ cty:(NSString * _Nullable)cty crit:(NSString * _Nullable)crit __attribute__((swift_name("doCopy(alg:jku:jwk:kid:x5u:x5c:x5t:x5tS256:typ:cty:crit:)")));

/**
 * https://datatracker.ietf.org/doc/html/rfc7515#section-4.1
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * https://datatracker.ietf.org/doc/html/rfc7515#section-4.1
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * https://datatracker.ietf.org/doc/html/rfc7515#section-4.1
 */
- (NSString *)description __attribute__((swift_name("description()")));

/** Required: Algorithm. Possible values: https://datatracker.ietf.org/doc/html/rfc7518#section-3.1 **/
@property (readonly) NSString *alg __attribute__((swift_name("alg")));
@property (readonly) NSString * _Nullable crit __attribute__((swift_name("crit")));
@property (readonly) NSString * _Nullable cty __attribute__((swift_name("cty")));
@property (readonly) NSString * _Nullable jku __attribute__((swift_name("jku")));
@property (readonly) NSString * _Nullable jwk __attribute__((swift_name("jwk")));
@property (readonly) NSString * _Nullable kid __attribute__((swift_name("kid")));
@property (readonly) NSString * _Nullable typ __attribute__((swift_name("typ")));
@property (readonly) NSString * _Nullable x5c __attribute__((swift_name("x5c")));
@property (readonly) NSString * _Nullable x5t __attribute__((swift_name("x5t")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="x5t#S256")
*/
@property (readonly) NSString * _Nullable x5tS256 __attribute__((swift_name("x5tS256")));
@property (readonly) NSString * _Nullable x5u __attribute__((swift_name("x5u")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("JwtHeader.Companion")))
@interface JwtHeaderCompanion : OICCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) JwtHeaderCompanion *shared __attribute__((swift_name("shared")));
- (JwtHeader *)parseString:(NSString *)string __attribute__((swift_name("parse(string:)")));
- (id<OICCKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end

__attribute__((objc_subclassing_restricted))
@interface JwtParser : OICCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)jwtParser __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) JwtParser *shared __attribute__((swift_name("shared")));

/**
 * Objective-C convenience function
 * @see Jwt.parse
 *
 * @note This method converts instances of OpenIdConnectException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (Jwt * _Nullable)parseFrom:(NSString *)from error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("parse(from:)")));
@end

__attribute__((objc_subclassing_restricted))
@interface TokenRequest : OICCBase
- (instancetype)initWithRequest:(OICCKtor_client_coreHttpStatement *)request formParameters:(id<OICCKtor_httpParameters>)formParameters __attribute__((swift_name("init(request:formParameters:)"))) __attribute__((objc_designated_initializer));
- (TokenRequest *)doCopyRequest:(OICCKtor_client_coreHttpStatement *)request formParameters:(id<OICCKtor_httpParameters>)formParameters __attribute__((swift_name("doCopy(request:formParameters:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id<OICCKtor_httpParameters> formParameters __attribute__((swift_name("formParameters")));
@property (readonly) OICCKtor_client_coreHttpStatement *request __attribute__((swift_name("request")));
@end


/**
 * Access Token Response expected from token endpoint.
 *
 * [https://openid.net/specs/openid-connect-core-1_0.html#TokenResponse](https://openid.net/specs/openid-connect-core-1_0.html#TokenResponse)
 * [https://datatracker.ietf.org/doc/html/rfc6749#section-5.1](https://datatracker.ietf.org/doc/html/rfc6749#section-5.1)
 *
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
@interface AccessTokenResponse : OICCBase
- (instancetype)initWithAccess_token:(NSString *)access_token token_type:(NSString * _Nullable)token_type expires_in:(OICCInt * _Nullable)expires_in refresh_token:(NSString * _Nullable)refresh_token refresh_token_expires_in:(OICCInt * _Nullable)refresh_token_expires_in refresh_expires_in:(OICCInt * _Nullable)refresh_expires_in id_token:(NSString * _Nullable)id_token scope:(NSString * _Nullable)scope received_at:(int64_t)received_at __attribute__((swift_name("init(access_token:token_type:expires_in:refresh_token:refresh_token_expires_in:refresh_expires_in:id_token:scope:received_at:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) AccessTokenResponseCompanion *companion __attribute__((swift_name("companion")));
- (AccessTokenResponse *)doCopyAccess_token:(NSString *)access_token token_type:(NSString * _Nullable)token_type expires_in:(OICCInt * _Nullable)expires_in refresh_token:(NSString * _Nullable)refresh_token refresh_token_expires_in:(OICCInt * _Nullable)refresh_token_expires_in refresh_expires_in:(OICCInt * _Nullable)refresh_expires_in id_token:(NSString * _Nullable)id_token scope:(NSString * _Nullable)scope received_at:(int64_t)received_at __attribute__((swift_name("doCopy(access_token:token_type:expires_in:refresh_token:refresh_token_expires_in:refresh_expires_in:id_token:scope:received_at:)")));

/**
 * Access Token Response expected from token endpoint.
 *
 * [https://openid.net/specs/openid-connect-core-1_0.html#TokenResponse](https://openid.net/specs/openid-connect-core-1_0.html#TokenResponse)
 * [https://datatracker.ietf.org/doc/html/rfc6749#section-5.1](https://datatracker.ietf.org/doc/html/rfc6749#section-5.1)
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * Access Token Response expected from token endpoint.
 *
 * [https://openid.net/specs/openid-connect-core-1_0.html#TokenResponse](https://openid.net/specs/openid-connect-core-1_0.html#TokenResponse)
 * [https://datatracker.ietf.org/doc/html/rfc6749#section-5.1](https://datatracker.ietf.org/doc/html/rfc6749#section-5.1)
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * Access Token Response expected from token endpoint.
 *
 * [https://openid.net/specs/openid-connect-core-1_0.html#TokenResponse](https://openid.net/specs/openid-connect-core-1_0.html#TokenResponse)
 * [https://datatracker.ietf.org/doc/html/rfc6749#section-5.1](https://datatracker.ietf.org/doc/html/rfc6749#section-5.1)
 */
- (NSString *)description __attribute__((swift_name("description()")));

/**
 * **Required**
 *
 * The access token issued by the authorization server.
 */
@property (readonly) NSString *access_token __attribute__((swift_name("access_token")));

/**
 * **Recommended**
 *
 * The lifetime in seconds of the [access_token].
 * For example, the value "3600" denotes that the access token will
 * expire in one hour from the time the response was generated.
 *
 * If omitted, the authorization server SHOULD provide the
 * expiration time via other means or document the default value.
 */
@property (readonly) OICCInt * _Nullable expires_in __attribute__((swift_name("expires_in")));

/**
 * **Required in OpenIDConnect**
 *
 * ID Token value associated with the authenticated session.
 */
@property (readonly) NSString * _Nullable id_token __attribute__((swift_name("id_token")));

/** Computed locally **/
@property (readonly) int64_t received_at __attribute__((swift_name("received_at")));

/**
 * Alternative field to refresh_token_expires_in.
 */
@property (readonly) OICCInt * _Nullable refresh_expires_in __attribute__((swift_name("refresh_expires_in")));

/**
 * **Optional**
 *
 * The refresh token, which can be used to obtain new access tokens using the same authorization grant type.
 */
@property (readonly) NSString * _Nullable refresh_token __attribute__((swift_name("refresh_token")));

/**
 * **Not specified in OAuth 2.0**
 *
 * The lifetime in seconds of the [refresh_token].
 * For example, the value "3600" denotes that the refresh token will
 * expire in one hour from the time the response was generated.
 */
@property (readonly) OICCInt * _Nullable refresh_token_expires_in __attribute__((swift_name("refresh_token_expires_in")));

/** Optional if identical to request **/
@property (readonly) NSString * _Nullable scope __attribute__((swift_name("scope")));

/**
 * **Required**
 *
 * The value MUST be _Bearer_ or another token_type value that the Client has negotiated with the Authorization Server.
 *
 * Clients implementing this profile MUST support the OAuth 2.0 Bearer Token Usage [RFC6750](https://openid.net/specs/openid-connect-core-1_0.html#RFC6750) specification.
 */
@property (readonly) NSString * _Nullable token_type __attribute__((swift_name("token_type")));
@end


/**
 * Access Token Response expected from token endpoint.
 *
 * [https://openid.net/specs/openid-connect-core-1_0.html#TokenResponse](https://openid.net/specs/openid-connect-core-1_0.html#TokenResponse)
 * [https://datatracker.ietf.org/doc/html/rfc6749#section-5.1](https://datatracker.ietf.org/doc/html/rfc6749#section-5.1)
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AccessTokenResponse.Companion")))
@interface AccessTokenResponseCompanion : OICCBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Access Token Response expected from token endpoint.
 *
 * [https://openid.net/specs/openid-connect-core-1_0.html#TokenResponse](https://openid.net/specs/openid-connect-core-1_0.html#TokenResponse)
 * [https://datatracker.ietf.org/doc/html/rfc6749#section-5.1](https://datatracker.ietf.org/doc/html/rfc6749#section-5.1)
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) AccessTokenResponseCompanion *shared __attribute__((swift_name("shared")));

/**
 * Access Token Response expected from token endpoint.
 *
 * [https://openid.net/specs/openid-connect-core-1_0.html#TokenResponse](https://openid.net/specs/openid-connect-core-1_0.html#TokenResponse)
 * [https://datatracker.ietf.org/doc/html/rfc6749#section-5.1](https://datatracker.ietf.org/doc/html/rfc6749#section-5.1)
 */
- (id<OICCKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * ErrorResponse expected from Authorization or Token endpoint.
 * [RFC6749](https://datatracker.ietf.org/doc/html/rfc6749#section-4.1.2.1)
 * [RFC6749](https://datatracker.ietf.org/doc/html/rfc6749#section-5.2)
 *
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
@interface OpenIdConnectErrorResponse : OICCBase
- (instancetype)initWithError:(OpenIdConnectErrorResponseError *)error error_description:(NSString * _Nullable)error_description error_uri:(NSString * _Nullable)error_uri state:(NSString * _Nullable)state __attribute__((swift_name("init(error:error_description:error_uri:state:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) OpenIdConnectErrorResponseCompanion *companion __attribute__((swift_name("companion")));
- (OpenIdConnectErrorResponse *)doCopyError:(OpenIdConnectErrorResponseError *)error error_description:(NSString * _Nullable)error_description error_uri:(NSString * _Nullable)error_uri state:(NSString * _Nullable)state __attribute__((swift_name("doCopy(error:error_description:error_uri:state:)")));

/**
 * ErrorResponse expected from Authorization or Token endpoint.
 * [RFC6749](https://datatracker.ietf.org/doc/html/rfc6749#section-4.1.2.1)
 * [RFC6749](https://datatracker.ietf.org/doc/html/rfc6749#section-5.2)
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * ErrorResponse expected from Authorization or Token endpoint.
 * [RFC6749](https://datatracker.ietf.org/doc/html/rfc6749#section-4.1.2.1)
 * [RFC6749](https://datatracker.ietf.org/doc/html/rfc6749#section-5.2)
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * ErrorResponse expected from Authorization or Token endpoint.
 * [RFC6749](https://datatracker.ietf.org/doc/html/rfc6749#section-4.1.2.1)
 * [RFC6749](https://datatracker.ietf.org/doc/html/rfc6749#section-5.2)
 */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) OpenIdConnectErrorResponseError *error __attribute__((swift_name("error")));
@property (readonly) NSString * _Nullable error_description __attribute__((swift_name("error_description")));
@property (readonly) NSString * _Nullable error_uri __attribute__((swift_name("error_uri")));
@property (readonly) NSString * _Nullable state __attribute__((swift_name("state")));
@end


/**
 * ErrorResponse expected from Authorization or Token endpoint.
 * [RFC6749](https://datatracker.ietf.org/doc/html/rfc6749#section-4.1.2.1)
 * [RFC6749](https://datatracker.ietf.org/doc/html/rfc6749#section-5.2)
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("OpenIdConnectErrorResponse.Companion")))
@interface OpenIdConnectErrorResponseCompanion : OICCBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * ErrorResponse expected from Authorization or Token endpoint.
 * [RFC6749](https://datatracker.ietf.org/doc/html/rfc6749#section-4.1.2.1)
 * [RFC6749](https://datatracker.ietf.org/doc/html/rfc6749#section-5.2)
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) OpenIdConnectErrorResponseCompanion *shared __attribute__((swift_name("shared")));

/**
 * ErrorResponse expected from Authorization or Token endpoint.
 * [RFC6749](https://datatracker.ietf.org/doc/html/rfc6749#section-4.1.2.1)
 * [RFC6749](https://datatracker.ietf.org/doc/html/rfc6749#section-5.2)
 */
- (id<OICCKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("OpenIdConnectErrorResponse.Error")))
@interface OpenIdConnectErrorResponseError : OICCKotlinEnum<OpenIdConnectErrorResponseError *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) OpenIdConnectErrorResponseErrorCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) OpenIdConnectErrorResponseError *invalidClient __attribute__((swift_name("invalidClient")));
@property (class, readonly) OpenIdConnectErrorResponseError *invalidGrant __attribute__((swift_name("invalidGrant")));
@property (class, readonly) OpenIdConnectErrorResponseError *badVerificationCode __attribute__((swift_name("badVerificationCode")));
@property (class, readonly) OpenIdConnectErrorResponseError *invalidRequest __attribute__((swift_name("invalidRequest")));
@property (class, readonly) OpenIdConnectErrorResponseError *unauthorizedClient __attribute__((swift_name("unauthorizedClient")));
@property (class, readonly) OpenIdConnectErrorResponseError *unsupportedGrantType __attribute__((swift_name("unsupportedGrantType")));
@property (class, readonly) OpenIdConnectErrorResponseError *accessDenied __attribute__((swift_name("accessDenied")));
@property (class, readonly) OpenIdConnectErrorResponseError *unsupportedResponseType __attribute__((swift_name("unsupportedResponseType")));
@property (class, readonly) OpenIdConnectErrorResponseError *invalidScope __attribute__((swift_name("invalidScope")));
@property (class, readonly) OpenIdConnectErrorResponseError *serverError __attribute__((swift_name("serverError")));
@property (class, readonly) OpenIdConnectErrorResponseError *temporarilyUnavailable __attribute__((swift_name("temporarilyUnavailable")));
+ (OICCKotlinArray<OpenIdConnectErrorResponseError *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<OpenIdConnectErrorResponseError *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("OpenIdConnectErrorResponse.ErrorCompanion")))
@interface OpenIdConnectErrorResponseErrorCompanion : OICCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) OpenIdConnectErrorResponseErrorCompanion *shared __attribute__((swift_name("shared")));
- (id<OICCKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
- (id<OICCKotlinx_serialization_coreKSerializer>)serializerTypeParamsSerializers:(OICCKotlinArray<id<OICCKotlinx_serialization_coreKSerializer>> *)typeParamsSerializers __attribute__((swift_name("serializer(typeParamsSerializers:)")));
@property (readonly) NSArray<OpenIdConnectErrorResponseError *> *authorizationErrors __attribute__((swift_name("authorizationErrors")));
@property (readonly) NSArray<OpenIdConnectErrorResponseError *> *tokenErrors __attribute__((swift_name("tokenErrors")));
@end


/**
 * Openid-configuration JSON expected from discovery endpoint
 *
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("OpenIdConnectConfiguration")))
@interface OICCOpenIdConnectConfiguration : OICCBase
- (instancetype)initWithAuthorization_endpoint:(NSString * _Nullable)authorization_endpoint token_endpoint:(NSString * _Nullable)token_endpoint device_authorization_endpoint:(NSString * _Nullable)device_authorization_endpoint userinfo_endpoint:(NSString * _Nullable)userinfo_endpoint end_session_endpoint:(NSString * _Nullable)end_session_endpoint introspection_endpoint:(NSString * _Nullable)introspection_endpoint revocation_endpoint:(NSString * _Nullable)revocation_endpoint issuer:(NSString * _Nullable)issuer jwks_uri:(NSString * _Nullable)jwks_uri response_types_supported:(NSArray<NSString *> * _Nullable)response_types_supported id_token_signing_alg_values_supported:(NSArray<NSString *> * _Nullable)id_token_signing_alg_values_supported frontchannel_logout_supported:(OICCBoolean * _Nullable)frontchannel_logout_supported scopes_supported:(NSArray<NSString *> * _Nullable)scopes_supported claims_supported:(NSArray<NSString *> * _Nullable)claims_supported subject_types_supported:(NSArray<NSString *> * _Nullable)subject_types_supported token_endpoint_auth_methods_supported:(NSArray<NSString *> * _Nullable)token_endpoint_auth_methods_supported grant_types_supported:(NSArray<NSString *> * _Nullable)grant_types_supported introspection_endpoint_auth_methods_supported:(NSArray<NSString *> * _Nullable)introspection_endpoint_auth_methods_supported __attribute__((swift_name("init(authorization_endpoint:token_endpoint:device_authorization_endpoint:userinfo_endpoint:end_session_endpoint:introspection_endpoint:revocation_endpoint:issuer:jwks_uri:response_types_supported:id_token_signing_alg_values_supported:frontchannel_logout_supported:scopes_supported:claims_supported:subject_types_supported:token_endpoint_auth_methods_supported:grant_types_supported:introspection_endpoint_auth_methods_supported:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) OICCOpenIdConnectConfigurationCompanion *companion __attribute__((swift_name("companion")));
- (OICCOpenIdConnectConfiguration *)doCopyAuthorization_endpoint:(NSString * _Nullable)authorization_endpoint token_endpoint:(NSString * _Nullable)token_endpoint device_authorization_endpoint:(NSString * _Nullable)device_authorization_endpoint userinfo_endpoint:(NSString * _Nullable)userinfo_endpoint end_session_endpoint:(NSString * _Nullable)end_session_endpoint introspection_endpoint:(NSString * _Nullable)introspection_endpoint revocation_endpoint:(NSString * _Nullable)revocation_endpoint issuer:(NSString * _Nullable)issuer jwks_uri:(NSString * _Nullable)jwks_uri response_types_supported:(NSArray<NSString *> * _Nullable)response_types_supported id_token_signing_alg_values_supported:(NSArray<NSString *> * _Nullable)id_token_signing_alg_values_supported frontchannel_logout_supported:(OICCBoolean * _Nullable)frontchannel_logout_supported scopes_supported:(NSArray<NSString *> * _Nullable)scopes_supported claims_supported:(NSArray<NSString *> * _Nullable)claims_supported subject_types_supported:(NSArray<NSString *> * _Nullable)subject_types_supported token_endpoint_auth_methods_supported:(NSArray<NSString *> * _Nullable)token_endpoint_auth_methods_supported grant_types_supported:(NSArray<NSString *> * _Nullable)grant_types_supported introspection_endpoint_auth_methods_supported:(NSArray<NSString *> * _Nullable)introspection_endpoint_auth_methods_supported __attribute__((swift_name("doCopy(authorization_endpoint:token_endpoint:device_authorization_endpoint:userinfo_endpoint:end_session_endpoint:introspection_endpoint:revocation_endpoint:issuer:jwks_uri:response_types_supported:id_token_signing_alg_values_supported:frontchannel_logout_supported:scopes_supported:claims_supported:subject_types_supported:token_endpoint_auth_methods_supported:grant_types_supported:introspection_endpoint_auth_methods_supported:)")));

/**
 * Openid-configuration JSON expected from discovery endpoint
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * Openid-configuration JSON expected from discovery endpoint
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * Openid-configuration JSON expected from discovery endpoint
 */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable authorization_endpoint __attribute__((swift_name("authorization_endpoint")));
@property (readonly) NSArray<NSString *> * _Nullable claims_supported __attribute__((swift_name("claims_supported")));
@property (readonly) NSString * _Nullable device_authorization_endpoint __attribute__((swift_name("device_authorization_endpoint")));
@property (readonly) NSString * _Nullable end_session_endpoint __attribute__((swift_name("end_session_endpoint")));
@property (readonly) OICCBoolean * _Nullable frontchannel_logout_supported __attribute__((swift_name("frontchannel_logout_supported")));
@property (readonly) NSArray<NSString *> * _Nullable grant_types_supported __attribute__((swift_name("grant_types_supported")));
@property (readonly) NSArray<NSString *> * _Nullable id_token_signing_alg_values_supported __attribute__((swift_name("id_token_signing_alg_values_supported")));
@property (readonly) NSString * _Nullable introspection_endpoint __attribute__((swift_name("introspection_endpoint")));
@property (readonly) NSArray<NSString *> * _Nullable introspection_endpoint_auth_methods_supported __attribute__((swift_name("introspection_endpoint_auth_methods_supported")));
@property (readonly) NSString * _Nullable issuer __attribute__((swift_name("issuer")));
@property (readonly) NSString * _Nullable jwks_uri __attribute__((swift_name("jwks_uri")));
@property (readonly) NSArray<NSString *> * _Nullable response_types_supported __attribute__((swift_name("response_types_supported")));
@property (readonly) NSString * _Nullable revocation_endpoint __attribute__((swift_name("revocation_endpoint")));
@property (readonly) NSArray<NSString *> * _Nullable scopes_supported __attribute__((swift_name("scopes_supported")));
@property (readonly) NSArray<NSString *> * _Nullable subject_types_supported __attribute__((swift_name("subject_types_supported")));
@property (readonly) NSString * _Nullable token_endpoint __attribute__((swift_name("token_endpoint")));
@property (readonly) NSArray<NSString *> * _Nullable token_endpoint_auth_methods_supported __attribute__((swift_name("token_endpoint_auth_methods_supported")));
@property (readonly) NSString * _Nullable userinfo_endpoint __attribute__((swift_name("userinfo_endpoint")));
@end


/**
 * Openid-configuration JSON expected from discovery endpoint
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("OpenIdConnectConfiguration.Companion")))
@interface OICCOpenIdConnectConfigurationCompanion : OICCBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Openid-configuration JSON expected from discovery endpoint
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) OICCOpenIdConnectConfigurationCompanion *shared __attribute__((swift_name("shared")));

/**
 * Openid-configuration JSON expected from discovery endpoint
 */
- (id<OICCKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TokenExpirationPolicy")))
@interface OICCTokenExpirationPolicy : OICCBase
- (instancetype)initWithExpiryTimeTolerance:(int64_t)expiryTimeTolerance __attribute__((swift_name("init(expiryTimeTolerance:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) OICCTokenExpirationPolicyCompanion *companion __attribute__((swift_name("companion")));

/**
 * Tokens with less this duration left before expiration are considered expired.
 */
@property (readonly) int64_t expiryTimeTolerance __attribute__((swift_name("expiryTimeTolerance")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TokenExpirationPolicy.Companion")))
@interface OICCTokenExpirationPolicyCompanion : OICCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) OICCTokenExpirationPolicyCompanion *shared __attribute__((swift_name("shared")));
@end


/**
 * A mutable [HttpClient] configuration used to adjust settings, install plugins and interceptors.
 *
 * This configuration can be provided as a lambda in the [HttpClient] constructor or the [HttpClient.config] builder:
 * ```kotlin
 * val client = HttpClient { // HttpClientConfig<Engine>()
 *     // Configure engine settings
 *     engine { // HttpClientEngineConfig
 *         threadsCount = 4
 *         pipelining = true
 *     }
 *
 *     // Install and configure plugins
 *     install(ContentNegotiation) {
 *         json()
 *     }
 *
 *     // Configure default request parameters
 *     defaultRequest {
 *         url("https://api.example.com")
 *         header("X-Custom-Header", "value")
 *     }
 *
 *     // Configure client-wide settings
 *     expectSuccess = true
 *     followRedirects = true
 * }
 * ```
 * ## Configuring [HttpClientEngine]
 *
 * If the engine is specified explicitly, engine-specific properties will be available in the `engine` block:
 * ```kotlin
 * val client = HttpClient(CIO) { // HttpClientConfig<CIOEngineConfig>.() -> Unit
 *     engine { // CIOEngineConfig.() -> Unit
 *         // engine specific properties
 *     }
 * }
 * ```
 *
 * Learn more about the client's configuration from
 * [Creating and configuring a client](https://ktor.io/docs/create-client.html).
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.HttpClientConfig)
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpClientConfig")))
@interface OICCKtor_client_coreHttpClientConfig<T> : OICCBase

/**
 * A mutable [HttpClient] configuration used to adjust settings, install plugins and interceptors.
 *
 * This configuration can be provided as a lambda in the [HttpClient] constructor or the [HttpClient.config] builder:
 * ```kotlin
 * val client = HttpClient { // HttpClientConfig<Engine>()
 *     // Configure engine settings
 *     engine { // HttpClientEngineConfig
 *         threadsCount = 4
 *         pipelining = true
 *     }
 *
 *     // Install and configure plugins
 *     install(ContentNegotiation) {
 *         json()
 *     }
 *
 *     // Configure default request parameters
 *     defaultRequest {
 *         url("https://api.example.com")
 *         header("X-Custom-Header", "value")
 *     }
 *
 *     // Configure client-wide settings
 *     expectSuccess = true
 *     followRedirects = true
 * }
 * ```
 * ## Configuring [HttpClientEngine]
 *
 * If the engine is specified explicitly, engine-specific properties will be available in the `engine` block:
 * ```kotlin
 * val client = HttpClient(CIO) { // HttpClientConfig<CIOEngineConfig>.() -> Unit
 *     engine { // CIOEngineConfig.() -> Unit
 *         // engine specific properties
 *     }
 * }
 * ```
 *
 * Learn more about the client's configuration from
 * [Creating and configuring a client](https://ktor.io/docs/create-client.html).
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.HttpClientConfig)
 */
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));

/**
 * A mutable [HttpClient] configuration used to adjust settings, install plugins and interceptors.
 *
 * This configuration can be provided as a lambda in the [HttpClient] constructor or the [HttpClient.config] builder:
 * ```kotlin
 * val client = HttpClient { // HttpClientConfig<Engine>()
 *     // Configure engine settings
 *     engine { // HttpClientEngineConfig
 *         threadsCount = 4
 *         pipelining = true
 *     }
 *
 *     // Install and configure plugins
 *     install(ContentNegotiation) {
 *         json()
 *     }
 *
 *     // Configure default request parameters
 *     defaultRequest {
 *         url("https://api.example.com")
 *         header("X-Custom-Header", "value")
 *     }
 *
 *     // Configure client-wide settings
 *     expectSuccess = true
 *     followRedirects = true
 * }
 * ```
 * ## Configuring [HttpClientEngine]
 *
 * If the engine is specified explicitly, engine-specific properties will be available in the `engine` block:
 * ```kotlin
 * val client = HttpClient(CIO) { // HttpClientConfig<CIOEngineConfig>.() -> Unit
 *     engine { // CIOEngineConfig.() -> Unit
 *         // engine specific properties
 *     }
 * }
 * ```
 *
 * Learn more about the client's configuration from
 * [Creating and configuring a client](https://ktor.io/docs/create-client.html).
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.HttpClientConfig)
 */
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));

/**
 * Clones this [HttpClientConfig] by duplicating all the [plugins] and [customInterceptors].
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.HttpClientConfig.clone)
 */
- (OICCKtor_client_coreHttpClientConfig<T> *)clone __attribute__((swift_name("clone()")));

/**
 * A builder for configuring engine-specific settings in [HttpClientEngineConfig],
 * such as dispatcher, thread count, proxy, and more.
 *
 * ```kotlin
 * val client = HttpClient(CIO) { // HttpClientConfig<CIOEngineConfig>
 *     engine { // CIOEngineConfig.() -> Unit
 *         proxy = ProxyBuilder.http("proxy.example.com", 8080)
 *     }
 * ```
 *
 * You can learn more from [Engines](https://ktor.io/docs/http-client-engines.html).
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.HttpClientConfig.engine)
 */
- (void)engineBlock:(void (^)(T))block __attribute__((swift_name("engine(block:)")));

/**
 * Applies all the installed [plugins] and [customInterceptors] from this configuration
 * into the specified [client].
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.HttpClientConfig.install)
 */
- (void)installClient:(OICCKtor_client_coreHttpClient *)client __attribute__((swift_name("install(client:)")));

/**
 * Installs the specified [plugin] and optionally configures it using the [configure] block.
 *
 * ```kotlin
 * val client = HttpClient {
 *     install(ContentNegotiation) {
 *         // configuration block
 *         json()
 *     }
 * }
 * ```
 *
 * If the plugin is already installed, the configuration block will be applied to the existing configuration class.
 *
 * Learn more from [Plugins](https://ktor.io/docs/http-client-plugins.html).
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.HttpClientConfig.install)
 */
- (void)installPlugin:(id<OICCKtor_client_coreHttpClientPlugin>)plugin configure:(void (^)(id))configure __attribute__((swift_name("install(plugin:configure:)")));

/**
 * Installs an interceptor defined by [block].
 * The [key] parameter is used as a unique name, that also prevents installing duplicated interceptors.
 *
 * If the [key] is already used, the new interceptor will replace the old one.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.HttpClientConfig.install)
 */
- (void)installKey:(NSString *)key block:(void (^)(OICCKtor_client_coreHttpClient *))block __attribute__((swift_name("install(key:block:)")));

/**
 * Installs the plugin from the [other] client's configuration.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.HttpClientConfig.plusAssign)
 */
- (void)plusAssignOther:(OICCKtor_client_coreHttpClientConfig<T> *)other __attribute__((swift_name("plusAssign(other:)")));

/**
 * Development mode is no longer required all functionality is enabled by default. The property is safe to remove.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.HttpClientConfig.developmentMode)
 */
@property BOOL developmentMode __attribute__((swift_name("developmentMode"))) __attribute__((deprecated("Development mode is no longer required. The property will be removed in the future.")));

/**
 * Terminates [HttpClient.receivePipeline] if the status code is not successful (>=300).
 * Learn more from [Response validation](https://ktor.io/docs/response-validation.html).
 *
 * For more details, see the [HttpCallValidator] documentation.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.HttpClientConfig.expectSuccess)
 */
@property BOOL expectSuccess __attribute__((swift_name("expectSuccess")));

/**
 * Specifies whether the client redirects to URLs provided in the `Location` header.
 * You can disable redirections by setting this property to `false`.
 *
 * For an advanced redirection configuration, use the [HttpRedirect] plugin.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.HttpClientConfig.followRedirects)
 */
@property BOOL followRedirects __attribute__((swift_name("followRedirects")));

/**
 * Enables body transformations for many common types like [String], [ByteArray], [ByteReadChannel], etc.
 * These transformations are applied to the request and response bodies.
 *
 * The transformers will be used when the response body is received with a type:
 * ```kotlin
 * val client = HttpClient()
 * val bytes = client.get("https://ktor.io")
 *                   .body<ByteArray>()
 * ```
 *
 * This flag is enabled by default.
 * You might want to disable it if you want to write your own transformers or handle body manually.
 *
 * For more details, see the [defaultTransformers] documentation.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.HttpClientConfig.useDefaultTransformers)
 */
@property BOOL useDefaultTransformers __attribute__((swift_name("useDefaultTransformers")));
@end

@interface OICCKtor_client_coreHttpClientConfig (Extensions)

/**
 * Create and install a custom client plugin.
 * @suppress
 */
- (void)installClientPluginName:(NSString *)name onRequest:(void (^)(OICCKtor_client_coreHttpRequestBuilder *, id))onRequest onResponse:(void (^)(OICCKtor_client_coreHttpResponse *))onResponse onClose:(void (^)(void))onClose __attribute__((swift_name("installClientPlugin(name:onRequest:onResponse:onClose:)")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreCoroutineScope")))
@protocol OICCKotlinx_coroutines_coreCoroutineScope
@required
@property (readonly) id<OICCKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@end


/**
 * A pair of a [request] and [response] for a specific [HttpClient].
 *
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.call.HttpClientCall)
 *
 * @property client the client that executed the call.
 */
__attribute__((swift_name("Ktor_client_coreHttpClientCall")))
@interface OICCKtor_client_coreHttpClientCall : OICCBase <OICCKotlinx_coroutines_coreCoroutineScope>
- (instancetype)initWithClient:(OICCKtor_client_coreHttpClient *)client __attribute__((swift_name("init(client:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithClient:(OICCKtor_client_coreHttpClient *)client requestData:(OICCKtor_client_coreHttpRequestData *)requestData responseData:(OICCKtor_client_coreHttpResponseData *)responseData __attribute__((swift_name("init(client:requestData:responseData:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) OICCKtor_client_coreHttpClientCallCompanion *companion __attribute__((swift_name("companion")));

/**
 * Tries to receive the payload of the [response] as a specific expected type provided in [info].
 * Returns [response] if [info] corresponds to [HttpResponse].
 *
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.call.HttpClientCall.body)
 *
 * @throws NoTransformationFoundException If no transformation is found for the type [info].
 * @throws DoubleReceiveException If already called [body].
 * @throws NullPointerException If content is `null`.
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)bodyInfo:(OICCKtor_utilsTypeInfo *)info completionHandler:(void (^)(id _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("body(info:completionHandler:)")));

/**
 * Tries to receive the payload of the [response] as a specific expected type provided in [info].
 * Returns [response] if [info] corresponds to [HttpResponse].
 *
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.call.HttpClientCall.bodyNullable)
 *
 * @throws NoTransformationFoundException If no transformation is found for the type [info].
 * @throws DoubleReceiveException If already called [body].
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)bodyNullableInfo:(OICCKtor_utilsTypeInfo *)info completionHandler:(void (^)(id _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("bodyNullable(info:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)getResponseContentWithCompletionHandler:(void (^)(id<OICCKtor_ioByteReadChannel> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getResponseContent(completionHandler:)")));
- (NSString *)description __attribute__((swift_name("description()")));

/**
 * @note This property has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
@property (readonly) BOOL allowDoubleReceive __attribute__((swift_name("allowDoubleReceive")));

/**
 * Typed [Attributes] associated to this call serving as a lightweight container.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.call.HttpClientCall.attributes)
 */
@property (readonly) id<OICCKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property (readonly) OICCKtor_client_coreHttpClient *client __attribute__((swift_name("client")));
@property (readonly) id<OICCKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));

/**
 * The [request] sent by the client.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.call.HttpClientCall.request)
 */
@property id<OICCKtor_client_coreHttpRequest> request __attribute__((swift_name("request")));

/**
 * The [response] sent by the server.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.call.HttpClientCall.response)
 */
@property OICCKtor_client_coreHttpResponse *response __attribute__((swift_name("response")));
@end

@interface OICCKtor_client_coreHttpClientCall (Extensions)

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)errorBodyWithCompletionHandler:(void (^)(OpenIdConnectErrorResponse * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("errorBody(completionHandler:)")));
@end


/**
 * A message either from the client or the server,
 * that has [headers] associated.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.HttpMessage)
 */
__attribute__((swift_name("Ktor_httpHttpMessage")))
@protocol OICCKtor_httpHttpMessage
@required

/**
 * Message [Headers]
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.HttpMessage.headers)
 */
@property (readonly) id<OICCKtor_httpHeaders> headers __attribute__((swift_name("headers")));
@end


/**
 * An [HttpClient]'s response, a second part of [HttpClientCall].
 *
 * Learn more from [Receiving responses](https://ktor.io/docs/response.html).
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.statement.HttpResponse)
 */
__attribute__((swift_name("Ktor_client_coreHttpResponse")))
@interface OICCKtor_client_coreHttpResponse : OICCBase <OICCKtor_httpHttpMessage, OICCKotlinx_coroutines_coreCoroutineScope>

/**
 * An [HttpClient]'s response, a second part of [HttpClientCall].
 *
 * Learn more from [Receiving responses](https://ktor.io/docs/response.html).
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.statement.HttpResponse)
 */
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));

/**
 * An [HttpClient]'s response, a second part of [HttpClientCall].
 *
 * Learn more from [Receiving responses](https://ktor.io/docs/response.html).
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.statement.HttpResponse)
 */
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (NSString *)description __attribute__((swift_name("description()")));

/**
 * The associated [HttpClientCall] containing both
 * the underlying [HttpClientCall.request] and [HttpClientCall.response].
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.statement.HttpResponse.call)
 */
@property (readonly) OICCKtor_client_coreHttpClientCall *call __attribute__((swift_name("call")));

/**
 * Provides a raw [ByteReadChannel] to the response content as it is read from the network.
 * This content can be still compressed or encoded.
 *
 * This content doesn't go through any interceptors from [HttpResponsePipeline].
 *
 * If you need to read the content as decoded bytes, use the [bodyAsChannel] method instead.
 *
 * This property produces a new channel every time it's accessed.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.statement.HttpResponse.rawContent)
 */
@property (readonly) id<OICCKtor_ioByteReadChannel> rawContent __attribute__((swift_name("rawContent")));

/**
 * [GMTDate] of the request start.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.statement.HttpResponse.requestTime)
 */
@property (readonly) OICCKtor_utilsGMTDate *requestTime __attribute__((swift_name("requestTime")));

/**
 * [GMTDate] of the response start.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.statement.HttpResponse.responseTime)
 */
@property (readonly) OICCKtor_utilsGMTDate *responseTime __attribute__((swift_name("responseTime")));

/**
 * The [HttpStatusCode] returned by the server. It includes both,
 * the [HttpStatusCode.description] and the [HttpStatusCode.value] (code).
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.statement.HttpResponse.status)
 */
@property (readonly) OICCKtor_httpHttpStatusCode *status __attribute__((swift_name("status")));

/**
 * HTTP version. Usually [HttpProtocolVersion.HTTP_1_1] or [HttpProtocolVersion.HTTP_2_0].
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.statement.HttpResponse.version)
 */
@property (readonly) OICCKtor_httpHttpProtocolVersion *version __attribute__((swift_name("version")));
@end

@interface OICCKtor_client_coreHttpResponse (Extensions)

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)toHttpExceptionWithCompletionHandler:(void (^)(OICCHttpException * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("toHttpException(completionHandler:)")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerialFormat")))
@protocol OICCKotlinx_serialization_coreSerialFormat
@required
@property (readonly) OICCKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreStringFormat")))
@protocol OICCKotlinx_serialization_coreStringFormat <OICCKotlinx_serialization_coreSerialFormat>
@required
- (id _Nullable)decodeFromStringDeserializer:(id<OICCKotlinx_serialization_coreDeserializationStrategy>)deserializer string:(NSString *)string __attribute__((swift_name("decodeFromString(deserializer:string:)")));
- (NSString *)encodeToStringSerializer:(id<OICCKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeToString(serializer:value:)")));
@end

__attribute__((swift_name("Kotlinx_serialization_jsonJson")))
@interface OICCKotlinx_serialization_jsonJson : OICCBase <OICCKotlinx_serialization_coreStringFormat>
@property (class, readonly, getter=companion) OICCKotlinx_serialization_jsonJsonDefault *companion __attribute__((swift_name("companion")));
- (id _Nullable)decodeFromJsonElementDeserializer:(id<OICCKotlinx_serialization_coreDeserializationStrategy>)deserializer element:(OICCKotlinx_serialization_jsonJsonElement *)element __attribute__((swift_name("decodeFromJsonElement(deserializer:element:)")));
- (id _Nullable)decodeFromStringString:(NSString *)string __attribute__((swift_name("decodeFromString(string:)")));
- (id _Nullable)decodeFromStringDeserializer:(id<OICCKotlinx_serialization_coreDeserializationStrategy>)deserializer string:(NSString *)string __attribute__((swift_name("decodeFromString(deserializer:string:)")));
- (OICCKotlinx_serialization_jsonJsonElement *)encodeToJsonElementSerializer:(id<OICCKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeToJsonElement(serializer:value:)")));
- (NSString *)encodeToStringValue:(id _Nullable)value __attribute__((swift_name("encodeToString(value:)")));
- (NSString *)encodeToStringSerializer:(id<OICCKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeToString(serializer:value:)")));
- (OICCKotlinx_serialization_jsonJsonElement *)parseToJsonElementString:(NSString *)string __attribute__((swift_name("parseToJsonElement(string:)")));
@property (readonly) OICCKotlinx_serialization_jsonJsonConfiguration *configuration __attribute__((swift_name("configuration")));
@property (readonly) OICCKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

@interface OICCKotlinx_serialization_jsonJson (Extensions)
- (id _Nullable)decodeFromStringOrNullString:(NSString *)string __attribute__((swift_name("decodeFromStringOrNull(string:)")));
@end

@interface OpenIdConnectClient (Extensions)

/**
 * Objective-C convenience function
 * @see OpenIDConnectClient.createAccessTokenRequest
 * @suppress
 *
 * @note This method converts instances of OpenIdConnectException, CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)createAccessTokenRequestAuthCodeRequest:(AuthCodeRequest *)authCodeRequest code:(NSString *)code completionHandler:(void (^)(TokenRequest * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("createAccessTokenRequest(authCodeRequest:code:completionHandler:)")));

/**
 * Objective-C convenience function
 * @see OpenIdConnectClient.createRefreshTokenRequest
 * @suppress
 *
 * @note This method converts instances of OpenIdConnectException, CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)createRefreshTokenRequestRefreshToken:(NSString *)refreshToken completionHandler:(void (^)(TokenRequest * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("createRefreshTokenRequest(refreshToken:completionHandler:)")));

/**
 * Objective-C convenience function
 * @see OpenIdConnectClient.exchangeToken
 * @suppress
 *
 * @note This method converts instances of OpenIdConnectException, CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)discoverWithCompletionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("discover(completionHandler:)")));

/**
 * Objective-C convenience function
 * @see OpenIdConnectClient.endSession
 * @suppress
 *
 * @note This method converts instances of OpenIdConnectException, CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)endSessionIdToken:(NSString *)idToken completionHandler:(void (^)(OICCKtor_httpHttpStatusCode * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("endSession(idToken:completionHandler:)")));

/**
 * Objective-C convenience function
 * @see OpenIdConnectClient.exchangeToken
 * @suppress
 *
 * @note This method converts instances of OpenIdConnectException, CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)exchangeTokenAuthCodeRequest:(AuthCodeRequest *)authCodeRequest code:(NSString *)code completionHandler:(void (^)(AccessTokenResponse * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("exchangeToken(authCodeRequest:code:completionHandler:)")));

/**
 * Objective-C convenience function
 * @see OpenIdConnectClient.refreshToken
 * @suppress
 *
 * @note This method converts instances of OpenIdConnectException, CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)refreshTokenRefreshToken:(NSString *)refreshToken completionHandler:(void (^)(AccessTokenResponse * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("refreshToken(refreshToken:completionHandler:)")));
@end

@interface OpenIdConnectClientConfig (Extensions)

/**
 * Validate the config
 *
 * @receiver the [OpenIdConnectClientConfig] to validate
 * @throws OpenIdConnectException if the config is invalid
 */
- (void)validate __attribute__((swift_name("validate()")));
@end

@interface CodeAuthFlow (Extensions)

/**
 * @note This method converts instances of OpenIdConnectException, CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getAccessTokenWithCompletionHandler:(void (^)(AccessTokenResponse * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getAccessToken(completionHandler:)")));
@end

@interface TokenRefreshHandler (Extensions)

/**
 * Thread-safe refresh the tokens and save to store.
 * (convenience method to allow calls from iOS as lambdas are not supported yet)
 *
 * @return The new access token
 *
 * @note This method converts instances of OpenIdConnectException, CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)refreshAndSaveTokenRefresher:(id<OICCTokenRefresher>)refresher oldAccessToken:(NSString *)oldAccessToken completionHandler:(void (^)(OICCOauthTokens * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("refreshAndSaveToken(refresher:oldAccessToken:completionHandler:)")));
@end

@interface TokenStoreProtocol (Extensions)

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getTokensWithCompletionHandler:(void (^)(OICCOauthTokens * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("getTokens(completionHandler:)")));
@property (readonly) OICCFlowWrapper<NSString *> *accessToken __attribute__((swift_name("accessToken")));
@property (readonly) OICCFlowWrapper<NSString *> *idToken __attribute__((swift_name("idToken")));
@property (readonly) OICCFlowWrapper<NSString *> *refreshToken __attribute__((swift_name("refreshToken")));
@property (readonly) OICCFlowWrapper<AccessTokenResponse *> *tokenResponse __attribute__((swift_name("tokenResponse")));
@property (readonly) id<OICCKotlinx_coroutines_coreFlow> tokensFlow __attribute__((swift_name("tokensFlow"))) __attribute__((deprecated("Use tokenResponseFlow instead")));
@end

@interface AuthCodeRequest (Extensions)
- (BOOL)validateNonceNonce:(NSString *)nonce __attribute__((swift_name("validateNonce(nonce:)")));
- (BOOL)validateStateState:(NSString *)state __attribute__((swift_name("validateState(state:)")));
@end

@interface AccessTokenResponse (Extensions)
- (BOOL)accessTokenExpiredExpiryTimeTolerance:(int64_t)expiryTimeTolerance __attribute__((swift_name("accessTokenExpired(expiryTimeTolerance:)")));
- (BOOL)refreshTokenExpiredExpiryTimeTolerance:(int64_t)expiryTimeTolerance __attribute__((swift_name("refreshTokenExpired(expiryTimeTolerance:)")));
@property (readonly) OICCKotlinInstant * _Nullable accessTokenExpirationTime __attribute__((swift_name("accessTokenExpirationTime")));
@property (readonly) OICCKotlinInstant * _Nullable refreshTokenExpirationTime __attribute__((swift_name("refreshTokenExpirationTime")));
@end

@interface OICCTokenExpirationPolicyCompanion (Extensions)
- (OICCTokenExpirationPolicy *)secondsValue:(int32_t)value __attribute__((swift_name("seconds(value:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CodeAuthFlowKt")))
@interface OICCCodeAuthFlowKt : OICCBase

/**
 * Continue login flow.
 *
 * @param request The original auth code request
 * @param responseUri URI returned by the IDP in response to the authorization, containing code and state.
 * @param configureTokenExchange configuration closure to configure the http request builder with (will _not_
 * be used for discovery if necessary)
 *
 * @note This method converts instances of OpenIdConnectException, CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
+ (void)continueLogin:(id<OpenIdConnectClientProtocol>)receiver request:(AuthCodeRequest *)request responseUri:(OICCKtor_httpUrl *)responseUri configureTokenExchange:(void (^ _Nullable)(OICCKtor_client_coreHttpRequestBuilder *))configureTokenExchange completionHandler:(void (^)(AccessTokenResponse * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("continueLogin(_:request:responseUri:configureTokenExchange:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EndSessionFlowKt")))
@interface OICCEndSessionFlowKt : OICCBase

/**
 * @note This method converts instances of OpenIdConnectException, CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
+ (void)continueLogout:(id<OpenIdConnectClientProtocol>)receiver responseUri:(OICCKtor_httpUrl *)responseUri completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("continueLogout(_:responseUri:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FlowWrapperKt")))
@interface OICCFlowWrapperKt : OICCBase
+ (OICCFlowWrapper<id> *)wrap:(id<OICCKotlinx_coroutines_coreFlow>)receiver scope:(id<OICCKotlinx_coroutines_coreCoroutineScope>)scope __attribute__((swift_name("wrap(_:scope:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("JwtKt")))
@interface OICCJwtKt : OICCBase

/**
 * @note This method converts instances of OpenIdConnectException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
+ (Jwt * _Nullable)parseJwt:(NSString *)receiver error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("parseJwt(_:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("OpenIdConnectClientKt")))
@interface OICCOpenIdConnectClientKt : OICCBase

/**
 * Create a [DefaultOpenIdConnectClient].
 */
+ (id<OpenIdConnectClientProtocol>)OpenIdConnectClientHttpClient:(OICCKtor_client_coreHttpClient *)httpClient config:(OpenIdConnectClientConfig *)config __attribute__((swift_name("OpenIdConnectClient(httpClient:config:)"))) __attribute__((deprecated("Use DefaultOpenIdConnectClient constructor instead")));

/**
 * Builds an [OpenIdConnectClientConfig] using the [block] parameter and returns a
 * [DefaultOpenIdConnectClient].
 *
 * This uses the default ktor HTTP client. You may provide your own client using the
 * [DefaultOpenIdConnectClient] constructor.
 *
 * @param discoveryUri if set, endpoints in the configuration are optional.
 * Setting an endpoint manually will override a discovered endpoint.
 * @param block configuration closure. See [OpenIdConnectClientConfig]
 */
+ (id<OpenIdConnectClientProtocol>)OpenIdConnectClientDiscoveryUri:(NSString * _Nullable)discoveryUri block:(void (^)(OpenIdConnectClientConfig *))block __attribute__((swift_name("OpenIdConnectClient(discoveryUri:block:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("OpenIdConnectClientConfigKt")))
@interface OICCOpenIdConnectClientConfigKt : OICCBase

/**
 * Builds an [OpenIdConnectClientConfig] using the [block] parameter.
 *
 * @return [OpenIdConnectClientConfig]
 */
+ (OpenIdConnectClientConfig *)OpenIdConnectClientConfigBlock:(void (^)(OpenIdConnectClientConfig *))block __attribute__((swift_name("OpenIdConnectClientConfig(block:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PlatformCodeAuthFlow_iosKt")))
@interface OICCPlatformCodeAuthFlow_iosKt : OICCBase

/** fix for multiple callbacks from ASWebAuthenticationSession (https://github.com/kalinjul/kotlin-multiplatform-oidc/issues/89) **/
+ (void)resumeIfActive:(id<OICCKotlinx_coroutines_coreCancellableContinuation>)receiver value:(id _Nullable)value __attribute__((swift_name("resumeIfActive(_:value:)")));

/** fix for multiple callbacks from ASWebAuthenticationSession (https://github.com/kalinjul/kotlin-multiplatform-oidc/issues/89) **/
+ (void)resumeWithExceptionIfActive:(id<OICCKotlinx_coroutines_coreCancellableContinuation>)receiver value:(OICCKotlinException *)value __attribute__((swift_name("resumeWithExceptionIfActive(_:value:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PreferencesExtKt")))
@interface OICCPreferencesExtKt : OICCBase

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
+ (void)clearOidcPreferences:(id<OICCPreferences>)receiver completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("clearOidcPreferences(_:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
+ (void)getAuthRequest:(id<OICCPreferences>)receiver completionHandler:(void (^)(AuthCodeRequest * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("getAuthRequest(_:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
+ (void)getEndsessionRequest:(id<OICCPreferences>)receiver completionHandler:(void (^)(EndSessionRequest * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("getEndsessionRequest(_:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
+ (void)getResponseUri:(id<OICCPreferences>)receiver completionHandler:(void (^)(OICCKtor_httpUrl * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("getResponseUri(_:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
+ (void)setAuthRequest:(id<OICCPreferences>)receiver request:(AuthCodeRequest *)request completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("setAuthRequest(_:request:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
+ (void)setEndSessionRequest:(id<OICCPreferences>)receiver request:(EndSessionRequest *)request completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("setEndSessionRequest(_:request:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
+ (void)setResponseUri:(id<OICCPreferences>)receiver response:(OICCKtor_httpUrl *)response completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("setResponseUri(_:response:completionHandler:)")));
@property (class, readonly) NSString *PREFERENCES_FILENAME __attribute__((swift_name("PREFERENCES_FILENAME")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RunCatchingWrapExceptionKt")))
@interface OICCRunCatchingWrapExceptionKt : OICCBase
+ (id _Nullable)wrapExceptionsBlock:(id _Nullable (^)(void))block __attribute__((swift_name("wrapExceptions(block:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SettingsTokenStoreKt")))
@interface OICCSettingsTokenStoreKt : OICCBase
+ (id _Nullable)runOrNullBlock:(id _Nullable (^)(void))block __attribute__((swift_name("runOrNull(block:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TokenExpirationKt")))
@interface OICCTokenExpirationKt : OICCBase
@property (class, readonly) OICCTokenExpirationPolicy *DefaultTokenExpirationPolicy __attribute__((swift_name("DefaultTokenExpirationPolicy")));
@end

__attribute__((swift_name("KotlinRuntimeException")))
@interface OICCKotlinRuntimeException : OICCKotlinException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(OICCKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(OICCKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((swift_name("KotlinIllegalStateException")))
@interface OICCKotlinIllegalStateException : OICCKotlinRuntimeException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(OICCKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(OICCKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.4")
*/
__attribute__((swift_name("KotlinCancellationException")))
@interface OICCKotlinCancellationException : OICCKotlinIllegalStateException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(OICCKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(OICCKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end


/**
 * A builder message either for the client or the server,
 * that has a [headers] builder associated.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.HttpMessageBuilder)
 */
__attribute__((swift_name("Ktor_httpHttpMessageBuilder")))
@protocol OICCKtor_httpHttpMessageBuilder
@required

/**
 * MessageBuilder [HeadersBuilder]
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.HttpMessageBuilder.headers)
 */
@property (readonly) OICCKtor_httpHeadersBuilder *headers __attribute__((swift_name("headers")));
@end


/**
 * Contains parameters used to make an HTTP request.
 *
 * Learn more from [Making requests](https://ktor.io/docs/request.html).
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpRequestBuilder)
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpRequestBuilder")))
@interface OICCKtor_client_coreHttpRequestBuilder : OICCBase <OICCKtor_httpHttpMessageBuilder>

/**
 * Contains parameters used to make an HTTP request.
 *
 * Learn more from [Making requests](https://ktor.io/docs/request.html).
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpRequestBuilder)
 */
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));

/**
 * Contains parameters used to make an HTTP request.
 *
 * Learn more from [Making requests](https://ktor.io/docs/request.html).
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpRequestBuilder)
 */
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) OICCKtor_client_coreHttpRequestBuilderCompanion *companion __attribute__((swift_name("companion")));

/**
 * Creates immutable [HttpRequestData].
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpRequestBuilder.build)
 */
- (OICCKtor_client_coreHttpRequestData *)build __attribute__((swift_name("build()")));

/**
 * Retrieves capability by the key.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpRequestBuilder.getCapabilityOrNull)
 */
- (id _Nullable)getCapabilityOrNullKey:(id<OICCKtor_client_coreHttpClientEngineCapability>)key __attribute__((swift_name("getCapabilityOrNull(key:)")));

/**
 * Sets request-specific attributes specified by [block].
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpRequestBuilder.setAttributes)
 */
- (void)setAttributesBlock:(void (^)(id<OICCKtor_utilsAttributes>))block __attribute__((swift_name("setAttributes(block:)")));

/**
 * Sets capability configuration.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpRequestBuilder.setCapability)
 */
- (void)setCapabilityKey:(id<OICCKtor_client_coreHttpClientEngineCapability>)key capability:(id)capability __attribute__((swift_name("setCapability(key:capability:)")));

/**
 * Mutates [this] by copying all the data but execution context from another [builder] using it as the base.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpRequestBuilder.takeFrom)
 */
- (OICCKtor_client_coreHttpRequestBuilder *)takeFromBuilder:(OICCKtor_client_coreHttpRequestBuilder *)builder __attribute__((swift_name("takeFrom(builder:)")));

/**
 * Mutates [this] copying all the data from another [builder] using it as the base.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpRequestBuilder.takeFromWithExecutionContext)
 */
- (OICCKtor_client_coreHttpRequestBuilder *)takeFromWithExecutionContextBuilder:(OICCKtor_client_coreHttpRequestBuilder *)builder __attribute__((swift_name("takeFromWithExecutionContext(builder:)")));

/**
 * Executes a [block] that configures the [URLBuilder] associated to this request.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpRequestBuilder.url)
 */
- (void)urlBlock:(void (^)(OICCKtor_httpURLBuilder *, OICCKtor_httpURLBuilder *))block __attribute__((swift_name("url(block:)")));

/**
 * Provides access to attributes specific for this request.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpRequestBuilder.attributes)
 */
@property (readonly) id<OICCKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));

/**
 * The [body] for this request. Initially [EmptyContent].
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpRequestBuilder.body)
 */
@property id body __attribute__((swift_name("body")));

/**
 * The [KType] of [body] for this request. Null for default types that don't need serialization.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpRequestBuilder.bodyType)
 */
@property OICCKtor_utilsTypeInfo * _Nullable bodyType __attribute__((swift_name("bodyType")));

/**
 * A deferred used to control the execution of this request.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpRequestBuilder.executionContext)
 */
@property (readonly) id<OICCKotlinx_coroutines_coreJob> executionContext __attribute__((swift_name("executionContext")));

/**
 * [HeadersBuilder] to configure the headers for this request.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpRequestBuilder.headers)
 */
@property (readonly) OICCKtor_httpHeadersBuilder *headers __attribute__((swift_name("headers")));

/**
 * [HttpMethod] used by this request. [HttpMethod.Get] by default.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpRequestBuilder.method)
 */
@property OICCKtor_httpHttpMethod *method __attribute__((swift_name("method")));

/**
 * [URLBuilder] to configure the URL for this request.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpRequestBuilder.url)
 */
@property (readonly) OICCKtor_httpURLBuilder *url __attribute__((swift_name("url")));
@end


/**
 * A URL builder with all mutable components
 *
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.URLBuilder)
 *
 * @property protocol URL protocol (scheme)
 * @property host name without port (domain)
 * @property port port number
 * @property user username part (optional)
 * @property password password part (optional)
 * @property pathSegments URL path without query
 * @property parameters URL query parameters
 * @property fragment URL fragment (anchor name)
 * @property trailingQuery keep a trailing question character even if there are no query parameters
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpURLBuilder")))
@interface OICCKtor_httpURLBuilder : OICCBase
- (instancetype)initWithProtocol:(OICCKtor_httpURLProtocol * _Nullable)protocol host:(NSString *)host port:(int32_t)port user:(NSString * _Nullable)user password:(NSString * _Nullable)password pathSegments:(NSArray<NSString *> *)pathSegments parameters:(id<OICCKtor_httpParameters>)parameters fragment:(NSString *)fragment trailingQuery:(BOOL)trailingQuery __attribute__((swift_name("init(protocol:host:port:user:password:pathSegments:parameters:fragment:trailingQuery:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) OICCKtor_httpURLBuilderCompanion *companion __attribute__((swift_name("companion")));

/**
 * Build a [Url] instance (everything is copied to a new instance)
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.URLBuilder.build)
 */
- (OICCKtor_httpUrl *)build __attribute__((swift_name("build()")));

/**
 * Build a URL string
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.URLBuilder.buildString)
 */
- (NSString *)buildString __attribute__((swift_name("buildString()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString *encodedFragment __attribute__((swift_name("encodedFragment")));
@property id<OICCKtor_httpParametersBuilder> encodedParameters __attribute__((swift_name("encodedParameters")));
@property NSString * _Nullable encodedPassword __attribute__((swift_name("encodedPassword")));
@property NSArray<NSString *> *encodedPathSegments __attribute__((swift_name("encodedPathSegments")));
@property NSString * _Nullable encodedUser __attribute__((swift_name("encodedUser")));
@property NSString *fragment __attribute__((swift_name("fragment")));
@property NSString *host __attribute__((swift_name("host")));
@property (readonly) id<OICCKtor_httpParametersBuilder> parameters __attribute__((swift_name("parameters")));
@property NSString * _Nullable password __attribute__((swift_name("password")));
@property NSArray<NSString *> *pathSegments __attribute__((swift_name("pathSegments")));
@property int32_t port __attribute__((swift_name("port")));
@property OICCKtor_httpURLProtocol *protocol __attribute__((swift_name("protocol")));
@property OICCKtor_httpURLProtocol * _Nullable protocolOrNull __attribute__((swift_name("protocolOrNull")));
@property BOOL trailingQuery __attribute__((swift_name("trailingQuery")));
@property NSString * _Nullable user __attribute__((swift_name("user")));
@end


/**
 * Represents an HTTP status code and description.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.HttpStatusCode)
 *
 * @param value is a numeric code.
 * @param description is free form description of a status.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpStatusCode")))
@interface OICCKtor_httpHttpStatusCode : OICCBase <OICCKotlinComparable>
- (instancetype)initWithValue:(int32_t)value description:(NSString *)description __attribute__((swift_name("init(value:description:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) OICCKtor_httpHttpStatusCodeCompanion *companion __attribute__((swift_name("companion")));
- (int32_t)compareToOther:(OICCKtor_httpHttpStatusCode *)other __attribute__((swift_name("compareTo(other:)")));
- (OICCKtor_httpHttpStatusCode *)doCopyValue:(int32_t)value description:(NSString *)description __attribute__((swift_name("doCopy(value:description:)")));

/**
 * Returns a copy of `this` code with a description changed to [value].
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.HttpStatusCode.description)
 */
- (OICCKtor_httpHttpStatusCode *)descriptionValue:(NSString *)value __attribute__((swift_name("description(value:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *description_ __attribute__((swift_name("description_")));
@property (readonly) int32_t value __attribute__((swift_name("value")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="2.0")
*/
__attribute__((swift_name("KotlinAutoCloseable")))
@protocol OICCKotlinAutoCloseable
@required
- (void)close __attribute__((swift_name("close()")));
@end

__attribute__((swift_name("Ktor_ioCloseable")))
@protocol OICCKtor_ioCloseable <OICCKotlinAutoCloseable>
@required
@end


/**
 * A multiplatform asynchronous HTTP client that allows you to make requests, handle responses,
 * and extend its functionality with plugins such as authentication, JSON serialization, and more.
 *
 * # Creating client
 * To create a new client, you can call:
 * ```kotlin
 * val client = HttpClient()
 * ```
 * You can create as many clients as you need.
 *
 * If you no longer need the client, please consider closing it to release resources:
 * ```
 * client.close()
 * ```
 *
 * To learn more on how to create and configure an [HttpClient] see the tutorial page:
 * [Creating and configuring a client](https://ktor.io/docs/create-client.html).
 *
 * # Making API Requests
 * For every HTTP method (GET, POST, PUT, etc.), there is a corresponding function:
 * ```kotlin
 * val response: HttpResponse = client.get("https://ktor.io/")
 * val body = response.bodyAsText()
 * ```
 * See [Making HTTP requests](https://ktor.io/docs/client-requests.html) for more details.
 *
 * # Query Parameters
 * Add query parameters to your request using the `parameter` function:
 * ```kotlin
 * val response = client.get("https://google.com/search") {
 *     url {
 *         parameter("q", "REST API with Ktor")
 *     }
 * }
 * ```
 * For more information, refer to [Passing request parameters](https://ktor.io/docs/client-requests.html#parameters).
 *
 * # Adding Headers
 * Include headers in your request using the `headers` builder or the `header` function:
 * ```kotlin
 * val response = client.get("https://httpbin.org/bearer") {
 *     headers {
 *         append("Authorization", "Bearer your_token_here")
 *         append("Accept", "application/json")
 *     }
 * }
 * ```
 * Learn more at [Adding headers to a request](https://ktor.io/docs/client-requests.html#headers).
 *
 * # JSON Serialization
 * Add dependencies:
 * - io.ktor:ktor-client-content-negotiation:3.+
 * - io.ktor:ktor-serialization-kotlinx-json:3.+
 * Add Gradle plugin:
 * ```
 * plugins {
 *     kotlin("plugin.serialization")
 * }
 * ```
 *
 * Send and receive JSON data by installing the `ContentNegotiation` plugin with `kotlinx.serialization`:
 * ```kotlin
 * val client = HttpClient {
 *     install(ContentNegotiation) {
 *         json()
 *     }
 * }
 *
 * @Serializable
 * data class MyRequestType(val someData: String)
 *
 * @Serializable
 * data class MyResponseType(val someResponseData: String)
 *
 * val response: MyResponseType = client.post("https://api.example.com/data") {
 *     contentType(ContentType.Application.Json)
 *     setBody(MyRequestType(someData = "value"))
 * }.body()
 * ```
 * See [Serializing JSON data](https://ktor.io/docs/client-serialization.html) for maven configuration and other details.
 *
 * # Submitting Forms
 * Submit form data using `FormDataContent` or the `submitForm` function:
 * ```kotlin
 * // Using FormDataContent
 * val response = client.post("https://example.com/submit") {
 *     setBody(FormDataContent(Parameters.build {
 *         append("username", "user")
 *         append("password", "pass")
 *     }))
 * }
 *
 * // Or using submitForm
 * val response = client.submitForm(
 *     url = "https://example.com/submit",
 *     formParameters = Parameters.build {
 *         append("username", "user")
 *         append("password", "pass")
 *     }
 * )
 * ```
 * More information is available at [Submitting form parameters](https://ktor.io/docs/client-requests.html#form_parameters).
 *
 * # Handling Authentication
 * Add dependency: io.ktor:ktor-client-auth:3.+
 *
 * Use the `Auth` plugin to handle various authentication schemes like Basic or Bearer token authentication:
 * ```kotlin
 * val client = HttpClient {
 *     install(Auth) {
 *         bearer {
 *             loadTokens {
 *                 BearerTokens(accessToken = "your_access_token", refreshToken = "your_refresh_token")
 *             }
 *         }
 *     }
 * }
 *
 * val response = client.get("https://api.example.com/protected")
 * ```
 * Refer to [Client authentication](https://ktor.io/docs/client-auth.html) for more details.
 *
 * # Setting Timeouts and Retries
 * Configure timeouts and implement retry logic for your requests:
 * ```kotlin
 * val client = HttpClient {
 *     install(HttpTimeout) {
 *         requestTimeoutMillis = 10000
 *         connectTimeoutMillis = 5000
 *         socketTimeoutMillis = 15000
 *     }
 * }
 * ```
 *
 * For the request timeout:
 * ```kotlin
 * client.get("") {
 *     timeout {
 *         requestTimeoutMillis = 1000
 *     }
 * }
 * ```
 * See [Timeout](https://ktor.io/docs/client-timeout.html) for more information.
 *
 * # Handling Cookies
 *
 * Manage cookies automatically by installing the `HttpCookies` plugin:
 * ```kotlin
 * val client = HttpClient {
 *     install(HttpCookies) {
 *         storage = AcceptAllCookiesStorage()
 *     }
 * }
 *
 * // Accessing cookies
 * val cookies: List<Cookie> = client.cookies("https://example.com")
 * ```
 * Learn more at [Cookies](https://ktor.io/docs/client-cookies.html).
 *
 * # Uploading Files
 * Upload files using multipart/form-data requests:
 * ```kotlin
 * client.submitFormWithBinaryData(
 *      url = "https://example.com/upload",
 *      formData = formData {
 *          append("description", "File upload example")
 *          append("file", {
 *              File("path/to/file.txt").readChannel()
 *          })
 *      }
 *  )
 *
 * See [Uploading data](https://ktor.io/docs/client-requests.html#upload_file) for details.
 *
 * # Using WebSockets
 *
 * Communicate over WebSockets using the `webSocket` function:
 * ```kotlin
 * client.webSocket("wss://echo.websocket.org") {
 *     send(Frame.Text("Hello, WebSocket!"))
 *     val frame = incoming.receive()
 *     if (frame is Frame.Text) {
 *         println("Received: ${frame.readText()}")
 *     }
 * }
 * ```
 * Learn more at [Client WebSockets](https://ktor.io/docs/client-websockets.html).
 *
 * # Error Handling
 * Handle exceptions and HTTP error responses gracefully:
 * val client = HttpClient {
 *     HttpResponseValidator {
 *         validateResponse { response ->
 *             val statusCode = response.status.value
 *             when (statusCode) {
 *                 in 300..399 -> error("Redirects are not allowed")
 *             }
 *         }
 *     }
 * }
 * See [Error handling](https://ktor.io/docs/client-response-validation.html) for more information.
 *
 * # Configuring SSL/TLS
 *
 * Customize SSL/TLS settings for secure connections is engine-specific. Please refer to the following page for
 * the details: [Client SSL/TLS](https://ktor.io/docs/client-ssl.html).
 *
 * # Using Proxies
 * Route requests through an HTTP or SOCKS proxy:
 * ```kotlin
 * val client = HttpClient() {
 *     engine {
 *         proxy = ProxyBuilder.http("http://proxy.example.com:8080")
 *         // For a SOCKS proxy:
 *         // proxy = ProxyBuilder.socks(host = "proxy.example.com", port = 1080)
 *     }
 * }
 * ```
 * See [Using a proxy](https://ktor.io/docs/client-proxy.html) for details.
 *
 * # Streaming Data
 *
 * Stream large data efficiently without loading it entirely into memory.
 *
 * Stream request:
 * ```kotlin
 * val response = client.post("https://example.com/upload") {
 *      setBody(object: OutgoingContent.WriteChannelContent() {
 *          override suspend fun writeTo(channel: ByteWriteChannel) {
 *              repeat(1000) {
 *                  channel.writeString("Hello!")
 *              }
 *          }
 *      })
 * }
 * ```
 *
 * Stream response:
 * ```kotlin
 * client.prepareGet("https://example.com/largefile.zip").execute { response ->
 *     val channel: ByteReadChannel = response.bodyAsChannel()
 *
 *     while (!channel.exhausted()) {
 *         val chunk = channel.readBuffer()
 *         // ...
 *     }
 * }
 * ```
 * Learn more at [Streaming data](https://ktor.io/docs/client-responses.html#streaming).
 *
 * # Using SSE
 * Server-Sent Events (SSE) is a technology that allows a server to continuously push events to a client over an HTTP
 * connection. It's particularly useful in cases where the server needs to send event-based updates without requiring
 * the client to repeatedly poll the server.
 *
 * Install the plugin:
 * ```kotlin
 * val client = HttpClient(CIO) {
 *     install(SSE)
 * }
 * ```
 *
 * ```
 * client.sse(host = "0.0.0.0", port = 8080, path = "/events") {
 *     while (true) {
 *         for (event in incoming) {
 *             println("Event from server:")
 *             println(event)
 *         }
 *     }
 * }
 * ```
 *
 * Visit [Using SSE](https://ktor.io/docs/client-server-sent-events.html#install_plugin) to learn more.
 *
 * # Customizing a client with plugins
 * To extend out-of-the-box functionality, you can install plugins for a Ktor client:
 * ```kotlin
 * val client = HttpClient {
 *     install(ContentNegotiation) {
 *         json()
 *     }
 * }
 * ```
 *
 * There are many plugins available out of the box, and you can write your own. See
 * [Create custom client plugins](https://ktor.io/docs/client-custom-plugins.html) to learn more.
 *
 * # Service Loader and Default Engine
 * On JVM, calling `HttpClient()` without specifying an engine uses a service loader mechanism to
 * determine the appropriate default engine. This can introduce a performance overhead, especially on
 * slower devices, such as Android.
 *
 * **Performance Note**: If you are targeting platforms where initialization speed is critical,
 * consider explicitly specifying an engine to avoid the service loader lookup.
 *
 * Example with manual engine specification:
 * ```
 * val client = HttpClient(Apache) // Explicitly uses Apache engine, bypassing service loader
 * ```
 *
 * By directly setting the engine (e.g., `Apache`, `OkHttp`), you can optimize startup performance
 * by preventing the default service loader mechanism.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.HttpClient)
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpClient")))
@interface OICCKtor_client_coreHttpClient : OICCBase <OICCKotlinx_coroutines_coreCoroutineScope, OICCKtor_ioCloseable>
- (instancetype)initWithEngine:(id<OICCKtor_client_coreHttpClientEngine>)engine userConfig:(OICCKtor_client_coreHttpClientConfig<OICCKtor_client_coreHttpClientEngineConfig *> *)userConfig __attribute__((swift_name("init(engine:userConfig:)"))) __attribute__((objc_designated_initializer));

/**
 * Initiates the shutdown process for the `HttpClient`. This is a non-blocking call, which
 * means it returns immediately and begins the client closure in the background.
 *
 * ## Usage
 * ```
 * val client = HttpClient()
 * client.close()
 * client.coroutineContext.job.join() // Waits for complete termination if necessary
 * ```
 *
 * ## Important Notes
 * - **Non-blocking**: `close()` only starts the closing process and does not wait for it to complete.
 * - **Coroutine Context**: To wait for all client resources to be freed, use `client.coroutineContext.job.join()`
 *   or `client.coroutineContext.cancel()` to terminate ongoing tasks.
 * - **Manual Engine Management**: If a custom `engine` was manually created, it must be closed explicitly
 *   after calling `client.close()` to release all resources.
 *
 * Example with custom engine management:
 * ```
 * val engine = HttpClientEngine() // Custom engine instance
 * val client = HttpClient(engine)
 *
 * client.close()
 * engine.close() // Ensure manually created engine is also closed
 * ```
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.HttpClient.close)
 */
- (void)close __attribute__((swift_name("close()")));

/**
 * Returns a new [HttpClient] by copying this client's configuration
 * and additionally configured by the [block] parameter.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.HttpClient.config)
 */
- (OICCKtor_client_coreHttpClient *)configBlock:(void (^)(OICCKtor_client_coreHttpClientConfig<id> *))block __attribute__((swift_name("config(block:)")));

/**
 * Checks if the specified [capability] is supported by this client.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.HttpClient.isSupported)
 */
- (BOOL)isSupportedCapability:(id<OICCKtor_client_coreHttpClientEngineCapability>)capability __attribute__((swift_name("isSupported(capability:)")));
- (NSString *)description __attribute__((swift_name("description()")));

/**
 * Typed attributes used as a lightweight container for this client.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.HttpClient.attributes)
 */
@property (readonly) id<OICCKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property (readonly) id<OICCKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@property (readonly) id<OICCKtor_client_coreHttpClientEngine> engine __attribute__((swift_name("engine")));

/**
 * Provides access to the client's engine configuration.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.HttpClient.engineConfig)
 */
@property (readonly) OICCKtor_client_coreHttpClientEngineConfig *engineConfig __attribute__((swift_name("engineConfig")));

/**
 * Provides access to the events of the client's lifecycle.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.HttpClient.monitor)
 */
@property (readonly) OICCKtor_eventsEvents *monitor __attribute__((swift_name("monitor")));

/**
 * A pipeline used for receiving a request.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.HttpClient.receivePipeline)
 */
@property (readonly) OICCKtor_client_coreHttpReceivePipeline *receivePipeline __attribute__((swift_name("receivePipeline")));

/**
 * A pipeline used for processing all requests sent by this client.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.HttpClient.requestPipeline)
 */
@property (readonly) OICCKtor_client_coreHttpRequestPipeline *requestPipeline __attribute__((swift_name("requestPipeline")));

/**
 * A pipeline used for processing all responses sent by the server.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.HttpClient.responsePipeline)
 */
@property (readonly) OICCKtor_client_coreHttpResponsePipeline *responsePipeline __attribute__((swift_name("responsePipeline")));

/**
 * A pipeline used for sending a request.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.HttpClient.sendPipeline)
 */
@property (readonly) OICCKtor_client_coreHttpSendPipeline *sendPipeline __attribute__((swift_name("sendPipeline")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerializationStrategy")))
@protocol OICCKotlinx_serialization_coreSerializationStrategy
@required
- (void)serializeEncoder:(id<OICCKotlinx_serialization_coreEncoder>)encoder value:(id _Nullable)value __attribute__((swift_name("serialize(encoder:value:)")));
@property (readonly) id<OICCKotlinx_serialization_coreSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreDeserializationStrategy")))
@protocol OICCKotlinx_serialization_coreDeserializationStrategy
@required
- (id _Nullable)deserializeDecoder:(id<OICCKotlinx_serialization_coreDecoder>)decoder __attribute__((swift_name("deserialize(decoder:)")));
@property (readonly) id<OICCKotlinx_serialization_coreSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreKSerializer")))
@protocol OICCKotlinx_serialization_coreKSerializer <OICCKotlinx_serialization_coreSerializationStrategy, OICCKotlinx_serialization_coreDeserializationStrategy>
@required
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinArray")))
@interface OICCKotlinArray<T> : OICCBase
+ (instancetype)arrayWithSize:(int32_t)size init:(T _Nullable (^)(OICCInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (T _Nullable)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (id<OICCKotlinIterator>)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(T _Nullable)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end

__attribute__((swift_name("Oidc_preferencesPreferencesSingletonFactory")))
@interface OICCOidc_preferencesPreferencesSingletonFactory : OICCBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) OICCOidc_preferencesPreferencesSingletonFactoryCompanion *companion __attribute__((swift_name("companion")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (id<OICCPreferences>)createFilename:(NSString *)filename __attribute__((swift_name("create(filename:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getOrCreateFilename:(NSString *)filename completionHandler:(void (^)(id<OICCPreferences> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getOrCreate(filename:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Oidc_preferencesPreferencesFactory")))
@interface OICCOidc_preferencesPreferencesFactory : OICCOidc_preferencesPreferencesSingletonFactory
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (id<OICCPreferences>)createFilename:(NSString *)filename __attribute__((swift_name("create(filename:)")));
@end

__attribute__((swift_name("Ktor_ioJvmSerializable")))
@protocol OICCKtor_ioJvmSerializable
@required
@end


/**
 * Represents an immutable URL
 *
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.Url)
 *
 * @property protocol
 * @property host name without port (domain)
 * @property port the specified port or protocol default port
 * @property specifiedPort port number that was specified to override protocol's default
 * @property encodedPath encoded path without query string
 * @property parameters URL query parameters
 * @property fragment URL fragment (anchor name)
 * @property user username part of URL
 * @property password password part of URL
 * @property trailingQuery keep trailing question character even if there are no query parameters
 *
 * @note annotations
 *   kotlinx.serialization.Serializable(with=NormalClass(value=io/ktor/http/UrlSerializer))
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpUrl")))
@interface OICCKtor_httpUrl : OICCBase <OICCKtor_ioJvmSerializable>
@property (class, readonly, getter=companion) OICCKtor_httpUrlCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *encodedFragment __attribute__((swift_name("encodedFragment")));
@property (readonly) NSString * _Nullable encodedPassword __attribute__((swift_name("encodedPassword")));
@property (readonly) NSString *encodedPath __attribute__((swift_name("encodedPath")));
@property (readonly) NSString *encodedPathAndQuery __attribute__((swift_name("encodedPathAndQuery")));
@property (readonly) NSString *encodedQuery __attribute__((swift_name("encodedQuery")));
@property (readonly) NSString * _Nullable encodedUser __attribute__((swift_name("encodedUser")));
@property (readonly) NSString *fragment __attribute__((swift_name("fragment")));
@property (readonly) NSString *host __attribute__((swift_name("host")));
@property (readonly) id<OICCKtor_httpParameters> parameters __attribute__((swift_name("parameters")));
@property (readonly) NSString * _Nullable password __attribute__((swift_name("password")));

/**
 * A list containing the segments of the URL path.
 *
 * This property was designed to distinguish between absolute and relative paths,
 * so it will have an empty segment at the beginning for URLs with a hostname
 * and an empty segment at the end for URLs with a trailing slash.
 *
 * ```kotlin
 * val fullUrl = Url("http://ktor.io/docs/")
 * fullUrl.pathSegments == listOf("", "docs", "")
 *
 * val absolute = Url("/docs/")
 * absolute.pathSegments == listOf("", "docs", "")
 *
 * val relative = Url("docs")
 * relative.pathSegments == listOf("docs")
 * ```
 *
 * This behaviour may not be ideal if you're working only with full URLs.
 * If you don't require the specific handling of empty segments, consider using the [segments] property instead:
 *
 * ```kotlin
 * val fullUrl = Url("http://ktor.io/docs/")
 * fullUrl.segments == listOf("docs")
 *
 * val absolute = Url("/docs/")
 * absolute.segments == listOf("docs")
 *
 * val relative = Url("docs")
 * relative.segments == listOf("docs")
 * ```
 *
 * To address this issue, the current [pathSegments] property will be renamed to [rawSegments].
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.Url.pathSegments)
 */
@property (readonly) NSArray<NSString *> *pathSegments __attribute__((swift_name("pathSegments"))) __attribute__((deprecated("\n        `pathSegments` is deprecated.\n\n        This property will contain an empty path segment at the beginning for URLs with a hostname,\n        and an empty path segment at the end for the URLs with a trailing slash. If you need to keep this behaviour please\n        use [rawSegments]. If you only need to access the meaningful parts of the path, consider using [segments] instead.\n             \n        Please decide if you need [rawSegments] or [segments] explicitly.\n        ")));
@property (readonly) int32_t port __attribute__((swift_name("port")));
@property (readonly) OICCKtor_httpURLProtocol *protocol __attribute__((swift_name("protocol")));
@property (readonly) OICCKtor_httpURLProtocol * _Nullable protocolOrNull __attribute__((swift_name("protocolOrNull")));

/**
 * A list containing the segments of the URL path.
 *
 * This property is designed to distinguish between absolute and relative paths,
 * so it will have an empty segment at the beginning for URLs with a hostname
 * and an empty segment at the end for URLs with a trailing slash.
 *
 * ```kotlin
 * val fullUrl = Url("http://ktor.io/docs/")
 * fullUrl.rawSegments == listOf("", "docs", "")
 *
 * val absolute = Url("/docs/")
 * absolute.rawSegments == listOf("", "docs", "")
 *
 * val relative = Url("docs")
 * relative.rawSegments == listOf("docs")
 * ```
 *
 * This behaviour may not be ideal if you're working only with full URLs.
 * If you don't require the specific handling of empty segments, consider using the [segments] property instead:
 *
 * ```kotlin
 * val fullUrl = Url("http://ktor.io/docs/")
 * fullUrl.segments == listOf("docs")
 *
 * val absolute = Url("/docs/")
 * absolute.segments == listOf("docs")
 *
 * val relative = Url("docs")
 * relative.segments == listOf("docs")
 * ```
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.Url.rawSegments)
 */
@property (readonly) NSArray<NSString *> *rawSegments __attribute__((swift_name("rawSegments")));

/**
 * A list of path segments derived from the URL, excluding any leading
 * and trailing empty segments.
 *
 * ```kotlin
 * val fullUrl = Url("http://ktor.io/docs/")
 * fullUrl.segments == listOf("docs")
 *
 * val absolute = Url("/docs/")
 * absolute.segments == listOf("docs")
 * val relative = Url("docs")
 * relative.segments == listOf("docs")
 * ```
 *
 * If you need to check for trailing slash and relative/absolute paths, please check the [rawSegments] property.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.Url.segments)
 **/
@property (readonly) NSArray<NSString *> *segments __attribute__((swift_name("segments")));
@property (readonly) int32_t specifiedPort __attribute__((swift_name("specifiedPort")));
@property (readonly) BOOL trailingQuery __attribute__((swift_name("trailingQuery")));
@property (readonly) NSString * _Nullable user __attribute__((swift_name("user")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreFlow")))
@protocol OICCKotlinx_coroutines_coreFlow
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)collectCollector:(id<OICCKotlinx_coroutines_coreFlowCollector>)collector completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("collect(collector:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinEnumCompanion")))
@interface OICCKotlinEnumCompanion : OICCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) OICCKotlinEnumCompanion *shared __attribute__((swift_name("shared")));
@end


/**
 * Represents a prepared HTTP request statement for [HttpClient].
 *
 * The [HttpStatement] class encapsulates a request configuration without executing it immediately.
 * This statement can be executed on-demand via various methods such as [execute], allowing for
 * deferred or multiple executions without creating a new request each time.
 *
 * ## Deferred Execution
 * `HttpStatement` does not initiate any network activity until an execution method is called.
 * It is safe to execute multiple times, which can be useful in scenarios requiring reusability of
 * the same request configuration.
 *
 * Example: [Streaming data](https://ktor.io/docs/response.html#streaming)
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.statement.HttpStatement)
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpStatement")))
@interface OICCKtor_client_coreHttpStatement : OICCBase
- (instancetype)initWithBuilder:(OICCKtor_client_coreHttpRequestBuilder *)builder client:(OICCKtor_client_coreHttpClient *)client __attribute__((swift_name("init(builder:client:)"))) __attribute__((objc_designated_initializer));

/**
 * Executes the HTTP statement and processes the response through [HttpClient.responsePipeline] to retrieve
 * an instance of the specified type [T].
 *
 * If [T] represents a streaming type (such as [ByteReadChannel]), it is the caller's responsibility to
 * properly manage the resource, ensuring it is closed when no longer needed.
 *
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.statement.HttpStatement.body)
 *
 * @return The response body transformed to the specified type [T].
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)bodyWithCompletionHandler:(void (^)(id _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("body(completionHandler:)")));

/**
 * Executes the HTTP statement and processes the response of type [T] through the provided [block].
 *
 * This function is particularly useful for handling streaming responses, allowing you to process data on-the-fly
 * while the network connection remains open.
 * The [block] receives the streamed [response] and can be used to perform operations on the data as it arrives.
 *
 * Once [block] completes, the resources associated with the response are automatically cleaned up, freeing
 * any network or memory resources held by the response.
 *
 * ## Usage Example
 * ```
 * client.request {
 *     url("https://ktor.io")
 * }.body<ByteReadChannel> { channel ->
 *     // Process streaming data here
 * }
 * // Resources are released automatically after block completes
 * ```
 *
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.statement.HttpStatement.body)
 *
 * @param block A suspend function that handles the streamed [response] of type [T].
 * @return The result of [block] applied to the streaming [response].
 *
 * @note For streaming types (such as [ByteReadChannel]), ensure processing completes within [block], as resources
 * will be cleaned up automatically once [block] finishes.
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)bodyBlock:(id<OICCKotlinSuspendFunction1>)block completionHandler:(void (^)(id _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("body(block:completionHandler:)")));

/**
 * Executes the HTTP statement and returns the full [HttpResponse].
 *
 * Once the method completes, the response body is downloaded fully into memory, and the connection is released.
 * This is suitable for requests where the entire response body is needed at once.
 *
 * For retrieving a specific data type directly, consider using [body<T>()].
 *
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.statement.HttpStatement.execute)
 *
 * @return [HttpResponse] The complete response with the body loaded into memory.
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)executeWithCompletionHandler:(void (^)(OICCKtor_client_coreHttpResponse * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("execute(completionHandler:)")));

/**
 * Executes the HTTP statement and invokes the provided [block] with the streaming [HttpResponse].
 *
 * The [response] holds an open network connection until [block] completes.
 * You can access the response body incrementally (streaming) or load it entirely with [body<T>()].
 *
 * After [block] finishes, the [response] is finalized based on the engine's configuration—either discarded
 * or released.
 * The [response] object should not be accessed outside of [block] as it will be canceled upon
 * block completion.
 *
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.statement.HttpStatement.execute)
 *
 * @param block A suspend function that receives the [HttpResponse] for streaming.
 * @return The result of executing [block] with the streaming [response].
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)executeBlock:(id<OICCKotlinSuspendFunction1>)block completionHandler:(void (^)(id _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("execute(block:completionHandler:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@end


/**
 * Provides data structure for associating a [String] with a [List] of Strings
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.StringValues)
 */
__attribute__((swift_name("Ktor_utilsStringValues")))
@protocol OICCKtor_utilsStringValues
@required

/**
 * Checks if the given [name] exists in the map
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.StringValues.contains)
 */
- (BOOL)containsName:(NSString *)name __attribute__((swift_name("contains(name:)")));

/**
 * Checks if the given [name] and [value] pair exists in the map
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.StringValues.contains)
 */
- (BOOL)containsName:(NSString *)name value:(NSString *)value __attribute__((swift_name("contains(name:value:)")));

/**
 * Gets all entries from the map
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.StringValues.entries)
 */
- (NSSet<id<OICCKotlinMapEntry>> *)entries __attribute__((swift_name("entries()")));

/**
 * Iterates over all entries in this map and calls [body] for each pair
 *
 * Can be optimized in implementations
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.StringValues.forEach)
 */
- (void)forEachBody:(void (^)(NSString *, NSArray<NSString *> *))body __attribute__((swift_name("forEach(body:)")));

/**
 * Gets first value from the list of values associated with a [name], or null if the name is not present
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.StringValues.get)
 */
- (NSString * _Nullable)getName:(NSString *)name __attribute__((swift_name("get(name:)")));

/**
 * Gets all values associated with the [name], or null if the name is not present
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.StringValues.getAll)
 */
- (NSArray<NSString *> * _Nullable)getAllName:(NSString *)name __attribute__((swift_name("getAll(name:)")));

/**
 * Checks if this map is empty
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.StringValues.isEmpty)
 */
- (BOOL)isEmpty __attribute__((swift_name("isEmpty()")));

/**
 * Gets all names from the map
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.StringValues.names)
 */
- (NSSet<NSString *> *)names __attribute__((swift_name("names()")));

/**
 * Specifies if map has case-sensitive or case-insensitive names
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.StringValues.caseInsensitiveName)
 */
@property (readonly) BOOL caseInsensitiveName __attribute__((swift_name("caseInsensitiveName")));
@end


/**
 * Represents HTTP parameters as a map from case-insensitive names to collection of [String] values
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.Parameters)
 */
__attribute__((swift_name("Ktor_httpParameters")))
@protocol OICCKtor_httpParameters <OICCKtor_utilsStringValues>
@required
@end


/**
 * Base interface representing a [HttpClient] plugin.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.plugins.HttpClientPlugin)
 */
__attribute__((swift_name("Ktor_client_coreHttpClientPlugin")))
@protocol OICCKtor_client_coreHttpClientPlugin
@required

/**
 * Installs the [plugin] class for a [HttpClient] defined at [scope].
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.plugins.HttpClientPlugin.install)
 */
- (void)installPlugin:(id)plugin scope:(OICCKtor_client_coreHttpClient *)scope __attribute__((swift_name("install(plugin:scope:)")));

/**
 * Builds a [TPlugin] by calling the [block] with a [TConfig] config instance as receiver.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.plugins.HttpClientPlugin.prepare)
 */
- (id)prepareBlock:(void (^)(id))block __attribute__((swift_name("prepare(block:)")));

/**
 * The [AttributeKey] for this plugin.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.plugins.HttpClientPlugin.key)
 */
@property (readonly) OICCKtor_utilsAttributeKey<id> *key __attribute__((swift_name("key")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.3")
*/
__attribute__((swift_name("KotlinCoroutineContext")))
@protocol OICCKotlinCoroutineContext
@required
- (id _Nullable)foldInitial:(id _Nullable)initial operation:(id _Nullable (^)(id _Nullable, id<OICCKotlinCoroutineContextElement>))operation __attribute__((swift_name("fold(initial:operation:)")));
- (id<OICCKotlinCoroutineContextElement> _Nullable)getKey:(id<OICCKotlinCoroutineContextKey>)key __attribute__((swift_name("get(key:)")));
- (id<OICCKotlinCoroutineContext>)minusKeyKey:(id<OICCKotlinCoroutineContextKey>)key __attribute__((swift_name("minusKey(key:)")));
- (id<OICCKotlinCoroutineContext>)plusContext:(id<OICCKotlinCoroutineContext>)context __attribute__((swift_name("plus(context:)")));
@end


/**
 * Actual data of the [HttpRequest], including [url], [method], [headers], [body] and [executionContext].
 * Built by [HttpRequestBuilder].
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpRequestData)
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpRequestData")))
@interface OICCKtor_client_coreHttpRequestData : OICCBase
- (instancetype)initWithUrl:(OICCKtor_httpUrl *)url method:(OICCKtor_httpHttpMethod *)method headers:(id<OICCKtor_httpHeaders>)headers body:(OICCKtor_httpOutgoingContent *)body executionContext:(id<OICCKotlinx_coroutines_coreJob>)executionContext attributes:(id<OICCKtor_utilsAttributes>)attributes __attribute__((swift_name("init(url:method:headers:body:executionContext:attributes:)"))) __attribute__((objc_designated_initializer));

/**
 * Retrieve extension by its key.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpRequestData.getCapabilityOrNull)
 */
- (id _Nullable)getCapabilityOrNullKey:(id<OICCKtor_client_coreHttpClientEngineCapability>)key __attribute__((swift_name("getCapabilityOrNull(key:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id<OICCKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property (readonly) OICCKtor_httpOutgoingContent *body __attribute__((swift_name("body")));
@property (readonly) id<OICCKotlinx_coroutines_coreJob> executionContext __attribute__((swift_name("executionContext")));
@property (readonly) id<OICCKtor_httpHeaders> headers __attribute__((swift_name("headers")));
@property (readonly) OICCKtor_httpHttpMethod *method __attribute__((swift_name("method")));
@property (readonly) OICCKtor_httpUrl *url __attribute__((swift_name("url")));
@end


/**
 * Data prepared for [HttpResponse].
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpResponseData)
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpResponseData")))
@interface OICCKtor_client_coreHttpResponseData : OICCBase
- (instancetype)initWithStatusCode:(OICCKtor_httpHttpStatusCode *)statusCode requestTime:(OICCKtor_utilsGMTDate *)requestTime headers:(id<OICCKtor_httpHeaders>)headers version:(OICCKtor_httpHttpProtocolVersion *)version body:(id)body callContext:(id<OICCKotlinCoroutineContext>)callContext __attribute__((swift_name("init(statusCode:requestTime:headers:version:body:callContext:)"))) __attribute__((objc_designated_initializer));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id body __attribute__((swift_name("body")));
@property (readonly) id<OICCKotlinCoroutineContext> callContext __attribute__((swift_name("callContext")));
@property (readonly) id<OICCKtor_httpHeaders> headers __attribute__((swift_name("headers")));
@property (readonly) OICCKtor_utilsGMTDate *requestTime __attribute__((swift_name("requestTime")));
@property (readonly) OICCKtor_utilsGMTDate *responseTime __attribute__((swift_name("responseTime")));
@property (readonly) OICCKtor_httpHttpStatusCode *statusCode __attribute__((swift_name("statusCode")));
@property (readonly) OICCKtor_httpHttpProtocolVersion *version __attribute__((swift_name("version")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpClientCall.Companion")))
@interface OICCKtor_client_coreHttpClientCallCompanion : OICCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) OICCKtor_client_coreHttpClientCallCompanion *shared __attribute__((swift_name("shared")));
@end


/**
 * Ktor type information.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.reflect.TypeInfo)
 *
 * @property type Source KClass<*>
 * @property kotlinType Kotlin reified type with all generic type parameters.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsTypeInfo")))
@interface OICCKtor_utilsTypeInfo : OICCBase
- (instancetype)initWithType:(id<OICCKotlinKClass>)type kotlinType:(id<OICCKotlinKType> _Nullable)kotlinType __attribute__((swift_name("init(type:kotlinType:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithType:(id<OICCKotlinKClass>)type reifiedType:(id<OICCKotlinKType>)reifiedType kotlinType:(id<OICCKotlinKType> _Nullable)kotlinType __attribute__((swift_name("init(type:reifiedType:kotlinType:)"))) __attribute__((objc_designated_initializer)) __attribute__((deprecated("Use constructor without reifiedType parameter.")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id<OICCKotlinKType> _Nullable kotlinType __attribute__((swift_name("kotlinType")));
@property (readonly) id<OICCKotlinKClass> type __attribute__((swift_name("type")));
@end


/**
 * Channel for asynchronous reading of sequences of bytes.
 * This is a **single-reader channel**.
 *
 * Operations on this channel cannot be invoked concurrently.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.utils.io.ByteReadChannel)
 */
__attribute__((swift_name("Ktor_ioByteReadChannel")))
@protocol OICCKtor_ioByteReadChannel
@required

/**
 * Suspend the channel until it has [min] bytes or gets closed. Throws exception if the channel was closed with an
 * error. If there are bytes available in the channel, this function returns immediately.
 *
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.utils.io.ByteReadChannel.awaitContent)
 *
 * @return return `false` eof is reached, otherwise `true`.
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)awaitContentMin:(int32_t)min completionHandler:(void (^)(OICCBoolean * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("awaitContent(min:completionHandler:)")));
- (void)cancelCause:(OICCKotlinThrowable * _Nullable)cause __attribute__((swift_name("cancel(cause:)")));
@property (readonly) OICCKotlinThrowable * _Nullable closedCause __attribute__((swift_name("closedCause")));
@property (readonly) BOOL isClosedForRead __attribute__((swift_name("isClosedForRead")));
@property (readonly) id<OICCKotlinx_io_coreSource> readBuffer __attribute__((swift_name("readBuffer")));
@end


/**
 * Map of attributes accessible by [AttributeKey] in a typed manner
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.Attributes)
 */
__attribute__((swift_name("Ktor_utilsAttributes")))
@protocol OICCKtor_utilsAttributes
@required

/**
 * Gets a value of the attribute for the specified [key], or calls supplied [block] to compute its value
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.Attributes.computeIfAbsent)
 */
- (id)computeIfAbsentKey:(OICCKtor_utilsAttributeKey<id> *)key block:(id (^)(void))block __attribute__((swift_name("computeIfAbsent(key:block:)")));

/**
 * Checks if an attribute with the specified [key] exists
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.Attributes.contains)
 */
- (BOOL)containsKey:(OICCKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("contains(key:)")));

/**
 * Gets a value of the attribute for the specified [key], or throws an exception if an attribute doesn't exist
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.Attributes.get)
 */
- (id)getKey_:(OICCKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("get(key_:)")));

/**
 * Gets a value of the attribute for the specified [key], or return `null` if an attribute doesn't exist
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.Attributes.getOrNull)
 */
- (id _Nullable)getOrNullKey:(OICCKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("getOrNull(key:)")));

/**
 * Creates or changes an attribute with the specified [key] using [value]
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.Attributes.put)
 */
- (void)putKey:(OICCKtor_utilsAttributeKey<id> *)key value:(id)value __attribute__((swift_name("put(key:value:)")));

/**
 * Removes an attribute with the specified [key]
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.Attributes.remove)
 */
- (void)removeKey:(OICCKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("remove(key:)")));

/**
 * Creates or changes an attribute with the specified [key] using [value]
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.Attributes.set)
 */
- (void)setKey:(OICCKtor_utilsAttributeKey<id> *)key value:(id)value __attribute__((swift_name("set(key:value:)")));

/**
 * Removes an attribute with the specified [key] and returns its current value, throws an exception if an attribute doesn't exist
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.Attributes.take)
 */
- (id)takeKey:(OICCKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("take(key:)")));

/**
 * Removes an attribute with the specified [key] and returns its current value, returns `null` if an attribute doesn't exist
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.Attributes.takeOrNull)
 */
- (id _Nullable)takeOrNullKey:(OICCKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("takeOrNull(key:)")));

/**
 * Returns [List] of all [AttributeKey] instances in this map
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.Attributes.allKeys)
 */
@property (readonly) NSArray<OICCKtor_utilsAttributeKey<id> *> *allKeys __attribute__((swift_name("allKeys")));
@end


/**
 * A request for [HttpClient], first part of [HttpClientCall].
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpRequest)
 */
__attribute__((swift_name("Ktor_client_coreHttpRequest")))
@protocol OICCKtor_client_coreHttpRequest <OICCKtor_httpHttpMessage, OICCKotlinx_coroutines_coreCoroutineScope>
@required

/**
 * Typed [Attributes] associated to this call serving as a lightweight container.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpRequest.attributes)
 */
@property (readonly) id<OICCKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));

/**
 * The associated [HttpClientCall] containing both
 * the underlying [HttpClientCall.request] and [HttpClientCall.response].
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpRequest.call)
 */
@property (readonly) OICCKtor_client_coreHttpClientCall *call __attribute__((swift_name("call")));

/**
 * An [OutgoingContent] representing the request body
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpRequest.content)
 */
@property (readonly) OICCKtor_httpOutgoingContent *content __attribute__((swift_name("content")));

/**
 * The [HttpMethod] or HTTP VERB used for this request.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpRequest.method)
 */
@property (readonly) OICCKtor_httpHttpMethod *method __attribute__((swift_name("method")));

/**
 * The [Url] representing the endpoint and the uri for this request.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpRequest.url)
 */
@property (readonly) OICCKtor_httpUrl *url __attribute__((swift_name("url")));
@end


/**
 * Represents HTTP headers as a map from case-insensitive names to collection of [String] values
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.Headers)
 */
__attribute__((swift_name("Ktor_httpHeaders")))
@protocol OICCKtor_httpHeaders <OICCKtor_utilsStringValues>
@required
@end


/**
 * Date in GMT timezone
 *
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.date.GMTDate)
 *
 * @property seconds: seconds from 0 to 60(last is for leap second)
 * @property minutes: minutes from 0 to 59
 * @property hours: hours from 0 to 23
 * @property dayOfWeek an instance of the corresponding day of week
 * @property dayOfMonth: day of month from 1 to 31
 * @property dayOfYear: day of year from 1 to 366
 * @property month an instance of the corresponding month
 * @property year: year in common era(CE: https://en.wikipedia.org/wiki/Common_Era)
 *
 * @property timestamp is a number of epoch milliseconds
 *
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsGMTDate")))
@interface OICCKtor_utilsGMTDate : OICCBase <OICCKotlinComparable>
- (instancetype)initWithSeconds:(int32_t)seconds minutes:(int32_t)minutes hours:(int32_t)hours dayOfWeek:(OICCKtor_utilsWeekDay *)dayOfWeek dayOfMonth:(int32_t)dayOfMonth dayOfYear:(int32_t)dayOfYear month:(OICCKtor_utilsMonth *)month year:(int32_t)year timestamp:(int64_t)timestamp __attribute__((swift_name("init(seconds:minutes:hours:dayOfWeek:dayOfMonth:dayOfYear:month:year:timestamp:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) OICCKtor_utilsGMTDateCompanion *companion __attribute__((swift_name("companion")));
- (int32_t)compareToOther:(OICCKtor_utilsGMTDate *)other __attribute__((swift_name("compareTo(other:)")));
- (OICCKtor_utilsGMTDate *)doCopy __attribute__((swift_name("doCopy()")));
- (OICCKtor_utilsGMTDate *)doCopySeconds:(int32_t)seconds minutes:(int32_t)minutes hours:(int32_t)hours dayOfWeek:(OICCKtor_utilsWeekDay *)dayOfWeek dayOfMonth:(int32_t)dayOfMonth dayOfYear:(int32_t)dayOfYear month:(OICCKtor_utilsMonth *)month year:(int32_t)year timestamp:(int64_t)timestamp __attribute__((swift_name("doCopy(seconds:minutes:hours:dayOfWeek:dayOfMonth:dayOfYear:month:year:timestamp:)")));

/**
 * Date in GMT timezone
 *
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.date.GMTDate)
 *
 * @property seconds: seconds from 0 to 60(last is for leap second)
 * @property minutes: minutes from 0 to 59
 * @property hours: hours from 0 to 23
 * @property dayOfWeek an instance of the corresponding day of week
 * @property dayOfMonth: day of month from 1 to 31
 * @property dayOfYear: day of year from 1 to 366
 * @property month an instance of the corresponding month
 * @property year: year in common era(CE: https://en.wikipedia.org/wiki/Common_Era)
 *
 * @property timestamp is a number of epoch milliseconds
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * Date in GMT timezone
 *
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.date.GMTDate)
 *
 * @property seconds: seconds from 0 to 60(last is for leap second)
 * @property minutes: minutes from 0 to 59
 * @property hours: hours from 0 to 23
 * @property dayOfWeek an instance of the corresponding day of week
 * @property dayOfMonth: day of month from 1 to 31
 * @property dayOfYear: day of year from 1 to 366
 * @property month an instance of the corresponding month
 * @property year: year in common era(CE: https://en.wikipedia.org/wiki/Common_Era)
 *
 * @property timestamp is a number of epoch milliseconds
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * Date in GMT timezone
 *
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.date.GMTDate)
 *
 * @property seconds: seconds from 0 to 60(last is for leap second)
 * @property minutes: minutes from 0 to 59
 * @property hours: hours from 0 to 23
 * @property dayOfWeek an instance of the corresponding day of week
 * @property dayOfMonth: day of month from 1 to 31
 * @property dayOfYear: day of year from 1 to 366
 * @property month an instance of the corresponding month
 * @property year: year in common era(CE: https://en.wikipedia.org/wiki/Common_Era)
 *
 * @property timestamp is a number of epoch milliseconds
 */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t dayOfMonth __attribute__((swift_name("dayOfMonth")));
@property (readonly) OICCKtor_utilsWeekDay *dayOfWeek __attribute__((swift_name("dayOfWeek")));
@property (readonly) int32_t dayOfYear __attribute__((swift_name("dayOfYear")));
@property (readonly) int32_t hours __attribute__((swift_name("hours")));
@property (readonly) int32_t minutes __attribute__((swift_name("minutes")));
@property (readonly) OICCKtor_utilsMonth *month __attribute__((swift_name("month")));
@property (readonly) int32_t seconds __attribute__((swift_name("seconds")));
@property (readonly) int64_t timestamp __attribute__((swift_name("timestamp")));
@property (readonly) int32_t year __attribute__((swift_name("year")));
@end


/**
 * Represents an HTTP protocol version.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.HttpProtocolVersion)
 *
 * @property name specifies name of the protocol, e.g. "HTTP".
 * @property major specifies protocol major version.
 * @property minor specifies protocol minor version.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpProtocolVersion")))
@interface OICCKtor_httpHttpProtocolVersion : OICCBase
- (instancetype)initWithName:(NSString *)name major:(int32_t)major minor:(int32_t)minor __attribute__((swift_name("init(name:major:minor:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) OICCKtor_httpHttpProtocolVersionCompanion *companion __attribute__((swift_name("companion")));
- (OICCKtor_httpHttpProtocolVersion *)doCopyName:(NSString *)name major:(int32_t)major minor:(int32_t)minor __attribute__((swift_name("doCopy(name:major:minor:)")));

/**
 * Represents an HTTP protocol version.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.HttpProtocolVersion)
 *
 * @property name specifies name of the protocol, e.g. "HTTP".
 * @property major specifies protocol major version.
 * @property minor specifies protocol minor version.
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * Represents an HTTP protocol version.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.HttpProtocolVersion)
 *
 * @property name specifies name of the protocol, e.g. "HTTP".
 * @property major specifies protocol major version.
 * @property minor specifies protocol minor version.
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t major __attribute__((swift_name("major")));
@property (readonly) int32_t minor __attribute__((swift_name("minor")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerializersModule")))
@interface OICCKotlinx_serialization_coreSerializersModule : OICCBase

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)dumpToCollector:(id<OICCKotlinx_serialization_coreSerializersModuleCollector>)collector __attribute__((swift_name("dumpTo(collector:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id<OICCKotlinx_serialization_coreKSerializer> _Nullable)getContextualKClass:(id<OICCKotlinKClass>)kClass typeArgumentsSerializers:(NSArray<id<OICCKotlinx_serialization_coreKSerializer>> *)typeArgumentsSerializers __attribute__((swift_name("getContextual(kClass:typeArgumentsSerializers:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id<OICCKotlinx_serialization_coreSerializationStrategy> _Nullable)getPolymorphicBaseClass:(id<OICCKotlinKClass>)baseClass value:(id)value __attribute__((swift_name("getPolymorphic(baseClass:value:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id<OICCKotlinx_serialization_coreDeserializationStrategy> _Nullable)getPolymorphicBaseClass:(id<OICCKotlinKClass>)baseClass serializedClassName:(NSString * _Nullable)serializedClassName __attribute__((swift_name("getPolymorphic(baseClass:serializedClassName:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_serialization_jsonJson.Default")))
@interface OICCKotlinx_serialization_jsonJsonDefault : OICCKotlinx_serialization_jsonJson
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)default_ __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) OICCKotlinx_serialization_jsonJsonDefault *shared __attribute__((swift_name("shared")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable(with=NormalClass(value=kotlinx/serialization/json/JsonElementSerializer))
*/
__attribute__((swift_name("Kotlinx_serialization_jsonJsonElement")))
@interface OICCKotlinx_serialization_jsonJsonElement : OICCBase
@property (class, readonly, getter=companion) OICCKotlinx_serialization_jsonJsonElementCompanion *companion __attribute__((swift_name("companion")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_serialization_jsonJsonConfiguration")))
@interface OICCKotlinx_serialization_jsonJsonConfiguration : OICCBase
- (NSString *)description __attribute__((swift_name("description()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) BOOL allowComments __attribute__((swift_name("allowComments")));
@property (readonly) BOOL allowSpecialFloatingPointValues __attribute__((swift_name("allowSpecialFloatingPointValues")));
@property (readonly) BOOL allowStructuredMapKeys __attribute__((swift_name("allowStructuredMapKeys")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) BOOL allowTrailingComma __attribute__((swift_name("allowTrailingComma")));
@property (readonly) NSString *classDiscriminator __attribute__((swift_name("classDiscriminator")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property OICCKotlinx_serialization_jsonClassDiscriminatorMode *classDiscriminatorMode __attribute__((swift_name("classDiscriminatorMode")));
@property (readonly) BOOL coerceInputValues __attribute__((swift_name("coerceInputValues")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) BOOL decodeEnumsCaseInsensitive __attribute__((swift_name("decodeEnumsCaseInsensitive")));
@property (readonly) BOOL encodeDefaults __attribute__((swift_name("encodeDefaults")));
@property (readonly) BOOL explicitNulls __attribute__((swift_name("explicitNulls")));
@property (readonly) BOOL ignoreUnknownKeys __attribute__((swift_name("ignoreUnknownKeys")));
@property (readonly) BOOL isLenient __attribute__((swift_name("isLenient")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) id<OICCKotlinx_serialization_jsonJsonNamingStrategy> _Nullable namingStrategy __attribute__((swift_name("namingStrategy")));
@property (readonly) BOOL prettyPrint __attribute__((swift_name("prettyPrint")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) NSString *prettyPrintIndent __attribute__((swift_name("prettyPrintIndent")));
@property (readonly) BOOL useAlternativeNames __attribute__((swift_name("useAlternativeNames")));
@property (readonly) BOOL useArrayPolymorphism __attribute__((swift_name("useArrayPolymorphism")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="2.3")
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinInstant")))
@interface OICCKotlinInstant : OICCBase <OICCKotlinComparable>
@property (class, readonly, getter=companion) OICCKotlinInstantCompanion *companion __attribute__((swift_name("companion")));
- (int32_t)compareToOther:(OICCKotlinInstant *)other __attribute__((swift_name("compareTo(other:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (OICCKotlinInstant *)minusDuration:(int64_t)duration __attribute__((swift_name("minus(duration:)")));
- (int64_t)minusOther:(OICCKotlinInstant *)other __attribute__((swift_name("minus(other:)")));
- (OICCKotlinInstant *)plusDuration:(int64_t)duration __attribute__((swift_name("plus(duration:)")));
- (int64_t)toEpochMilliseconds __attribute__((swift_name("toEpochMilliseconds()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int64_t epochSeconds __attribute__((swift_name("epochSeconds")));
@property (readonly) int32_t nanosecondsOfSecond __attribute__((swift_name("nanosecondsOfSecond")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.3")
*/
__attribute__((swift_name("KotlinContinuation")))
@protocol OICCKotlinContinuation
@required
- (void)resumeWithResult:(id _Nullable)result __attribute__((swift_name("resumeWith(result:)")));
@property (readonly) id<OICCKotlinCoroutineContext> context __attribute__((swift_name("context")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreCancellableContinuation")))
@protocol OICCKotlinx_coroutines_coreCancellableContinuation <OICCKotlinContinuation>
@required
- (BOOL)cancelCause_:(OICCKotlinThrowable * _Nullable)cause __attribute__((swift_name("cancel(cause_:)")));

/**
 * @note annotations
 *   kotlinx.coroutines.InternalCoroutinesApi
*/
- (void)completeResumeToken:(id)token __attribute__((swift_name("completeResume(token:)")));

/**
 * @note annotations
 *   kotlinx.coroutines.InternalCoroutinesApi
*/
- (void)doInitCancellability __attribute__((swift_name("doInitCancellability()")));
- (void)invokeOnCancellationHandler:(void (^)(OICCKotlinThrowable * _Nullable cause))handler __attribute__((swift_name("invokeOnCancellation(handler:)")));
- (void)resumeValue:(id _Nullable)value onCancellation:(void (^ _Nullable)(OICCKotlinThrowable *cause, id _Nullable value, id<OICCKotlinCoroutineContext> context))onCancellation __attribute__((swift_name("resume(value:onCancellation:)")));
- (void)resumeValue:(id _Nullable)value onCancellation_:(void (^ _Nullable)(OICCKotlinThrowable *cause))onCancellation __attribute__((swift_name("resume(value:onCancellation_:)"))) __attribute__((deprecated("Use the overload that also accepts the `value` and the coroutine context in lambda")));

/**
 * @note annotations
 *   kotlinx.coroutines.ExperimentalCoroutinesApi
*/
- (void)resumeUndispatched:(OICCKotlinx_coroutines_coreCoroutineDispatcher *)receiver value:(id _Nullable)value __attribute__((swift_name("resumeUndispatched(_:value:)")));

/**
 * @note annotations
 *   kotlinx.coroutines.ExperimentalCoroutinesApi
*/
- (void)resumeUndispatchedWithException:(OICCKotlinx_coroutines_coreCoroutineDispatcher *)receiver exception:(OICCKotlinThrowable *)exception __attribute__((swift_name("resumeUndispatchedWithException(_:exception:)")));

/**
 * @note annotations
 *   kotlinx.coroutines.InternalCoroutinesApi
*/
- (id _Nullable)tryResumeValue:(id _Nullable)value idempotent:(id _Nullable)idempotent __attribute__((swift_name("tryResume(value:idempotent:)")));

/**
 * @note annotations
 *   kotlinx.coroutines.InternalCoroutinesApi
*/
- (id _Nullable)tryResumeValue:(id _Nullable)value idempotent:(id _Nullable)idempotent onCancellation:(void (^ _Nullable)(OICCKotlinThrowable *cause, id _Nullable value, id<OICCKotlinCoroutineContext> context))onCancellation __attribute__((swift_name("tryResume(value:idempotent:onCancellation:)")));

/**
 * @note annotations
 *   kotlinx.coroutines.InternalCoroutinesApi
*/
- (id _Nullable)tryResumeWithExceptionException:(OICCKotlinThrowable *)exception __attribute__((swift_name("tryResumeWithException(exception:)")));
@property (readonly) BOOL isActive __attribute__((swift_name("isActive")));
@property (readonly) BOOL isCancelled __attribute__((swift_name("isCancelled")));
@property (readonly) BOOL isCompleted __attribute__((swift_name("isCompleted")));
@end

__attribute__((swift_name("Ktor_utilsStringValuesBuilder")))
@protocol OICCKtor_utilsStringValuesBuilder
@required
- (void)appendName:(NSString *)name value:(NSString *)value __attribute__((swift_name("append(name:value:)")));
- (void)appendAllStringValues:(id<OICCKtor_utilsStringValues>)stringValues __attribute__((swift_name("appendAll(stringValues:)")));
- (void)appendAllName:(NSString *)name values:(id)values __attribute__((swift_name("appendAll(name:values:)")));
- (void)appendMissingStringValues:(id<OICCKtor_utilsStringValues>)stringValues __attribute__((swift_name("appendMissing(stringValues:)")));
- (void)appendMissingName:(NSString *)name values:(id)values __attribute__((swift_name("appendMissing(name:values:)")));
- (id<OICCKtor_utilsStringValues>)build __attribute__((swift_name("build()")));
- (void)clear __attribute__((swift_name("clear()")));
- (BOOL)containsName:(NSString *)name __attribute__((swift_name("contains(name:)")));
- (BOOL)containsName:(NSString *)name value:(NSString *)value __attribute__((swift_name("contains(name:value:)")));
- (NSSet<id<OICCKotlinMapEntry>> *)entries __attribute__((swift_name("entries()")));
- (NSString * _Nullable)getName:(NSString *)name __attribute__((swift_name("get(name:)")));
- (NSArray<NSString *> * _Nullable)getAllName:(NSString *)name __attribute__((swift_name("getAll(name:)")));
- (BOOL)isEmpty __attribute__((swift_name("isEmpty()")));
- (NSSet<NSString *> *)names __attribute__((swift_name("names()")));
- (void)removeName:(NSString *)name __attribute__((swift_name("remove(name:)")));
- (BOOL)removeName:(NSString *)name value:(NSString *)value __attribute__((swift_name("remove(name:value:)")));
- (void)removeKeysWithNoEntries __attribute__((swift_name("removeKeysWithNoEntries()")));
- (void)setName:(NSString *)name value:(NSString *)value __attribute__((swift_name("set(name:value:)")));
@property (readonly) BOOL caseInsensitiveName __attribute__((swift_name("caseInsensitiveName")));
@end

__attribute__((swift_name("Ktor_utilsStringValuesBuilderImpl")))
@interface OICCKtor_utilsStringValuesBuilderImpl : OICCBase <OICCKtor_utilsStringValuesBuilder>
- (instancetype)initWithCaseInsensitiveName:(BOOL)caseInsensitiveName size:(int32_t)size __attribute__((swift_name("init(caseInsensitiveName:size:)"))) __attribute__((objc_designated_initializer));
- (void)appendName:(NSString *)name value:(NSString *)value __attribute__((swift_name("append(name:value:)")));
- (void)appendAllStringValues:(id<OICCKtor_utilsStringValues>)stringValues __attribute__((swift_name("appendAll(stringValues:)")));
- (void)appendAllName:(NSString *)name values:(id)values __attribute__((swift_name("appendAll(name:values:)")));
- (void)appendMissingStringValues:(id<OICCKtor_utilsStringValues>)stringValues __attribute__((swift_name("appendMissing(stringValues:)")));
- (void)appendMissingName:(NSString *)name values:(id)values __attribute__((swift_name("appendMissing(name:values:)")));
- (id<OICCKtor_utilsStringValues>)build __attribute__((swift_name("build()")));
- (void)clear __attribute__((swift_name("clear()")));
- (BOOL)containsName:(NSString *)name __attribute__((swift_name("contains(name:)")));
- (BOOL)containsName:(NSString *)name value:(NSString *)value __attribute__((swift_name("contains(name:value:)")));
- (NSSet<id<OICCKotlinMapEntry>> *)entries __attribute__((swift_name("entries()")));
- (NSString * _Nullable)getName:(NSString *)name __attribute__((swift_name("get(name:)")));
- (NSArray<NSString *> * _Nullable)getAllName:(NSString *)name __attribute__((swift_name("getAll(name:)")));
- (BOOL)isEmpty __attribute__((swift_name("isEmpty()")));
- (NSSet<NSString *> *)names __attribute__((swift_name("names()")));
- (void)removeName:(NSString *)name __attribute__((swift_name("remove(name:)")));
- (BOOL)removeName:(NSString *)name value:(NSString *)value __attribute__((swift_name("remove(name:value:)")));
- (void)removeKeysWithNoEntries __attribute__((swift_name("removeKeysWithNoEntries()")));
- (void)setName:(NSString *)name value:(NSString *)value __attribute__((swift_name("set(name:value:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)validateNameName:(NSString *)name __attribute__((swift_name("validateName(name:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)validateValueValue:(NSString *)value __attribute__((swift_name("validateValue(value:)")));
@property (readonly) BOOL caseInsensitiveName __attribute__((swift_name("caseInsensitiveName")));

/**
 * @note This property has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
@property (readonly) OICCMutableDictionary<NSString *, NSMutableArray<NSString *> *> *values __attribute__((swift_name("values")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHeadersBuilder")))
@interface OICCKtor_httpHeadersBuilder : OICCKtor_utilsStringValuesBuilderImpl
- (instancetype)initWithSize:(int32_t)size __attribute__((swift_name("init(size:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCaseInsensitiveName:(BOOL)caseInsensitiveName size:(int32_t)size __attribute__((swift_name("init(caseInsensitiveName:size:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (id<OICCKtor_httpHeaders>)build __attribute__((swift_name("build()")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)validateNameName:(NSString *)name __attribute__((swift_name("validateName(name:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)validateValueValue:(NSString *)value __attribute__((swift_name("validateValue(value:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpRequestBuilder.Companion")))
@interface OICCKtor_client_coreHttpRequestBuilderCompanion : OICCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) OICCKtor_client_coreHttpRequestBuilderCompanion *shared __attribute__((swift_name("shared")));
@end


/**
 * Represents a capability that an [HttpClientEngine] can support, with [T] representing the type
 * of configuration or metadata associated with the capability.
 *
 * Capabilities are used to declare optional features or behaviors that an engine may support,
 * such as WebSocket communication, HTTP/2, or custom timeouts. They enable plugins and request
 * builders to configure engine-specific functionality by associating a capability with a
 * specific configuration.
 *
 * Capabilities can be set on a per-request basis using the `HttpRequestBuilder.setCapability` method,
 * allowing users to configure engine-specific behavior for individual requests.
 *
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.engine.HttpClientEngineCapability)
 *
 * @param T The type of the configuration or metadata associated with this capability.
 *
 * Example:
 * Suppose you have a custom capability for WebSocket support that requires a specific configuration:
 * ```kotlin
 * object WebSocketCapability : HttpClientEngineCapability<WebSocketConfig>
 *
 * data class WebSocketConfig(val maxFrameSize: Int, val pingIntervalMillis: Long)
 * ```
 *
 * Setting a capability in a request:
 * ```kotlin
 * client.request {
 *     setCapability(WebSocketCapability, WebSocketConfig(
 *         maxFrameSize = 65536,
 *         pingIntervalMillis = 30000
 *     ))
 * }
 * ```
 *
 * Engine Example:
 * A custom engine implementation can declare support for specific capabilities in its `supportedCapabilities` property:
 * ```kotlin
 * override val supportedCapabilities: Set<HttpClientEngineCapability<*>> = setOf(WebSocketCapability)
 * ```
 *
 * Plugin Integration Example:
 * Plugins use capabilities to interact with engine-specific features. For example:
 * ```kotlin
 * if (engine.supportedCapabilities.contains(WebSocketCapability)) {
 *     // Configure WebSocket behavior if supported by the engine
 * }
 * ```
 *
 * When creating a custom capability:
 * - Define a singleton object implementing `HttpClientEngineCapability`.
 * - Use the type parameter [T] to provide the associated configuration type or metadata.
 * - Ensure that engines supporting the capability handle the associated configuration properly.
 */
__attribute__((swift_name("Ktor_client_coreHttpClientEngineCapability")))
@protocol OICCKtor_client_coreHttpClientEngineCapability
@required
@end

__attribute__((swift_name("KotlinCoroutineContextElement")))
@protocol OICCKotlinCoroutineContextElement <OICCKotlinCoroutineContext>
@required
@property (readonly) id<OICCKotlinCoroutineContextKey> key __attribute__((swift_name("key")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreJob")))
@protocol OICCKotlinx_coroutines_coreJob <OICCKotlinCoroutineContextElement>
@required

/**
 * @note annotations
 *   kotlinx.coroutines.InternalCoroutinesApi
*/
- (id<OICCKotlinx_coroutines_coreChildHandle>)attachChildChild:(id<OICCKotlinx_coroutines_coreChildJob>)child __attribute__((swift_name("attachChild(child:)")));
- (void)cancelCause__:(OICCKotlinCancellationException * _Nullable)cause __attribute__((swift_name("cancel(cause__:)")));

/**
 * @note annotations
 *   kotlinx.coroutines.InternalCoroutinesApi
*/
- (OICCKotlinCancellationException *)getCancellationException __attribute__((swift_name("getCancellationException()")));
- (id<OICCKotlinx_coroutines_coreDisposableHandle>)invokeOnCompletionHandler:(void (^)(OICCKotlinThrowable * _Nullable cause))handler __attribute__((swift_name("invokeOnCompletion(handler:)")));

/**
 * @note annotations
 *   kotlinx.coroutines.InternalCoroutinesApi
*/
- (id<OICCKotlinx_coroutines_coreDisposableHandle>)invokeOnCompletionOnCancelling:(BOOL)onCancelling invokeImmediately:(BOOL)invokeImmediately handler:(void (^)(OICCKotlinThrowable * _Nullable cause))handler __attribute__((swift_name("invokeOnCompletion(onCancelling:invokeImmediately:handler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)joinWithCompletionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("join(completionHandler:)")));
- (id<OICCKotlinx_coroutines_coreJob>)plusOther:(id<OICCKotlinx_coroutines_coreJob>)other __attribute__((swift_name("plus(other:)"))) __attribute__((unavailable("Operator '+' on two Job objects is meaningless. Job is a coroutine context element and `+` is a set-sum operator for coroutine contexts. The job to the right of `+` just replaces the job the left of `+`.")));
- (BOOL)start __attribute__((swift_name("start()")));
@property (readonly) id<OICCKotlinSequence> children __attribute__((swift_name("children")));
@property (readonly) BOOL isActive __attribute__((swift_name("isActive")));
@property (readonly) BOOL isCancelled __attribute__((swift_name("isCancelled")));
@property (readonly) BOOL isCompleted __attribute__((swift_name("isCompleted")));
@property (readonly) id<OICCKotlinx_coroutines_coreSelectClause0> onJoin __attribute__((swift_name("onJoin")));

/**
 * @note annotations
 *   kotlinx.coroutines.ExperimentalCoroutinesApi
*/
@property (readonly) id<OICCKotlinx_coroutines_coreJob> _Nullable parent __attribute__((swift_name("parent")));
@end


/**
 * Represents an HTTP method (verb)
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.HttpMethod)
 *
 * @property value contains method name
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpMethod")))
@interface OICCKtor_httpHttpMethod : OICCBase
- (instancetype)initWithValue:(NSString *)value __attribute__((swift_name("init(value:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) OICCKtor_httpHttpMethodCompanion *companion __attribute__((swift_name("companion")));
- (OICCKtor_httpHttpMethod *)doCopyValue:(NSString *)value __attribute__((swift_name("doCopy(value:)")));

/**
 * Represents an HTTP method (verb)
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.HttpMethod)
 *
 * @property value contains method name
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * Represents an HTTP method (verb)
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.HttpMethod)
 *
 * @property value contains method name
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end


/**
 * Represents URL protocol
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.URLProtocol)
 *
 * @property name of protocol (schema)
 * @property defaultPort default port for protocol or `-1` if not known
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpURLProtocol")))
@interface OICCKtor_httpURLProtocol : OICCBase <OICCKtor_ioJvmSerializable>
- (instancetype)initWithName:(NSString *)name defaultPort:(int32_t)defaultPort __attribute__((swift_name("init(name:defaultPort:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) OICCKtor_httpURLProtocolCompanion *companion __attribute__((swift_name("companion")));
- (OICCKtor_httpURLProtocol *)doCopyName:(NSString *)name defaultPort:(int32_t)defaultPort __attribute__((swift_name("doCopy(name:defaultPort:)")));

/**
 * Represents URL protocol
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.URLProtocol)
 *
 * @property name of protocol (schema)
 * @property defaultPort default port for protocol or `-1` if not known
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * Represents URL protocol
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.URLProtocol)
 *
 * @property name of protocol (schema)
 * @property defaultPort default port for protocol or `-1` if not known
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * Represents URL protocol
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.URLProtocol)
 *
 * @property name of protocol (schema)
 * @property defaultPort default port for protocol or `-1` if not known
 */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t defaultPort __attribute__((swift_name("defaultPort")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpURLBuilder.Companion")))
@interface OICCKtor_httpURLBuilderCompanion : OICCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) OICCKtor_httpURLBuilderCompanion *shared __attribute__((swift_name("shared")));
@end

__attribute__((swift_name("Ktor_httpParametersBuilder")))
@protocol OICCKtor_httpParametersBuilder <OICCKtor_utilsStringValuesBuilder>
@required
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpStatusCode.Companion")))
@interface OICCKtor_httpHttpStatusCodeCompanion : OICCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) OICCKtor_httpHttpStatusCodeCompanion *shared __attribute__((swift_name("shared")));

/**
 * Creates an instance of [HttpStatusCode] with the given numeric value.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.HttpStatusCode.Companion.fromValue)
 */
- (OICCKtor_httpHttpStatusCode *)fromValueValue:(int32_t)value __attribute__((swift_name("fromValue(value:)")));
@property (readonly) OICCKtor_httpHttpStatusCode *Accepted __attribute__((swift_name("Accepted")));
@property (readonly) OICCKtor_httpHttpStatusCode *BadGateway __attribute__((swift_name("BadGateway")));
@property (readonly) OICCKtor_httpHttpStatusCode *BadRequest __attribute__((swift_name("BadRequest")));
@property (readonly) OICCKtor_httpHttpStatusCode *Conflict __attribute__((swift_name("Conflict")));
@property (readonly) OICCKtor_httpHttpStatusCode *Continue __attribute__((swift_name("Continue")));
@property (readonly) OICCKtor_httpHttpStatusCode *Created __attribute__((swift_name("Created")));
@property (readonly) OICCKtor_httpHttpStatusCode *ExpectationFailed __attribute__((swift_name("ExpectationFailed")));
@property (readonly) OICCKtor_httpHttpStatusCode *FailedDependency __attribute__((swift_name("FailedDependency")));
@property (readonly) OICCKtor_httpHttpStatusCode *Forbidden __attribute__((swift_name("Forbidden")));
@property (readonly) OICCKtor_httpHttpStatusCode *Found __attribute__((swift_name("Found")));
@property (readonly) OICCKtor_httpHttpStatusCode *GatewayTimeout __attribute__((swift_name("GatewayTimeout")));
@property (readonly) OICCKtor_httpHttpStatusCode *Gone __attribute__((swift_name("Gone")));
@property (readonly) OICCKtor_httpHttpStatusCode *InsufficientStorage __attribute__((swift_name("InsufficientStorage")));
@property (readonly) OICCKtor_httpHttpStatusCode *InternalServerError __attribute__((swift_name("InternalServerError")));
@property (readonly) OICCKtor_httpHttpStatusCode *LengthRequired __attribute__((swift_name("LengthRequired")));
@property (readonly) OICCKtor_httpHttpStatusCode *Locked __attribute__((swift_name("Locked")));
@property (readonly) OICCKtor_httpHttpStatusCode *MethodNotAllowed __attribute__((swift_name("MethodNotAllowed")));
@property (readonly) OICCKtor_httpHttpStatusCode *MovedPermanently __attribute__((swift_name("MovedPermanently")));
@property (readonly) OICCKtor_httpHttpStatusCode *MultiStatus __attribute__((swift_name("MultiStatus")));
@property (readonly) OICCKtor_httpHttpStatusCode *MultipleChoices __attribute__((swift_name("MultipleChoices")));
@property (readonly) OICCKtor_httpHttpStatusCode *NoContent __attribute__((swift_name("NoContent")));
@property (readonly) OICCKtor_httpHttpStatusCode *NonAuthoritativeInformation __attribute__((swift_name("NonAuthoritativeInformation")));
@property (readonly) OICCKtor_httpHttpStatusCode *NotAcceptable __attribute__((swift_name("NotAcceptable")));
@property (readonly) OICCKtor_httpHttpStatusCode *NotFound __attribute__((swift_name("NotFound")));
@property (readonly) OICCKtor_httpHttpStatusCode *NotImplemented __attribute__((swift_name("NotImplemented")));
@property (readonly) OICCKtor_httpHttpStatusCode *NotModified __attribute__((swift_name("NotModified")));
@property (readonly) OICCKtor_httpHttpStatusCode *OK __attribute__((swift_name("OK")));
@property (readonly) OICCKtor_httpHttpStatusCode *PartialContent __attribute__((swift_name("PartialContent")));
@property (readonly) OICCKtor_httpHttpStatusCode *PayloadTooLarge __attribute__((swift_name("PayloadTooLarge")));
@property (readonly) OICCKtor_httpHttpStatusCode *PaymentRequired __attribute__((swift_name("PaymentRequired")));
@property (readonly) OICCKtor_httpHttpStatusCode *PermanentRedirect __attribute__((swift_name("PermanentRedirect")));
@property (readonly) OICCKtor_httpHttpStatusCode *PreconditionFailed __attribute__((swift_name("PreconditionFailed")));
@property (readonly) OICCKtor_httpHttpStatusCode *Processing __attribute__((swift_name("Processing")));
@property (readonly) OICCKtor_httpHttpStatusCode *ProxyAuthenticationRequired __attribute__((swift_name("ProxyAuthenticationRequired")));
@property (readonly) OICCKtor_httpHttpStatusCode *RequestHeaderFieldTooLarge __attribute__((swift_name("RequestHeaderFieldTooLarge")));
@property (readonly) OICCKtor_httpHttpStatusCode *RequestTimeout __attribute__((swift_name("RequestTimeout")));
@property (readonly) OICCKtor_httpHttpStatusCode *RequestURITooLong __attribute__((swift_name("RequestURITooLong")));
@property (readonly) OICCKtor_httpHttpStatusCode *RequestedRangeNotSatisfiable __attribute__((swift_name("RequestedRangeNotSatisfiable")));
@property (readonly) OICCKtor_httpHttpStatusCode *ResetContent __attribute__((swift_name("ResetContent")));
@property (readonly) OICCKtor_httpHttpStatusCode *SeeOther __attribute__((swift_name("SeeOther")));
@property (readonly) OICCKtor_httpHttpStatusCode *ServiceUnavailable __attribute__((swift_name("ServiceUnavailable")));
@property (readonly) OICCKtor_httpHttpStatusCode *SwitchProxy __attribute__((swift_name("SwitchProxy")));
@property (readonly) OICCKtor_httpHttpStatusCode *SwitchingProtocols __attribute__((swift_name("SwitchingProtocols")));
@property (readonly) OICCKtor_httpHttpStatusCode *TemporaryRedirect __attribute__((swift_name("TemporaryRedirect")));
@property (readonly) OICCKtor_httpHttpStatusCode *TooEarly __attribute__((swift_name("TooEarly")));
@property (readonly) OICCKtor_httpHttpStatusCode *TooManyRequests __attribute__((swift_name("TooManyRequests")));
@property (readonly) OICCKtor_httpHttpStatusCode *Unauthorized __attribute__((swift_name("Unauthorized")));
@property (readonly) OICCKtor_httpHttpStatusCode *UnprocessableEntity __attribute__((swift_name("UnprocessableEntity")));
@property (readonly) OICCKtor_httpHttpStatusCode *UnsupportedMediaType __attribute__((swift_name("UnsupportedMediaType")));
@property (readonly) OICCKtor_httpHttpStatusCode *UpgradeRequired __attribute__((swift_name("UpgradeRequired")));
@property (readonly) OICCKtor_httpHttpStatusCode *UseProxy __attribute__((swift_name("UseProxy")));
@property (readonly) OICCKtor_httpHttpStatusCode *VariantAlsoNegotiates __attribute__((swift_name("VariantAlsoNegotiates")));
@property (readonly) OICCKtor_httpHttpStatusCode *VersionNotSupported __attribute__((swift_name("VersionNotSupported")));

/**
 * All known status codes
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.HttpStatusCode.Companion.allStatusCodes)
 */
@property (readonly) NSArray<OICCKtor_httpHttpStatusCode *> *allStatusCodes __attribute__((swift_name("allStatusCodes")));
@end


/**
 * Serves as the base interface for an [HttpClient]'s engine.
 *
 * An `HttpClientEngine` represents the underlying network implementation that
 * performs HTTP requests and handles responses.
 * Developers can implement this interface to create custom engines for use with [HttpClient].
 *
 * This interface provides a set of properties and methods that define the
 * contract for configuring, executing, and managing HTTP requests within the engine.
 *
 * For a base implementation that handles common engine functionality, see [HttpClientEngineBase].
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.engine.HttpClientEngine)
 */
__attribute__((swift_name("Ktor_client_coreHttpClientEngine")))
@protocol OICCKtor_client_coreHttpClientEngine <OICCKotlinx_coroutines_coreCoroutineScope, OICCKtor_ioCloseable>
@required

/**
 * Executes an HTTP request and produces an HTTP response.
 *
 * This function takes [HttpRequestData], which contains all details of the HTTP request,
 * and returns [HttpResponseData] with the server's response, including headers, status code, and body.
 *
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.engine.HttpClientEngine.execute)
 *
 * @param data The [HttpRequestData] representing the request to be executed.
 * @return An [HttpResponseData] object containing the server's response.
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)executeData:(OICCKtor_client_coreHttpRequestData *)data completionHandler:(void (^)(OICCKtor_client_coreHttpResponseData * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("execute(data:completionHandler:)")));

/**
 * Installs the engine into an [HttpClient].
 *
 * This method is called when the engine is being set up within an `HttpClient`.
 * Use it to register interceptors, validate configuration, or prepare the engine
 * for use with the client.
 *
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.engine.HttpClientEngine.install)
 *
 * @param client The [HttpClient] instance to which the engine is being installed.
 */
- (void)installClient:(OICCKtor_client_coreHttpClient *)client __attribute__((swift_name("install(client:)")));

/**
 * Provides access to the engine's configuration via [HttpClientEngineConfig].
 *
 * The [config] object stores user-defined parameters or settings that control
 * how the engine operates. When creating a custom engine, this property
 * should return the specific configuration implementation.
 *
 * Example:
 * ```kotlin
 * override val config: HttpClientEngineConfig = CustomEngineConfig()
 * ```
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.engine.HttpClientEngine.config)
 */
@property (readonly) OICCKtor_client_coreHttpClientEngineConfig *config __attribute__((swift_name("config")));

/**
 * Specifies the [CoroutineDispatcher] for I/O operations in the engine.
 *
 * This dispatcher is used for all network-related operations, such as
 * sending requests and receiving responses.
 * By default, it should be optimized for I/O tasks.
 *
 * Example:
 * ```kotlin
 * override val dispatcher: CoroutineDispatcher = Dispatchers.IO
 * ```
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.engine.HttpClientEngine.dispatcher)
 */
@property (readonly) OICCKotlinx_coroutines_coreCoroutineDispatcher *dispatcher __attribute__((swift_name("dispatcher")));

/**
 * Specifies the set of capabilities supported by this HTTP client engine.
 *
 * Capabilities provide a mechanism for plugins and other components to
 * determine whether the engine supports specific features such as timeouts,
 * WebSocket communication, HTTP/2, HTTP/3, or other advanced networking
 * capabilities. This allows seamless integration of features based on the
 * engine's functionality.
 *
 * Each capability is represented as an instance of [HttpClientEngineCapability],
 * which can carry additional metadata or configurations for the capability.
 *
 * Example:
 * ```kotlin
 * override val supportedCapabilities: Set<HttpClientEngineCapability<*>> = setOf(
 *     WebSocketCapability,
 *     Http2Capability,
 *     TimeoutCapability
 * )
 * ```
 *
 * **Usage in Plugins**:
 * Plugins can check if the engine supports a specific capability before
 * applying behavior:
 * ```kotlin
 * if (engine.supportedCapabilities.contains(WebSocketCapability)) {
 *     // Configure WebSocket-specific settings
 * }
 * ```
 *
 * When implementing a custom engine, ensure this property accurately reflects
 * the engine's abilities to avoid unexpected plugin behavior or runtime errors.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.engine.HttpClientEngine.supportedCapabilities)
 */
@property (readonly) NSSet<id<OICCKtor_client_coreHttpClientEngineCapability>> *supportedCapabilities __attribute__((swift_name("supportedCapabilities")));
@end


/**
 * Base configuration for [HttpClientEngine].
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.engine.HttpClientEngineConfig)
 */
__attribute__((swift_name("Ktor_client_coreHttpClientEngineConfig")))
@interface OICCKtor_client_coreHttpClientEngineConfig : OICCBase

/**
 * Base configuration for [HttpClientEngine].
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.engine.HttpClientEngineConfig)
 */
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));

/**
 * Base configuration for [HttpClientEngine].
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.engine.HttpClientEngineConfig)
 */
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));

/**
 * Allow specifying the coroutine dispatcher to use for IO operations.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.engine.HttpClientEngineConfig.dispatcher)
 */
@property OICCKotlinx_coroutines_coreCoroutineDispatcher * _Nullable dispatcher __attribute__((swift_name("dispatcher")));

/**
 * Enables HTTP pipelining advice.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.engine.HttpClientEngineConfig.pipelining)
 */
@property BOOL pipelining __attribute__((swift_name("pipelining")));

/**
 * Specifies a proxy address to use.
 * Uses a system proxy by default.
 *
 * You can learn more from [Proxy](https://ktor.io/docs/proxy.html).
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.engine.HttpClientEngineConfig.proxy)
 */
@property OICCKtor_client_coreProxyConfig * _Nullable proxy __attribute__((swift_name("proxy")));

/**
 * Specifies network threads count advice.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.engine.HttpClientEngineConfig.threadsCount)
 */
@property int32_t threadsCount __attribute__((swift_name("threadsCount"))) __attribute__((unavailable("The [threadsCount] property is deprecated. Consider setting [dispatcher] instead.")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_eventsEvents")))
@interface OICCKtor_eventsEvents : OICCBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));

/**
 * Raises the event specified by [definition] with the [value] and calls all handlers.
 *
 * Handlers are called in order of subscriptions.
 * If some handler throws an exception, all remaining handlers will still run. The exception will eventually be re-thrown.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.events.Events.raise)
 */
- (void)raiseDefinition:(OICCKtor_eventsEventDefinition<id> *)definition value:(id _Nullable)value __attribute__((swift_name("raise(definition:value:)")));

/**
 * Subscribe [handler] to an event specified by [definition]
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.events.Events.subscribe)
 */
- (id<OICCKotlinx_coroutines_coreDisposableHandle>)subscribeDefinition:(OICCKtor_eventsEventDefinition<id> *)definition handler:(void (^)(id _Nullable))handler __attribute__((swift_name("subscribe(definition:handler:)")));

/**
 * Unsubscribe [handler] from an event specified by [definition]
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.events.Events.unsubscribe)
 */
- (void)unsubscribeDefinition:(OICCKtor_eventsEventDefinition<id> *)definition handler:(void (^)(id _Nullable))handler __attribute__((swift_name("unsubscribe(definition:handler:)")));
@end


/**
 * Represents an execution pipeline for asynchronous extensible computations
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.pipeline.Pipeline)
 */
__attribute__((swift_name("Ktor_utilsPipeline")))
@interface OICCKtor_utilsPipeline<TSubject, TContext> : OICCBase
- (instancetype)initWithPhases:(OICCKotlinArray<OICCKtor_utilsPipelinePhase *> *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithPhase:(OICCKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<OICCKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer));

/**
 * Adds [phase] to the end of this pipeline
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.pipeline.Pipeline.addPhase)
 */
- (void)addPhasePhase:(OICCKtor_utilsPipelinePhase *)phase __attribute__((swift_name("addPhase(phase:)")));

/**
 * Invoked after an interceptor has been installed
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.pipeline.Pipeline.afterIntercepted)
 */
- (void)afterIntercepted __attribute__((swift_name("afterIntercepted()")));

/**
 * Executes this pipeline in the given [context] and with the given [subject]
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.pipeline.Pipeline.execute)
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)executeContext:(TContext)context subject:(TSubject)subject completionHandler:(void (^)(TSubject _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("execute(context:subject:completionHandler:)")));

/**
 * Inserts [phase] after the [reference] phase. If there are other phases inserted after [reference], then [phase]
 * will be inserted after them.
 * Example:
 * ```
 * val pipeline = Pipeline<String, String>(a)
 * pipeline.insertPhaseAfter(a, b)
 * pipeline.insertPhaseAfter(a, c)
 * assertEquals(listOf(a, b, c), pipeline.items)
 * ```
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.pipeline.Pipeline.insertPhaseAfter)
 */
- (void)insertPhaseAfterReference:(OICCKtor_utilsPipelinePhase *)reference phase:(OICCKtor_utilsPipelinePhase *)phase __attribute__((swift_name("insertPhaseAfter(reference:phase:)")));

/**
 * Inserts [phase] before the [reference] phase.
 * Example:
 * ```
 * val pipeline = Pipeline<String, String>(c)
 * pipeline.insertPhaseBefore(c, a)
 * pipeline.insertPhaseBefore(c, b)
 * assertEquals(listOf(a, b, c), pipeline.items)
 * ```
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.pipeline.Pipeline.insertPhaseBefore)
 */
- (void)insertPhaseBeforeReference:(OICCKtor_utilsPipelinePhase *)reference phase:(OICCKtor_utilsPipelinePhase *)phase __attribute__((swift_name("insertPhaseBefore(reference:phase:)")));

/**
 * Adds [block] to the [phase] of this pipeline
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.pipeline.Pipeline.intercept)
 */
- (void)interceptPhase:(OICCKtor_utilsPipelinePhase *)phase block:(id<OICCKotlinSuspendFunction2>)block __attribute__((swift_name("intercept(phase:block:)")));
- (NSArray<id<OICCKotlinSuspendFunction2>> *)interceptorsForPhasePhase:(OICCKtor_utilsPipelinePhase *)phase __attribute__((swift_name("interceptorsForPhase(phase:)")));

/**
 * Merges another pipeline into this pipeline, maintaining relative phases order
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.pipeline.Pipeline.merge)
 */
- (void)mergeFrom:(OICCKtor_utilsPipeline<TSubject, TContext> *)from __attribute__((swift_name("merge(from:)")));
- (void)mergePhasesFrom:(OICCKtor_utilsPipeline<TSubject, TContext> *)from __attribute__((swift_name("mergePhases(from:)")));

/**
 * Reset current pipeline from other.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.pipeline.Pipeline.resetFrom)
 */
- (void)resetFromFrom:(OICCKtor_utilsPipeline<TSubject, TContext> *)from __attribute__((swift_name("resetFrom(from:)")));
- (NSString *)description __attribute__((swift_name("description()")));

/**
 * Provides common place to store pipeline attributes
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.pipeline.Pipeline.attributes)
 */
@property (readonly) id<OICCKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));

/**
 * Indicated if debug mode is enabled. In debug mode users will get more details in the stacktrace.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.pipeline.Pipeline.developmentMode)
 */
@property (readonly) BOOL developmentMode __attribute__((swift_name("developmentMode")));

/**
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.pipeline.Pipeline.isEmpty)
 *
 * @return `true` if there are no interceptors installed regardless number of phases
 */
@property (readonly, getter=isEmpty_) BOOL isEmpty __attribute__((swift_name("isEmpty")));

/**
 * Phases of this pipeline
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.pipeline.Pipeline.items)
 */
@property (readonly) NSArray<OICCKtor_utilsPipelinePhase *> *items __attribute__((swift_name("items")));
@end


/**
 * [HttpClient] Pipeline used for receiving [HttpResponse] without any processing.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.statement.HttpReceivePipeline)
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpReceivePipeline")))
@interface OICCKtor_client_coreHttpReceivePipeline : OICCKtor_utilsPipeline<OICCKtor_client_coreHttpResponse *, OICCKotlinUnit *>
- (instancetype)initWithDevelopmentMode:(BOOL)developmentMode __attribute__((swift_name("init(developmentMode:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithPhases:(OICCKotlinArray<OICCKtor_utilsPipelinePhase *> *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithPhase:(OICCKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<OICCKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) OICCKtor_client_coreHttpReceivePipelinePhases *companion __attribute__((swift_name("companion")));
@property (readonly) BOOL developmentMode __attribute__((swift_name("developmentMode")));
@end


/**
 * An [HttpClient]'s pipeline used for executing [HttpRequest].
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpRequestPipeline)
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpRequestPipeline")))
@interface OICCKtor_client_coreHttpRequestPipeline : OICCKtor_utilsPipeline<id, OICCKtor_client_coreHttpRequestBuilder *>
- (instancetype)initWithDevelopmentMode:(BOOL)developmentMode __attribute__((swift_name("init(developmentMode:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithPhases:(OICCKotlinArray<OICCKtor_utilsPipelinePhase *> *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithPhase:(OICCKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<OICCKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) OICCKtor_client_coreHttpRequestPipelinePhases *companion __attribute__((swift_name("companion")));
@property (readonly) BOOL developmentMode __attribute__((swift_name("developmentMode")));
@end


/**
 * [HttpClient] Pipeline used for executing [HttpResponse].
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.statement.HttpResponsePipeline)
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpResponsePipeline")))
@interface OICCKtor_client_coreHttpResponsePipeline : OICCKtor_utilsPipeline<OICCKtor_client_coreHttpResponseContainer *, OICCKtor_client_coreHttpClientCall *>
- (instancetype)initWithDevelopmentMode:(BOOL)developmentMode __attribute__((swift_name("init(developmentMode:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithPhases:(OICCKotlinArray<OICCKtor_utilsPipelinePhase *> *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithPhase:(OICCKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<OICCKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) OICCKtor_client_coreHttpResponsePipelinePhases *companion __attribute__((swift_name("companion")));
@property (readonly) BOOL developmentMode __attribute__((swift_name("developmentMode")));
@end


/**
 * An [HttpClient]'s pipeline used for sending [HttpRequest] to a remote server.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpSendPipeline)
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpSendPipeline")))
@interface OICCKtor_client_coreHttpSendPipeline : OICCKtor_utilsPipeline<id, OICCKtor_client_coreHttpRequestBuilder *>
- (instancetype)initWithDevelopmentMode:(BOOL)developmentMode __attribute__((swift_name("init(developmentMode:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithPhases:(OICCKotlinArray<OICCKtor_utilsPipelinePhase *> *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithPhase:(OICCKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<OICCKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) OICCKtor_client_coreHttpSendPipelinePhases *companion __attribute__((swift_name("companion")));
@property (readonly) BOOL developmentMode __attribute__((swift_name("developmentMode")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreEncoder")))
@protocol OICCKotlinx_serialization_coreEncoder
@required
- (id<OICCKotlinx_serialization_coreCompositeEncoder>)beginCollectionDescriptor:(id<OICCKotlinx_serialization_coreSerialDescriptor>)descriptor collectionSize:(int32_t)collectionSize __attribute__((swift_name("beginCollection(descriptor:collectionSize:)")));
- (id<OICCKotlinx_serialization_coreCompositeEncoder>)beginStructureDescriptor:(id<OICCKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("beginStructure(descriptor:)")));
- (void)encodeBooleanValue:(BOOL)value __attribute__((swift_name("encodeBoolean(value:)")));
- (void)encodeByteValue:(int8_t)value __attribute__((swift_name("encodeByte(value:)")));
- (void)encodeCharValue:(unichar)value __attribute__((swift_name("encodeChar(value:)")));
- (void)encodeDoubleValue:(double)value __attribute__((swift_name("encodeDouble(value:)")));
- (void)encodeEnumEnumDescriptor:(id<OICCKotlinx_serialization_coreSerialDescriptor>)enumDescriptor index:(int32_t)index __attribute__((swift_name("encodeEnum(enumDescriptor:index:)")));
- (void)encodeFloatValue:(float)value __attribute__((swift_name("encodeFloat(value:)")));
- (id<OICCKotlinx_serialization_coreEncoder>)encodeInlineDescriptor:(id<OICCKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("encodeInline(descriptor:)")));
- (void)encodeIntValue:(int32_t)value __attribute__((swift_name("encodeInt(value:)")));
- (void)encodeLongValue:(int64_t)value __attribute__((swift_name("encodeLong(value:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNotNullMark __attribute__((swift_name("encodeNotNullMark()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNull __attribute__((swift_name("encodeNull()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNullableSerializableValueSerializer:(id<OICCKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeNullableSerializableValue(serializer:value:)")));
- (void)encodeSerializableValueSerializer:(id<OICCKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeSerializableValue(serializer:value:)")));
- (void)encodeShortValue:(int16_t)value __attribute__((swift_name("encodeShort(value:)")));
- (void)encodeStringValue:(NSString *)value __attribute__((swift_name("encodeString(value:)")));
@property (readonly) OICCKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerialDescriptor")))
@protocol OICCKotlinx_serialization_coreSerialDescriptor
@required
- (NSArray<id<OICCKotlinAnnotation>> *)getElementAnnotationsIndex:(int32_t)index __attribute__((swift_name("getElementAnnotations(index:)")));
- (id<OICCKotlinx_serialization_coreSerialDescriptor>)getElementDescriptorIndex:(int32_t)index __attribute__((swift_name("getElementDescriptor(index:)")));
- (int32_t)getElementIndexName:(NSString *)name __attribute__((swift_name("getElementIndex(name:)")));
- (NSString *)getElementNameIndex:(int32_t)index __attribute__((swift_name("getElementName(index:)")));
- (BOOL)isElementOptionalIndex:(int32_t)index __attribute__((swift_name("isElementOptional(index:)")));
@property (readonly) NSArray<id<OICCKotlinAnnotation>> *annotations __attribute__((swift_name("annotations")));
@property (readonly) int32_t elementsCount __attribute__((swift_name("elementsCount")));
@property (readonly) BOOL isInline __attribute__((swift_name("isInline")));
@property (readonly) BOOL isNullable __attribute__((swift_name("isNullable")));
@property (readonly) OICCKotlinx_serialization_coreSerialKind *kind __attribute__((swift_name("kind")));
@property (readonly) NSString *serialName __attribute__((swift_name("serialName")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreDecoder")))
@protocol OICCKotlinx_serialization_coreDecoder
@required
- (id<OICCKotlinx_serialization_coreCompositeDecoder>)beginStructureDescriptor:(id<OICCKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("beginStructure(descriptor:)")));
- (BOOL)decodeBoolean __attribute__((swift_name("decodeBoolean()")));
- (int8_t)decodeByte __attribute__((swift_name("decodeByte()")));
- (unichar)decodeChar __attribute__((swift_name("decodeChar()")));
- (double)decodeDouble __attribute__((swift_name("decodeDouble()")));
- (int32_t)decodeEnumEnumDescriptor:(id<OICCKotlinx_serialization_coreSerialDescriptor>)enumDescriptor __attribute__((swift_name("decodeEnum(enumDescriptor:)")));
- (float)decodeFloat __attribute__((swift_name("decodeFloat()")));
- (id<OICCKotlinx_serialization_coreDecoder>)decodeInlineDescriptor:(id<OICCKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("decodeInline(descriptor:)")));
- (int32_t)decodeInt __attribute__((swift_name("decodeInt()")));
- (int64_t)decodeLong __attribute__((swift_name("decodeLong()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (BOOL)decodeNotNullMark __attribute__((swift_name("decodeNotNullMark()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (OICCKotlinNothing * _Nullable)decodeNull __attribute__((swift_name("decodeNull()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id _Nullable)decodeNullableSerializableValueDeserializer:(id<OICCKotlinx_serialization_coreDeserializationStrategy>)deserializer __attribute__((swift_name("decodeNullableSerializableValue(deserializer:)")));
- (id _Nullable)decodeSerializableValueDeserializer:(id<OICCKotlinx_serialization_coreDeserializationStrategy>)deserializer __attribute__((swift_name("decodeSerializableValue(deserializer:)")));
- (int16_t)decodeShort __attribute__((swift_name("decodeShort()")));
- (NSString *)decodeString __attribute__((swift_name("decodeString()")));
@property (readonly) OICCKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((swift_name("KotlinIterator")))
@protocol OICCKotlinIterator
@required
- (BOOL)hasNext __attribute__((swift_name("hasNext()")));
- (id _Nullable)next __attribute__((swift_name("next()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Oidc_preferencesPreferencesSingletonFactory.Companion")))
@interface OICCOidc_preferencesPreferencesSingletonFactoryCompanion : OICCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) OICCOidc_preferencesPreferencesSingletonFactoryCompanion *shared __attribute__((swift_name("shared")));

/**
 * @note This property has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
@property id<OICCPreferences> _Nullable INSTANCE __attribute__((swift_name("INSTANCE")));

/**
 * @note This property has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
@property (readonly) id<OICCKotlinx_coroutines_coreMutex> mutex __attribute__((swift_name("mutex")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpUrl.Companion")))
@interface OICCKtor_httpUrlCompanion : OICCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) OICCKtor_httpUrlCompanion *shared __attribute__((swift_name("shared")));
- (id<OICCKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreFlowCollector")))
@protocol OICCKotlinx_coroutines_coreFlowCollector
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)emitValue:(id _Nullable)value completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("emit(value:completionHandler:)")));
@end

__attribute__((swift_name("KotlinFunction")))
@protocol OICCKotlinFunction
@required
@end

__attribute__((swift_name("KotlinSuspendFunction1")))
@protocol OICCKotlinSuspendFunction1 <OICCKotlinFunction>
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeP1:(id _Nullable)p1 completionHandler:(void (^)(id _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(p1:completionHandler:)")));
@end

__attribute__((swift_name("KotlinMapEntry")))
@protocol OICCKotlinMapEntry
@required
@property (readonly) id _Nullable key __attribute__((swift_name("key")));
@property (readonly) id _Nullable value __attribute__((swift_name("value")));
@end


/**
 * Specifies a key for an attribute in [Attributes]
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.AttributeKey)
 *
 * @param T is a type of the value stored in the attribute
 * @property name is a name of the attribute for diagnostic purposes. Can't be blank
 * @property type the recorded kotlin type of T
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsAttributeKey")))
@interface OICCKtor_utilsAttributeKey<T> : OICCBase

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithName:(NSString *)name type:(OICCKtor_utilsTypeInfo *)type __attribute__((swift_name("init(name:type:)"))) __attribute__((objc_designated_initializer));
- (OICCKtor_utilsAttributeKey<T> *)doCopyName:(NSString *)name type:(OICCKtor_utilsTypeInfo *)type __attribute__((swift_name("doCopy(name:type:)")));

/**
 * Specifies a key for an attribute in [Attributes]
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.AttributeKey)
 *
 * @param T is a type of the value stored in the attribute
 * @property name is a name of the attribute for diagnostic purposes. Can't be blank
 * @property type the recorded kotlin type of T
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * Specifies a key for an attribute in [Attributes]
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.AttributeKey)
 *
 * @param T is a type of the value stored in the attribute
 * @property name is a name of the attribute for diagnostic purposes. Can't be blank
 * @property type the recorded kotlin type of T
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end

__attribute__((swift_name("KotlinCoroutineContextKey")))
@protocol OICCKotlinCoroutineContextKey
@required
@end


/**
 * Information about the content to be sent to the peer, recognized by a client or server engine
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.content.OutgoingContent)
 */
__attribute__((swift_name("Ktor_httpOutgoingContent")))
@interface OICCKtor_httpOutgoingContent : OICCBase

/**
 * Gets an extension property for this content
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.content.OutgoingContent.getProperty)
 */
- (id _Nullable)getPropertyKey:(OICCKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("getProperty(key:)")));

/**
 * Sets an extension property for this content
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.content.OutgoingContent.setProperty)
 */
- (void)setPropertyKey:(OICCKtor_utilsAttributeKey<id> *)key value:(id _Nullable)value __attribute__((swift_name("setProperty(key:value:)")));

/**
 * Trailers to set when sending this content, will be ignored if request is not in HTTP2 mode
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.content.OutgoingContent.trailers)
 */
- (id<OICCKtor_httpHeaders> _Nullable)trailers __attribute__((swift_name("trailers()")));

/**
 * Specifies content length in bytes for this resource.
 *
 * If null, the resources will be sent as `Transfer-Encoding: chunked`
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.content.OutgoingContent.contentLength)
 */
@property (readonly) OICCLong * _Nullable contentLength __attribute__((swift_name("contentLength")));

/**
 * Specifies [ContentType] for this resource.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.content.OutgoingContent.contentType)
 */
@property (readonly) OICCKtor_httpContentType * _Nullable contentType __attribute__((swift_name("contentType")));

/**
 * Headers to set when sending this content
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.content.OutgoingContent.headers)
 */
@property (readonly) id<OICCKtor_httpHeaders> headers __attribute__((swift_name("headers")));

/**
 * Status code to set when sending this content
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.content.OutgoingContent.status)
 */
@property (readonly) OICCKtor_httpHttpStatusCode * _Nullable status __attribute__((swift_name("status")));
@end

__attribute__((swift_name("KotlinKDeclarationContainer")))
@protocol OICCKotlinKDeclarationContainer
@required
@end

__attribute__((swift_name("KotlinKAnnotatedElement")))
@protocol OICCKotlinKAnnotatedElement
@required
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.1")
*/
__attribute__((swift_name("KotlinKClassifier")))
@protocol OICCKotlinKClassifier
@required
@end

__attribute__((swift_name("KotlinKClass")))
@protocol OICCKotlinKClass <OICCKotlinKDeclarationContainer, OICCKotlinKAnnotatedElement, OICCKotlinKClassifier>
@required

/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.1")
*/
- (BOOL)isInstanceValue:(id _Nullable)value __attribute__((swift_name("isInstance(value:)")));
@property (readonly) NSString * _Nullable qualifiedName __attribute__((swift_name("qualifiedName")));
@property (readonly) NSString * _Nullable simpleName __attribute__((swift_name("simpleName")));
@end

__attribute__((swift_name("KotlinKType")))
@protocol OICCKotlinKType
@required

/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.1")
*/
@property (readonly) NSArray<OICCKotlinKTypeProjection *> *arguments __attribute__((swift_name("arguments")));

/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.1")
*/
@property (readonly) id<OICCKotlinKClassifier> _Nullable classifier __attribute__((swift_name("classifier")));
@property (readonly) BOOL isMarkedNullable __attribute__((swift_name("isMarkedNullable")));
@end

__attribute__((swift_name("Kotlinx_io_coreRawSource")))
@protocol OICCKotlinx_io_coreRawSource <OICCKotlinAutoCloseable>
@required
- (int64_t)readAtMostToSink:(OICCKotlinx_io_coreBuffer *)sink byteCount:(int64_t)byteCount __attribute__((swift_name("readAtMostTo(sink:byteCount:)")));
@end

__attribute__((swift_name("Kotlinx_io_coreSource")))
@protocol OICCKotlinx_io_coreSource <OICCKotlinx_io_coreRawSource>
@required
- (BOOL)exhausted __attribute__((swift_name("exhausted()")));
- (id<OICCKotlinx_io_coreSource>)peek __attribute__((swift_name("peek()")));
- (int32_t)readAtMostToSink:(OICCKotlinByteArray *)sink startIndex:(int32_t)startIndex endIndex:(int32_t)endIndex __attribute__((swift_name("readAtMostTo(sink:startIndex:endIndex:)")));
- (int8_t)readByte __attribute__((swift_name("readByte()")));
- (int32_t)readInt __attribute__((swift_name("readInt()")));
- (int64_t)readLong __attribute__((swift_name("readLong()")));
- (int16_t)readShort __attribute__((swift_name("readShort()")));
- (void)readToSink:(id<OICCKotlinx_io_coreRawSink>)sink byteCount:(int64_t)byteCount __attribute__((swift_name("readTo(sink:byteCount:)")));
- (BOOL)requestByteCount:(int64_t)byteCount __attribute__((swift_name("request(byteCount:)")));
- (void)requireByteCount:(int64_t)byteCount __attribute__((swift_name("require(byteCount:)")));
- (void)skipByteCount:(int64_t)byteCount __attribute__((swift_name("skip(byteCount:)")));
- (int64_t)transferToSink:(id<OICCKotlinx_io_coreRawSink>)sink __attribute__((swift_name("transferTo(sink:)")));

/**
 * @note annotations
 *   kotlinx.io.InternalIoApi
*/
@property (readonly) OICCKotlinx_io_coreBuffer *buffer __attribute__((swift_name("buffer")));
@end


/**
 * Day of week
 * [value] is 3 letter shortcut
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.date.WeekDay)
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsWeekDay")))
@interface OICCKtor_utilsWeekDay : OICCKotlinEnum<OICCKtor_utilsWeekDay *>
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Day of week
 * [value] is 3 letter shortcut
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.date.WeekDay)
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) OICCKtor_utilsWeekDayCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) OICCKtor_utilsWeekDay *monday __attribute__((swift_name("monday")));
@property (class, readonly) OICCKtor_utilsWeekDay *tuesday __attribute__((swift_name("tuesday")));
@property (class, readonly) OICCKtor_utilsWeekDay *wednesday __attribute__((swift_name("wednesday")));
@property (class, readonly) OICCKtor_utilsWeekDay *thursday __attribute__((swift_name("thursday")));
@property (class, readonly) OICCKtor_utilsWeekDay *friday __attribute__((swift_name("friday")));
@property (class, readonly) OICCKtor_utilsWeekDay *saturday __attribute__((swift_name("saturday")));
@property (class, readonly) OICCKtor_utilsWeekDay *sunday __attribute__((swift_name("sunday")));
+ (OICCKotlinArray<OICCKtor_utilsWeekDay *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<OICCKtor_utilsWeekDay *> *entries __attribute__((swift_name("entries")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end


/**
 * Month
 * [value] is 3 letter shortcut
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.date.Month)
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsMonth")))
@interface OICCKtor_utilsMonth : OICCKotlinEnum<OICCKtor_utilsMonth *>
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Month
 * [value] is 3 letter shortcut
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.date.Month)
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) OICCKtor_utilsMonthCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) OICCKtor_utilsMonth *january __attribute__((swift_name("january")));
@property (class, readonly) OICCKtor_utilsMonth *february __attribute__((swift_name("february")));
@property (class, readonly) OICCKtor_utilsMonth *march __attribute__((swift_name("march")));
@property (class, readonly) OICCKtor_utilsMonth *april __attribute__((swift_name("april")));
@property (class, readonly) OICCKtor_utilsMonth *may __attribute__((swift_name("may")));
@property (class, readonly) OICCKtor_utilsMonth *june __attribute__((swift_name("june")));
@property (class, readonly) OICCKtor_utilsMonth *july __attribute__((swift_name("july")));
@property (class, readonly) OICCKtor_utilsMonth *august __attribute__((swift_name("august")));
@property (class, readonly) OICCKtor_utilsMonth *september __attribute__((swift_name("september")));
@property (class, readonly) OICCKtor_utilsMonth *october __attribute__((swift_name("october")));
@property (class, readonly) OICCKtor_utilsMonth *november __attribute__((swift_name("november")));
@property (class, readonly) OICCKtor_utilsMonth *december __attribute__((swift_name("december")));
+ (OICCKotlinArray<OICCKtor_utilsMonth *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<OICCKtor_utilsMonth *> *entries __attribute__((swift_name("entries")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsGMTDate.Companion")))
@interface OICCKtor_utilsGMTDateCompanion : OICCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) OICCKtor_utilsGMTDateCompanion *shared __attribute__((swift_name("shared")));
- (id<OICCKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));

/**
 * An instance of [GMTDate] corresponding to the epoch beginning
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.date.GMTDate.Companion.START)
 */
@property (readonly) OICCKtor_utilsGMTDate *START __attribute__((swift_name("START")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpProtocolVersion.Companion")))
@interface OICCKtor_httpHttpProtocolVersionCompanion : OICCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) OICCKtor_httpHttpProtocolVersionCompanion *shared __attribute__((swift_name("shared")));

/**
 * Creates an instance of [HttpProtocolVersion] from the given parameters.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.HttpProtocolVersion.Companion.fromValue)
 */
- (OICCKtor_httpHttpProtocolVersion *)fromValueName:(NSString *)name major:(int32_t)major minor:(int32_t)minor __attribute__((swift_name("fromValue(name:major:minor:)")));

/**
 * Create an instance of [HttpProtocolVersion] from http string representation.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.HttpProtocolVersion.Companion.parse)
 */
- (OICCKtor_httpHttpProtocolVersion *)parseValue:(id)value __attribute__((swift_name("parse(value:)")));

/**
 * HTTP/1.0 version.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.HttpProtocolVersion.Companion.HTTP_1_0)
 */
@property (readonly) OICCKtor_httpHttpProtocolVersion *HTTP_1_0 __attribute__((swift_name("HTTP_1_0")));

/**
 * HTTP/1.1 version.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.HttpProtocolVersion.Companion.HTTP_1_1)
 */
@property (readonly) OICCKtor_httpHttpProtocolVersion *HTTP_1_1 __attribute__((swift_name("HTTP_1_1")));

/**
 * HTTP/2.0 version.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.HttpProtocolVersion.Companion.HTTP_2_0)
 */
@property (readonly) OICCKtor_httpHttpProtocolVersion *HTTP_2_0 __attribute__((swift_name("HTTP_2_0")));

/**
 * HTTP/3.0 version.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.HttpProtocolVersion.Companion.HTTP_3_0)
 */
@property (readonly) OICCKtor_httpHttpProtocolVersion *HTTP_3_0 __attribute__((swift_name("HTTP_3_0")));

/**
 * QUIC/1.0 version.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.HttpProtocolVersion.Companion.QUIC)
 */
@property (readonly) OICCKtor_httpHttpProtocolVersion *QUIC __attribute__((swift_name("QUIC")));

/**
 * SPDY/3.0 version.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.HttpProtocolVersion.Companion.SPDY_3)
 */
@property (readonly) OICCKtor_httpHttpProtocolVersion *SPDY_3 __attribute__((swift_name("SPDY_3")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
__attribute__((swift_name("Kotlinx_serialization_coreSerializersModuleCollector")))
@protocol OICCKotlinx_serialization_coreSerializersModuleCollector
@required
- (void)contextualKClass:(id<OICCKotlinKClass>)kClass provider:(id<OICCKotlinx_serialization_coreKSerializer> (^)(NSArray<id<OICCKotlinx_serialization_coreKSerializer>> *typeArgumentsSerializers))provider __attribute__((swift_name("contextual(kClass:provider:)")));
- (void)contextualKClass:(id<OICCKotlinKClass>)kClass serializer:(id<OICCKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("contextual(kClass:serializer:)")));
- (void)polymorphicBaseClass:(id<OICCKotlinKClass>)baseClass actualClass:(id<OICCKotlinKClass>)actualClass actualSerializer:(id<OICCKotlinx_serialization_coreKSerializer>)actualSerializer __attribute__((swift_name("polymorphic(baseClass:actualClass:actualSerializer:)")));
- (void)polymorphicDefaultBaseClass:(id<OICCKotlinKClass>)baseClass defaultDeserializerProvider:(id<OICCKotlinx_serialization_coreDeserializationStrategy> _Nullable (^)(NSString * _Nullable className))defaultDeserializerProvider __attribute__((swift_name("polymorphicDefault(baseClass:defaultDeserializerProvider:)"))) __attribute__((deprecated("Deprecated in favor of function with more precise name: polymorphicDefaultDeserializer")));
- (void)polymorphicDefaultDeserializerBaseClass:(id<OICCKotlinKClass>)baseClass defaultDeserializerProvider:(id<OICCKotlinx_serialization_coreDeserializationStrategy> _Nullable (^)(NSString * _Nullable className))defaultDeserializerProvider __attribute__((swift_name("polymorphicDefaultDeserializer(baseClass:defaultDeserializerProvider:)")));
- (void)polymorphicDefaultSerializerBaseClass:(id<OICCKotlinKClass>)baseClass defaultSerializerProvider:(id<OICCKotlinx_serialization_coreSerializationStrategy> _Nullable (^)(id value))defaultSerializerProvider __attribute__((swift_name("polymorphicDefaultSerializer(baseClass:defaultSerializerProvider:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_serialization_jsonJsonElement.Companion")))
@interface OICCKotlinx_serialization_jsonJsonElementCompanion : OICCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) OICCKotlinx_serialization_jsonJsonElementCompanion *shared __attribute__((swift_name("shared")));
- (id<OICCKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_serialization_jsonClassDiscriminatorMode")))
@interface OICCKotlinx_serialization_jsonClassDiscriminatorMode : OICCKotlinEnum<OICCKotlinx_serialization_jsonClassDiscriminatorMode *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) OICCKotlinx_serialization_jsonClassDiscriminatorMode *none __attribute__((swift_name("none")));
@property (class, readonly) OICCKotlinx_serialization_jsonClassDiscriminatorMode *allJsonObjects __attribute__((swift_name("allJsonObjects")));
@property (class, readonly) OICCKotlinx_serialization_jsonClassDiscriminatorMode *polymorphic __attribute__((swift_name("polymorphic")));
+ (OICCKotlinArray<OICCKotlinx_serialization_jsonClassDiscriminatorMode *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<OICCKotlinx_serialization_jsonClassDiscriminatorMode *> *entries __attribute__((swift_name("entries")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
__attribute__((swift_name("Kotlinx_serialization_jsonJsonNamingStrategy")))
@protocol OICCKotlinx_serialization_jsonJsonNamingStrategy
@required
- (NSString *)serialNameForJsonDescriptor:(id<OICCKotlinx_serialization_coreSerialDescriptor>)descriptor elementIndex:(int32_t)elementIndex serialName:(NSString *)serialName __attribute__((swift_name("serialNameForJson(descriptor:elementIndex:serialName:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinInstant.Companion")))
@interface OICCKotlinInstantCompanion : OICCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) OICCKotlinInstantCompanion *shared __attribute__((swift_name("shared")));
- (OICCKotlinInstant *)fromEpochMillisecondsEpochMilliseconds:(int64_t)epochMilliseconds __attribute__((swift_name("fromEpochMilliseconds(epochMilliseconds:)")));
- (OICCKotlinInstant *)fromEpochSecondsEpochSeconds:(int64_t)epochSeconds nanosecondAdjustment:(int32_t)nanosecondAdjustment __attribute__((swift_name("fromEpochSeconds(epochSeconds:nanosecondAdjustment:)")));
- (OICCKotlinInstant *)fromEpochSecondsEpochSeconds:(int64_t)epochSeconds nanosecondAdjustment_:(int64_t)nanosecondAdjustment __attribute__((swift_name("fromEpochSeconds(epochSeconds:nanosecondAdjustment_:)")));
- (OICCKotlinInstant *)now __attribute__((swift_name("now()"))) __attribute__((unavailable("Use Clock.System.now() instead")));
- (OICCKotlinInstant *)parseInput:(id)input __attribute__((swift_name("parse(input:)")));
- (OICCKotlinInstant * _Nullable)parseOrNullInput:(id)input __attribute__((swift_name("parseOrNull(input:)")));
@property (readonly) OICCKotlinInstant *DISTANT_FUTURE __attribute__((swift_name("DISTANT_FUTURE")));
@property (readonly) OICCKotlinInstant *DISTANT_PAST __attribute__((swift_name("DISTANT_PAST")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.3")
*/
__attribute__((swift_name("KotlinAbstractCoroutineContextElement")))
@interface OICCKotlinAbstractCoroutineContextElement : OICCBase <OICCKotlinCoroutineContextElement>
- (instancetype)initWithKey:(id<OICCKotlinCoroutineContextKey>)key __attribute__((swift_name("init(key:)"))) __attribute__((objc_designated_initializer));
@property (readonly) id<OICCKotlinCoroutineContextKey> key __attribute__((swift_name("key")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.3")
*/
__attribute__((swift_name("KotlinContinuationInterceptor")))
@protocol OICCKotlinContinuationInterceptor <OICCKotlinCoroutineContextElement>
@required
- (id<OICCKotlinContinuation>)interceptContinuationContinuation:(id<OICCKotlinContinuation>)continuation __attribute__((swift_name("interceptContinuation(continuation:)")));
- (void)releaseInterceptedContinuationContinuation:(id<OICCKotlinContinuation>)continuation __attribute__((swift_name("releaseInterceptedContinuation(continuation:)")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreCoroutineDispatcher")))
@interface OICCKotlinx_coroutines_coreCoroutineDispatcher : OICCKotlinAbstractCoroutineContextElement <OICCKotlinContinuationInterceptor>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithKey:(id<OICCKotlinCoroutineContextKey>)key __attribute__((swift_name("init(key:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) OICCKotlinx_coroutines_coreCoroutineDispatcherKey *companion __attribute__((swift_name("companion")));
- (void)dispatchContext:(id<OICCKotlinCoroutineContext>)context block:(id<OICCKotlinx_coroutines_coreRunnable>)block __attribute__((swift_name("dispatch(context:block:)")));

/**
 * @note annotations
 *   kotlinx.coroutines.InternalCoroutinesApi
*/
- (void)dispatchYieldContext:(id<OICCKotlinCoroutineContext>)context block:(id<OICCKotlinx_coroutines_coreRunnable>)block __attribute__((swift_name("dispatchYield(context:block:)")));
- (id<OICCKotlinContinuation>)interceptContinuationContinuation:(id<OICCKotlinContinuation>)continuation __attribute__((swift_name("interceptContinuation(continuation:)")));
- (BOOL)isDispatchNeededContext:(id<OICCKotlinCoroutineContext>)context __attribute__((swift_name("isDispatchNeeded(context:)")));
- (OICCKotlinx_coroutines_coreCoroutineDispatcher *)limitedParallelismParallelism:(int32_t)parallelism name:(NSString * _Nullable)name __attribute__((swift_name("limitedParallelism(parallelism:name:)")));
- (OICCKotlinx_coroutines_coreCoroutineDispatcher *)plusOther_:(OICCKotlinx_coroutines_coreCoroutineDispatcher *)other __attribute__((swift_name("plus(other_:)"))) __attribute__((unavailable("Operator '+' on two CoroutineDispatcher objects is meaningless. CoroutineDispatcher is a coroutine context element and `+` is a set-sum operator for coroutine contexts. The dispatcher to the right of `+` just replaces the dispatcher to the left.")));
- (void)releaseInterceptedContinuationContinuation:(id<OICCKotlinContinuation>)continuation __attribute__((swift_name("releaseInterceptedContinuation(continuation:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreDisposableHandle")))
@protocol OICCKotlinx_coroutines_coreDisposableHandle
@required
- (void)dispose __attribute__((swift_name("dispose()")));
@end


/**
 * @note annotations
 *   kotlinx.coroutines.InternalCoroutinesApi
*/
__attribute__((swift_name("Kotlinx_coroutines_coreChildHandle")))
@protocol OICCKotlinx_coroutines_coreChildHandle <OICCKotlinx_coroutines_coreDisposableHandle>
@required

/**
 * @note annotations
 *   kotlinx.coroutines.InternalCoroutinesApi
*/
- (BOOL)childCancelledCause:(OICCKotlinThrowable *)cause __attribute__((swift_name("childCancelled(cause:)")));

/**
 * @note annotations
 *   kotlinx.coroutines.InternalCoroutinesApi
*/
@property (readonly) id<OICCKotlinx_coroutines_coreJob> _Nullable parent __attribute__((swift_name("parent")));
@end


/**
 * @note annotations
 *   kotlinx.coroutines.InternalCoroutinesApi
*/
__attribute__((swift_name("Kotlinx_coroutines_coreChildJob")))
@protocol OICCKotlinx_coroutines_coreChildJob <OICCKotlinx_coroutines_coreJob>
@required

/**
 * @note annotations
 *   kotlinx.coroutines.InternalCoroutinesApi
*/
- (void)parentCancelledParentJob:(id<OICCKotlinx_coroutines_coreParentJob>)parentJob __attribute__((swift_name("parentCancelled(parentJob:)")));
@end

__attribute__((swift_name("KotlinSequence")))
@protocol OICCKotlinSequence
@required
- (id<OICCKotlinIterator>)iterator __attribute__((swift_name("iterator()")));
@end


/**
 * @note annotations
 *   kotlinx.coroutines.InternalCoroutinesApi
*/
__attribute__((swift_name("Kotlinx_coroutines_coreSelectClause")))
@protocol OICCKotlinx_coroutines_coreSelectClause
@required
@property (readonly) id clauseObject __attribute__((swift_name("clauseObject")));
@property (readonly) OICCKotlinUnit *(^(^ _Nullable onCancellationConstructor)(id<OICCKotlinx_coroutines_coreSelectInstance> select, id _Nullable param, id _Nullable internalResult))(OICCKotlinThrowable *, id _Nullable, id<OICCKotlinCoroutineContext>) __attribute__((swift_name("onCancellationConstructor")));
@property (readonly) id _Nullable (^processResFunc)(id clauseObject, id _Nullable param, id _Nullable clauseResult) __attribute__((swift_name("processResFunc")));
@property (readonly) void (^regFunc)(id clauseObject, id<OICCKotlinx_coroutines_coreSelectInstance> select, id _Nullable param) __attribute__((swift_name("regFunc")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreSelectClause0")))
@protocol OICCKotlinx_coroutines_coreSelectClause0 <OICCKotlinx_coroutines_coreSelectClause>
@required
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpMethod.Companion")))
@interface OICCKtor_httpHttpMethodCompanion : OICCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) OICCKtor_httpHttpMethodCompanion *shared __attribute__((swift_name("shared")));

/**
 * Parse HTTP method by [method] string
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.HttpMethod.Companion.parse)
 */
- (OICCKtor_httpHttpMethod *)parseMethod:(NSString *)method __attribute__((swift_name("parse(method:)")));

/**
 * A list of default HTTP methods
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.HttpMethod.Companion.DefaultMethods)
 */
@property (readonly) NSArray<OICCKtor_httpHttpMethod *> *DefaultMethods __attribute__((swift_name("DefaultMethods")));
@property (readonly) OICCKtor_httpHttpMethod *Delete __attribute__((swift_name("Delete")));
@property (readonly) OICCKtor_httpHttpMethod *Get __attribute__((swift_name("Get")));
@property (readonly) OICCKtor_httpHttpMethod *Head __attribute__((swift_name("Head")));
@property (readonly) OICCKtor_httpHttpMethod *Options __attribute__((swift_name("Options")));
@property (readonly) OICCKtor_httpHttpMethod *Patch __attribute__((swift_name("Patch")));
@property (readonly) OICCKtor_httpHttpMethod *Post __attribute__((swift_name("Post")));
@property (readonly) OICCKtor_httpHttpMethod *Put __attribute__((swift_name("Put")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpURLProtocol.Companion")))
@interface OICCKtor_httpURLProtocolCompanion : OICCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) OICCKtor_httpURLProtocolCompanion *shared __attribute__((swift_name("shared")));

/**
 * Create an instance by [name] or use already existing instance
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.URLProtocol.Companion.createOrDefault)
 */
- (OICCKtor_httpURLProtocol *)createOrDefaultName:(NSString *)name __attribute__((swift_name("createOrDefault(name:)")));

/**
 * HTTP with port 80
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.URLProtocol.Companion.HTTP)
 */
@property (readonly) OICCKtor_httpURLProtocol *HTTP __attribute__((swift_name("HTTP")));

/**
 * secure HTTPS with port 443
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.URLProtocol.Companion.HTTPS)
 */
@property (readonly) OICCKtor_httpURLProtocol *HTTPS __attribute__((swift_name("HTTPS")));

/**
 * Socks proxy url protocol.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.URLProtocol.Companion.SOCKS)
 */
@property (readonly) OICCKtor_httpURLProtocol *SOCKS __attribute__((swift_name("SOCKS")));

/**
 * Web socket over HTTP on port 80
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.URLProtocol.Companion.WS)
 */
@property (readonly) OICCKtor_httpURLProtocol *WS __attribute__((swift_name("WS")));

/**
 * Web socket over secure HTTPS on port 443
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.URLProtocol.Companion.WSS)
 */
@property (readonly) OICCKtor_httpURLProtocol *WSS __attribute__((swift_name("WSS")));

/**
 * Protocols by names map
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.URLProtocol.Companion.byName)
 */
@property (readonly) NSDictionary<NSString *, OICCKtor_httpURLProtocol *> *byName __attribute__((swift_name("byName")));
@end


/**
 * Proxy configuration.
 *
 * See [ProxyBuilder] to create proxy.
 *
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.engine.ProxyConfig)
 *
 * @param url: proxy url address.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreProxyConfig")))
@interface OICCKtor_client_coreProxyConfig : OICCBase
- (instancetype)initWithUrl:(OICCKtor_httpUrl *)url __attribute__((swift_name("init(url:)"))) __attribute__((objc_designated_initializer));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) OICCKtor_httpUrl *url __attribute__((swift_name("url")));
@end


/**
 * Definition of an event.
 * Event is used as a key so both [hashCode] and [equals] need to be implemented properly.
 * Inheriting of this class is an experimental feature.
 * Instantiate directly if inheritance not necessary.
 *
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.events.EventDefinition)
 *
 * @param T specifies what is a type of value passed to the event
 */
__attribute__((swift_name("Ktor_eventsEventDefinition")))
@interface OICCKtor_eventsEventDefinition<T> : OICCBase

/**
 * Definition of an event.
 * Event is used as a key so both [hashCode] and [equals] need to be implemented properly.
 * Inheriting of this class is an experimental feature.
 * Instantiate directly if inheritance not necessary.
 *
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.events.EventDefinition)
 *
 * @param T specifies what is a type of value passed to the event
 */
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));

/**
 * Definition of an event.
 * Event is used as a key so both [hashCode] and [equals] need to be implemented properly.
 * Inheriting of this class is an experimental feature.
 * Instantiate directly if inheritance not necessary.
 *
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.events.EventDefinition)
 *
 * @param T specifies what is a type of value passed to the event
 */
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@end


/**
 * Represents a phase in a pipeline
 *
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.pipeline.PipelinePhase)
 *
 * @param name a name for this phase
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsPipelinePhase")))
@interface OICCKtor_utilsPipelinePhase : OICCBase
- (instancetype)initWithName:(NSString *)name __attribute__((swift_name("init(name:)"))) __attribute__((objc_designated_initializer));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end

__attribute__((swift_name("KotlinSuspendFunction2")))
@protocol OICCKotlinSuspendFunction2 <OICCKotlinFunction>
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeP1:(id _Nullable)p1 p2:(id _Nullable)p2 completionHandler:(void (^)(id _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(p1:p2:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpReceivePipeline.Phases")))
@interface OICCKtor_client_coreHttpReceivePipelinePhases : OICCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)phases __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) OICCKtor_client_coreHttpReceivePipelinePhases *shared __attribute__((swift_name("shared")));

/**
 * Latest response pipeline phase
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.statement.HttpReceivePipeline.Phases.After)
 */
@property (readonly) OICCKtor_utilsPipelinePhase *After __attribute__((swift_name("After")));

/**
 * The earliest phase that happens before any other
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.statement.HttpReceivePipeline.Phases.Before)
 */
@property (readonly) OICCKtor_utilsPipelinePhase *Before __attribute__((swift_name("Before")));

/**
 * Use this phase to store request shared state
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.statement.HttpReceivePipeline.Phases.State)
 */
@property (readonly) OICCKtor_utilsPipelinePhase *State __attribute__((swift_name("State")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinUnit")))
@interface OICCKotlinUnit : OICCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)unit __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) OICCKotlinUnit *shared __attribute__((swift_name("shared")));
- (NSString *)description __attribute__((swift_name("description()")));
@end


/**
 * All interceptors accept payload as [subject] and try to convert it to [OutgoingContent].
 * Last phase should proceed with [HttpClientCall].
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpRequestPipeline.Phases)
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpRequestPipeline.Phases")))
@interface OICCKtor_client_coreHttpRequestPipelinePhases : OICCBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * All interceptors accept payload as [subject] and try to convert it to [OutgoingContent].
 * Last phase should proceed with [HttpClientCall].
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpRequestPipeline.Phases)
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)phases __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) OICCKtor_client_coreHttpRequestPipelinePhases *shared __attribute__((swift_name("shared")));

/**
 * The earliest phase that happens before any other.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpRequestPipeline.Phases.Before)
 */
@property (readonly) OICCKtor_utilsPipelinePhase *Before __attribute__((swift_name("Before")));

/**
 * Encode a request body to [OutgoingContent].
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpRequestPipeline.Phases.Render)
 */
@property (readonly) OICCKtor_utilsPipelinePhase *Render __attribute__((swift_name("Render")));

/**
 * A phase for the [HttpSend] plugin.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpRequestPipeline.Phases.Send)
 */
@property (readonly) OICCKtor_utilsPipelinePhase *Send __attribute__((swift_name("Send")));

/**
 * Use this phase to modify a request with a shared state.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpRequestPipeline.Phases.State)
 */
@property (readonly) OICCKtor_utilsPipelinePhase *State __attribute__((swift_name("State")));

/**
 * Transform a request body to supported render format.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpRequestPipeline.Phases.Transform)
 */
@property (readonly) OICCKtor_utilsPipelinePhase *Transform __attribute__((swift_name("Transform")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpResponsePipeline.Phases")))
@interface OICCKtor_client_coreHttpResponsePipelinePhases : OICCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)phases __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) OICCKtor_client_coreHttpResponsePipelinePhases *shared __attribute__((swift_name("shared")));

/**
 * Latest response pipeline phase
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.statement.HttpResponsePipeline.Phases.After)
 */
@property (readonly) OICCKtor_utilsPipelinePhase *After __attribute__((swift_name("After")));

/**
 * Decode response body
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.statement.HttpResponsePipeline.Phases.Parse)
 */
@property (readonly) OICCKtor_utilsPipelinePhase *Parse __attribute__((swift_name("Parse")));

/**
 * The earliest phase that happens before any other
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.statement.HttpResponsePipeline.Phases.Receive)
 */
@property (readonly) OICCKtor_utilsPipelinePhase *Receive __attribute__((swift_name("Receive")));

/**
 * Use this phase to store request shared state
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.statement.HttpResponsePipeline.Phases.State)
 */
@property (readonly) OICCKtor_utilsPipelinePhase *State __attribute__((swift_name("State")));

/**
 * Transform response body to expected format
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.statement.HttpResponsePipeline.Phases.Transform)
 */
@property (readonly) OICCKtor_utilsPipelinePhase *Transform __attribute__((swift_name("Transform")));
@end


/**
 * Class representing a typed [response] with an attached [expectedType].
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.statement.HttpResponseContainer)
 *
 * @param expectedType: information about expected type.
 * @param response: current response state.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpResponseContainer")))
@interface OICCKtor_client_coreHttpResponseContainer : OICCBase
- (instancetype)initWithExpectedType:(OICCKtor_utilsTypeInfo *)expectedType response:(id)response __attribute__((swift_name("init(expectedType:response:)"))) __attribute__((objc_designated_initializer));
- (OICCKtor_client_coreHttpResponseContainer *)doCopyExpectedType:(OICCKtor_utilsTypeInfo *)expectedType response:(id)response __attribute__((swift_name("doCopy(expectedType:response:)")));

/**
 * Class representing a typed [response] with an attached [expectedType].
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.statement.HttpResponseContainer)
 *
 * @param expectedType: information about expected type.
 * @param response: current response state.
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * Class representing a typed [response] with an attached [expectedType].
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.statement.HttpResponseContainer)
 *
 * @param expectedType: information about expected type.
 * @param response: current response state.
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * Class representing a typed [response] with an attached [expectedType].
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.statement.HttpResponseContainer)
 *
 * @param expectedType: information about expected type.
 * @param response: current response state.
 */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) OICCKtor_utilsTypeInfo *expectedType __attribute__((swift_name("expectedType")));
@property (readonly) id response __attribute__((swift_name("response")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpSendPipeline.Phases")))
@interface OICCKtor_client_coreHttpSendPipelinePhases : OICCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)phases __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) OICCKtor_client_coreHttpSendPipelinePhases *shared __attribute__((swift_name("shared")));

/**
 * The earliest phase that happens before any other.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpSendPipeline.Phases.Before)
 */
@property (readonly) OICCKtor_utilsPipelinePhase *Before __attribute__((swift_name("Before")));

/**
 * Send a request to a remote server.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpSendPipeline.Phases.Engine)
 */
@property (readonly) OICCKtor_utilsPipelinePhase *Engine __attribute__((swift_name("Engine")));

/**
 * Use this phase for logging and other actions that don't modify a request or shared data.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpSendPipeline.Phases.Monitoring)
 */
@property (readonly) OICCKtor_utilsPipelinePhase *Monitoring __attribute__((swift_name("Monitoring")));

/**
 * Receive a pipeline execution phase.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpSendPipeline.Phases.Receive)
 */
@property (readonly) OICCKtor_utilsPipelinePhase *Receive __attribute__((swift_name("Receive")));

/**
 * Use this phase to modify request with a shared state.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpSendPipeline.Phases.State)
 */
@property (readonly) OICCKtor_utilsPipelinePhase *State __attribute__((swift_name("State")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreCompositeEncoder")))
@protocol OICCKotlinx_serialization_coreCompositeEncoder
@required
- (void)encodeBooleanElementDescriptor:(id<OICCKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(BOOL)value __attribute__((swift_name("encodeBooleanElement(descriptor:index:value:)")));
- (void)encodeByteElementDescriptor:(id<OICCKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int8_t)value __attribute__((swift_name("encodeByteElement(descriptor:index:value:)")));
- (void)encodeCharElementDescriptor:(id<OICCKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(unichar)value __attribute__((swift_name("encodeCharElement(descriptor:index:value:)")));
- (void)encodeDoubleElementDescriptor:(id<OICCKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(double)value __attribute__((swift_name("encodeDoubleElement(descriptor:index:value:)")));
- (void)encodeFloatElementDescriptor:(id<OICCKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(float)value __attribute__((swift_name("encodeFloatElement(descriptor:index:value:)")));
- (id<OICCKotlinx_serialization_coreEncoder>)encodeInlineElementDescriptor:(id<OICCKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("encodeInlineElement(descriptor:index:)")));
- (void)encodeIntElementDescriptor:(id<OICCKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int32_t)value __attribute__((swift_name("encodeIntElement(descriptor:index:value:)")));
- (void)encodeLongElementDescriptor:(id<OICCKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int64_t)value __attribute__((swift_name("encodeLongElement(descriptor:index:value:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNullableSerializableElementDescriptor:(id<OICCKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index serializer:(id<OICCKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeNullableSerializableElement(descriptor:index:serializer:value:)")));
- (void)encodeSerializableElementDescriptor:(id<OICCKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index serializer:(id<OICCKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeSerializableElement(descriptor:index:serializer:value:)")));
- (void)encodeShortElementDescriptor:(id<OICCKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int16_t)value __attribute__((swift_name("encodeShortElement(descriptor:index:value:)")));
- (void)encodeStringElementDescriptor:(id<OICCKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(NSString *)value __attribute__((swift_name("encodeStringElement(descriptor:index:value:)")));
- (void)endStructureDescriptor:(id<OICCKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("endStructure(descriptor:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (BOOL)shouldEncodeElementDefaultDescriptor:(id<OICCKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("shouldEncodeElementDefault(descriptor:index:)")));
@property (readonly) OICCKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((swift_name("KotlinAnnotation")))
@protocol OICCKotlinAnnotation
@required
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerialKind")))
@interface OICCKotlinx_serialization_coreSerialKind : OICCBase
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreCompositeDecoder")))
@protocol OICCKotlinx_serialization_coreCompositeDecoder
@required
- (BOOL)decodeBooleanElementDescriptor:(id<OICCKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeBooleanElement(descriptor:index:)")));
- (int8_t)decodeByteElementDescriptor:(id<OICCKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeByteElement(descriptor:index:)")));
- (unichar)decodeCharElementDescriptor:(id<OICCKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeCharElement(descriptor:index:)")));
- (int32_t)decodeCollectionSizeDescriptor:(id<OICCKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("decodeCollectionSize(descriptor:)")));
- (double)decodeDoubleElementDescriptor:(id<OICCKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeDoubleElement(descriptor:index:)")));
- (int32_t)decodeElementIndexDescriptor:(id<OICCKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("decodeElementIndex(descriptor:)")));
- (float)decodeFloatElementDescriptor:(id<OICCKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeFloatElement(descriptor:index:)")));
- (id<OICCKotlinx_serialization_coreDecoder>)decodeInlineElementDescriptor:(id<OICCKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeInlineElement(descriptor:index:)")));
- (int32_t)decodeIntElementDescriptor:(id<OICCKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeIntElement(descriptor:index:)")));
- (int64_t)decodeLongElementDescriptor:(id<OICCKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeLongElement(descriptor:index:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id _Nullable)decodeNullableSerializableElementDescriptor:(id<OICCKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index deserializer:(id<OICCKotlinx_serialization_coreDeserializationStrategy>)deserializer previousValue:(id _Nullable)previousValue __attribute__((swift_name("decodeNullableSerializableElement(descriptor:index:deserializer:previousValue:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (BOOL)decodeSequentially __attribute__((swift_name("decodeSequentially()")));
- (id _Nullable)decodeSerializableElementDescriptor:(id<OICCKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index deserializer:(id<OICCKotlinx_serialization_coreDeserializationStrategy>)deserializer previousValue:(id _Nullable)previousValue __attribute__((swift_name("decodeSerializableElement(descriptor:index:deserializer:previousValue:)")));
- (int16_t)decodeShortElementDescriptor:(id<OICCKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeShortElement(descriptor:index:)")));
- (NSString *)decodeStringElementDescriptor:(id<OICCKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeStringElement(descriptor:index:)")));
- (void)endStructureDescriptor:(id<OICCKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("endStructure(descriptor:)")));
@property (readonly) OICCKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinNothing")))
@interface OICCKotlinNothing : OICCBase
@end

__attribute__((swift_name("Kotlinx_coroutines_coreMutex")))
@protocol OICCKotlinx_coroutines_coreMutex
@required
- (BOOL)holdsLockOwner:(id)owner __attribute__((swift_name("holdsLock(owner:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)lockOwner:(id _Nullable)owner completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("lock(owner:completionHandler:)")));
- (BOOL)tryLockOwner:(id _Nullable)owner __attribute__((swift_name("tryLock(owner:)")));
- (void)unlockOwner:(id _Nullable)owner __attribute__((swift_name("unlock(owner:)")));
@property (readonly) BOOL isLocked __attribute__((swift_name("isLocked")));
@property (readonly) id<OICCKotlinx_coroutines_coreSelectClause2> onLock __attribute__((swift_name("onLock"))) __attribute__((deprecated("Mutex.onLock deprecated without replacement. For additional details please refer to #2794")));
@end


/**
 * Represents a header value that consist of [content] followed by [parameters].
 * Useful for headers such as `Content-Type`, `Content-Disposition` and so on.
 *
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.HeaderValueWithParameters)
 *
 * @property content header's content without parameters
 * @property parameters
 */
__attribute__((swift_name("Ktor_httpHeaderValueWithParameters")))
@interface OICCKtor_httpHeaderValueWithParameters : OICCBase
- (instancetype)initWithContent:(NSString *)content parameters:(NSArray<OICCKtor_httpHeaderValueParam *> *)parameters __attribute__((swift_name("init(content:parameters:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) OICCKtor_httpHeaderValueWithParametersCompanion *companion __attribute__((swift_name("companion")));

/**
 * The first value for the parameter with [name] comparing case-insensitively or `null` if no such parameters found
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.HeaderValueWithParameters.parameter)
 */
- (NSString * _Nullable)parameterName:(NSString *)name __attribute__((swift_name("parameter(name:)")));
- (NSString *)description __attribute__((swift_name("description()")));

/**
 * @note This property has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
@property (readonly) NSString *content __attribute__((swift_name("content")));
@property (readonly) NSArray<OICCKtor_httpHeaderValueParam *> *parameters __attribute__((swift_name("parameters")));
@end


/**
 * Represents a value for a `Content-Type` header.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.ContentType)
 *
 * @property contentType represents a type part of the media type.
 * @property contentSubtype represents a subtype part of the media type.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpContentType")))
@interface OICCKtor_httpContentType : OICCKtor_httpHeaderValueWithParameters
- (instancetype)initWithContentType:(NSString *)contentType contentSubtype:(NSString *)contentSubtype parameters:(NSArray<OICCKtor_httpHeaderValueParam *> *)parameters __attribute__((swift_name("init(contentType:contentSubtype:parameters:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithContent:(NSString *)content parameters:(NSArray<OICCKtor_httpHeaderValueParam *> *)parameters __attribute__((swift_name("init(content:parameters:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) OICCKtor_httpContentTypeCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * Checks if `this` type matches a [pattern] type taking into account placeholder symbols `*` and parameters.
 * The `this` type must be a more specific type than the [pattern] type. In other words:
 *
 * ```kotlin
 * ContentType("a", "b").match(ContentType("a", "b").withParameter("foo", "bar")) === false
 * ContentType("a", "b").withParameter("foo", "bar").match(ContentType("a", "b")) === true
 * ContentType("a", "*").match(ContentType("a", "b")) === false
 * ContentType("a", "b").match(ContentType("a", "*")) === true
 * ```
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.ContentType.match)
 */
- (BOOL)matchPattern:(OICCKtor_httpContentType *)pattern __attribute__((swift_name("match(pattern:)")));

/**
 * Checks if `this` type matches a [pattern] type taking into account placeholder symbols `*` and parameters.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.ContentType.match)
 */
- (BOOL)matchPattern_:(NSString *)pattern __attribute__((swift_name("match(pattern_:)")));

/**
 * Creates a copy of `this` type with the added parameter with the [name] and [value].
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.ContentType.withParameter)
 */
- (OICCKtor_httpContentType *)withParameterName:(NSString *)name value:(NSString *)value __attribute__((swift_name("withParameter(name:value:)")));

/**
 * Creates a copy of `this` type without any parameters
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.ContentType.withoutParameters)
 */
- (OICCKtor_httpContentType *)withoutParameters __attribute__((swift_name("withoutParameters()")));
@property (readonly) NSString *contentSubtype __attribute__((swift_name("contentSubtype")));
@property (readonly) NSString *contentType __attribute__((swift_name("contentType")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.1")
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinKTypeProjection")))
@interface OICCKotlinKTypeProjection : OICCBase
- (instancetype)initWithVariance:(OICCKotlinKVariance * _Nullable)variance type:(id<OICCKotlinKType> _Nullable)type __attribute__((swift_name("init(variance:type:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) OICCKotlinKTypeProjectionCompanion *companion __attribute__((swift_name("companion")));
- (OICCKotlinKTypeProjection *)doCopyVariance:(OICCKotlinKVariance * _Nullable)variance type:(id<OICCKotlinKType> _Nullable)type __attribute__((swift_name("doCopy(variance:type:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id<OICCKotlinKType> _Nullable type __attribute__((swift_name("type")));
@property (readonly) OICCKotlinKVariance * _Nullable variance __attribute__((swift_name("variance")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinByteArray")))
@interface OICCKotlinByteArray : OICCBase
+ (instancetype)arrayWithSize:(int32_t)size __attribute__((swift_name("init(size:)")));
+ (instancetype)arrayWithSize:(int32_t)size init:(OICCByte *(^)(OICCInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (int8_t)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (OICCKotlinByteIterator *)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(int8_t)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end

__attribute__((swift_name("Kotlinx_io_coreRawSink")))
@protocol OICCKotlinx_io_coreRawSink <OICCKotlinAutoCloseable>
@required
- (void)flush __attribute__((swift_name("flush()")));
- (void)writeSource:(OICCKotlinx_io_coreBuffer *)source byteCount:(int64_t)byteCount __attribute__((swift_name("write(source:byteCount:)")));
@end

__attribute__((swift_name("Kotlinx_io_coreSink")))
@protocol OICCKotlinx_io_coreSink <OICCKotlinx_io_coreRawSink>
@required
- (void)emit __attribute__((swift_name("emit()")));

/**
 * @note annotations
 *   kotlinx.io.InternalIoApi
*/
- (void)hintEmit __attribute__((swift_name("hintEmit()")));
- (int64_t)transferFromSource:(id<OICCKotlinx_io_coreRawSource>)source __attribute__((swift_name("transferFrom(source:)")));
- (void)writeSource:(id<OICCKotlinx_io_coreRawSource>)source byteCount_:(int64_t)byteCount __attribute__((swift_name("write(source:byteCount_:)")));
- (void)writeSource:(OICCKotlinByteArray *)source startIndex:(int32_t)startIndex endIndex:(int32_t)endIndex __attribute__((swift_name("write(source:startIndex:endIndex:)")));
- (void)writeByteByte:(int8_t)byte __attribute__((swift_name("writeByte(byte:)")));
- (void)writeIntInt:(int32_t)int_ __attribute__((swift_name("writeInt(int:)")));
- (void)writeLongLong:(int64_t)long_ __attribute__((swift_name("writeLong(long:)")));
- (void)writeShortShort:(int16_t)short_ __attribute__((swift_name("writeShort(short:)")));

/**
 * @note annotations
 *   kotlinx.io.InternalIoApi
*/
@property (readonly) OICCKotlinx_io_coreBuffer *buffer __attribute__((swift_name("buffer")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_io_coreBuffer")))
@interface OICCKotlinx_io_coreBuffer : OICCBase <OICCKotlinx_io_coreSource, OICCKotlinx_io_coreSink>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)clear __attribute__((swift_name("clear()")));
- (void)close __attribute__((swift_name("close()")));
- (OICCKotlinx_io_coreBuffer *)doCopy __attribute__((swift_name("doCopy()")));
- (void)doCopyToOut:(OICCKotlinx_io_coreBuffer *)out startIndex:(int64_t)startIndex endIndex:(int64_t)endIndex __attribute__((swift_name("doCopyTo(out:startIndex:endIndex:)")));
- (void)emit __attribute__((swift_name("emit()")));
- (BOOL)exhausted __attribute__((swift_name("exhausted()")));
- (void)flush __attribute__((swift_name("flush()")));
- (int8_t)getPosition:(int64_t)position __attribute__((swift_name("get(position:)")));

/**
 * @note annotations
 *   kotlinx.io.InternalIoApi
*/
- (void)hintEmit __attribute__((swift_name("hintEmit()")));
- (id<OICCKotlinx_io_coreSource>)peek __attribute__((swift_name("peek()")));
- (int64_t)readAtMostToSink:(OICCKotlinx_io_coreBuffer *)sink byteCount:(int64_t)byteCount __attribute__((swift_name("readAtMostTo(sink:byteCount:)")));
- (int32_t)readAtMostToSink:(OICCKotlinByteArray *)sink startIndex:(int32_t)startIndex endIndex:(int32_t)endIndex __attribute__((swift_name("readAtMostTo(sink:startIndex:endIndex:)")));
- (int8_t)readByte __attribute__((swift_name("readByte()")));
- (int32_t)readInt __attribute__((swift_name("readInt()")));
- (int64_t)readLong __attribute__((swift_name("readLong()")));
- (int16_t)readShort __attribute__((swift_name("readShort()")));
- (void)readToSink:(id<OICCKotlinx_io_coreRawSink>)sink byteCount:(int64_t)byteCount __attribute__((swift_name("readTo(sink:byteCount:)")));
- (BOOL)requestByteCount:(int64_t)byteCount __attribute__((swift_name("request(byteCount:)")));
- (void)requireByteCount:(int64_t)byteCount __attribute__((swift_name("require(byteCount:)")));
- (void)skipByteCount:(int64_t)byteCount __attribute__((swift_name("skip(byteCount:)")));
- (NSString *)description __attribute__((swift_name("description()")));
- (int64_t)transferFromSource:(id<OICCKotlinx_io_coreRawSource>)source __attribute__((swift_name("transferFrom(source:)")));
- (int64_t)transferToSink:(id<OICCKotlinx_io_coreRawSink>)sink __attribute__((swift_name("transferTo(sink:)")));
- (void)writeSource:(OICCKotlinx_io_coreBuffer *)source byteCount:(int64_t)byteCount __attribute__((swift_name("write(source:byteCount:)")));
- (void)writeSource:(id<OICCKotlinx_io_coreRawSource>)source byteCount_:(int64_t)byteCount __attribute__((swift_name("write(source:byteCount_:)")));
- (void)writeSource:(OICCKotlinByteArray *)source startIndex:(int32_t)startIndex endIndex:(int32_t)endIndex __attribute__((swift_name("write(source:startIndex:endIndex:)")));
- (void)writeByteByte:(int8_t)byte __attribute__((swift_name("writeByte(byte:)")));
- (void)writeIntInt:(int32_t)int_ __attribute__((swift_name("writeInt(int:)")));
- (void)writeLongLong:(int64_t)long_ __attribute__((swift_name("writeLong(long:)")));
- (void)writeShortShort:(int16_t)short_ __attribute__((swift_name("writeShort(short:)")));

/**
 * @note annotations
 *   kotlinx.io.InternalIoApi
*/
@property (readonly) OICCKotlinx_io_coreBuffer *buffer __attribute__((swift_name("buffer")));
@property (readonly) int64_t size __attribute__((swift_name("size")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsWeekDay.Companion")))
@interface OICCKtor_utilsWeekDayCompanion : OICCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) OICCKtor_utilsWeekDayCompanion *shared __attribute__((swift_name("shared")));

/**
 * Lookup an instance by [ordinal]
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.date.WeekDay.Companion.from)
 */
- (OICCKtor_utilsWeekDay *)fromOrdinal:(int32_t)ordinal __attribute__((swift_name("from(ordinal:)")));

/**
 * Lookup an instance by short week day name [WeekDay.value]
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.date.WeekDay.Companion.from)
 */
- (OICCKtor_utilsWeekDay *)fromValue:(NSString *)value __attribute__((swift_name("from(value:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsMonth.Companion")))
@interface OICCKtor_utilsMonthCompanion : OICCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) OICCKtor_utilsMonthCompanion *shared __attribute__((swift_name("shared")));

/**
 * Lookup an instance by [ordinal]
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.date.Month.Companion.from)
 */
- (OICCKtor_utilsMonth *)fromOrdinal:(int32_t)ordinal __attribute__((swift_name("from(ordinal:)")));

/**
 * Lookup an instance by short month name [Month.value]
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.date.Month.Companion.from)
 */
- (OICCKtor_utilsMonth *)fromValue:(NSString *)value __attribute__((swift_name("from(value:)")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.3")
 *   kotlin.ExperimentalStdlibApi
*/
__attribute__((swift_name("KotlinAbstractCoroutineContextKey")))
@interface OICCKotlinAbstractCoroutineContextKey<B, E> : OICCBase <OICCKotlinCoroutineContextKey>
- (instancetype)initWithBaseKey:(id<OICCKotlinCoroutineContextKey>)baseKey safeCast:(E _Nullable (^)(id<OICCKotlinCoroutineContextElement> element))safeCast __attribute__((swift_name("init(baseKey:safeCast:)"))) __attribute__((objc_designated_initializer));
@end


/**
 * @note annotations
 *   kotlin.ExperimentalStdlibApi
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_coroutines_coreCoroutineDispatcher.Key")))
@interface OICCKotlinx_coroutines_coreCoroutineDispatcherKey : OICCKotlinAbstractCoroutineContextKey<id<OICCKotlinContinuationInterceptor>, OICCKotlinx_coroutines_coreCoroutineDispatcher *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithBaseKey:(id<OICCKotlinCoroutineContextKey>)baseKey safeCast:(id<OICCKotlinCoroutineContextElement> _Nullable (^)(id<OICCKotlinCoroutineContextElement> element))safeCast __attribute__((swift_name("init(baseKey:safeCast:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)key __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) OICCKotlinx_coroutines_coreCoroutineDispatcherKey *shared __attribute__((swift_name("shared")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreRunnable")))
@protocol OICCKotlinx_coroutines_coreRunnable
@required
- (void)run __attribute__((swift_name("run()")));
@end


/**
 * @note annotations
 *   kotlinx.coroutines.InternalCoroutinesApi
*/
__attribute__((swift_name("Kotlinx_coroutines_coreParentJob")))
@protocol OICCKotlinx_coroutines_coreParentJob <OICCKotlinx_coroutines_coreJob>
@required

/**
 * @note annotations
 *   kotlinx.coroutines.InternalCoroutinesApi
*/
- (OICCKotlinCancellationException *)getChildJobCancellationCause __attribute__((swift_name("getChildJobCancellationCause()")));
@end


/**
 * @note annotations
 *   kotlinx.coroutines.InternalCoroutinesApi
*/
__attribute__((swift_name("Kotlinx_coroutines_coreSelectInstance")))
@protocol OICCKotlinx_coroutines_coreSelectInstance
@required
- (void)disposeOnCompletionDisposableHandle:(id<OICCKotlinx_coroutines_coreDisposableHandle>)disposableHandle __attribute__((swift_name("disposeOnCompletion(disposableHandle:)")));
- (void)selectInRegistrationPhaseInternalResult:(id _Nullable)internalResult __attribute__((swift_name("selectInRegistrationPhase(internalResult:)")));
- (BOOL)trySelectClauseObject:(id)clauseObject result:(id _Nullable)result __attribute__((swift_name("trySelect(clauseObject:result:)")));
@property (readonly) id<OICCKotlinCoroutineContext> context __attribute__((swift_name("context")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreSelectClause2")))
@protocol OICCKotlinx_coroutines_coreSelectClause2 <OICCKotlinx_coroutines_coreSelectClause>
@required
@end


/**
 * Represents a single value parameter
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.HeaderValueParam)
 *
 * @property name of parameter
 * @property value of parameter
 * @property escapeValue specifies if the value should be escaped
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHeaderValueParam")))
@interface OICCKtor_httpHeaderValueParam : OICCBase
- (instancetype)initWithName:(NSString *)name value:(NSString *)value __attribute__((swift_name("init(name:value:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithName:(NSString *)name value:(NSString *)value escapeValue:(BOOL)escapeValue __attribute__((swift_name("init(name:value:escapeValue:)"))) __attribute__((objc_designated_initializer));
- (OICCKtor_httpHeaderValueParam *)doCopyName:(NSString *)name value:(NSString *)value escapeValue:(BOOL)escapeValue __attribute__((swift_name("doCopy(name:value:escapeValue:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * Represents a single value parameter
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.HeaderValueParam)
 *
 * @property name of parameter
 * @property value of parameter
 * @property escapeValue specifies if the value should be escaped
 */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL escapeValue __attribute__((swift_name("escapeValue")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHeaderValueWithParameters.Companion")))
@interface OICCKtor_httpHeaderValueWithParametersCompanion : OICCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) OICCKtor_httpHeaderValueWithParametersCompanion *shared __attribute__((swift_name("shared")));

/**
 * Parse header with parameter and pass it to [init] function to instantiate particular type
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.HeaderValueWithParameters.Companion.parse)
 */
- (id _Nullable)parseValue:(NSString *)value init:(id _Nullable (^)(NSString *, NSArray<OICCKtor_httpHeaderValueParam *> *))init __attribute__((swift_name("parse(value:init:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpContentType.Companion")))
@interface OICCKtor_httpContentTypeCompanion : OICCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) OICCKtor_httpContentTypeCompanion *shared __attribute__((swift_name("shared")));

/**
 * Parses a string representing a `Content-Type` header into a [ContentType] instance.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.ContentType.Companion.parse)
 */
- (OICCKtor_httpContentType *)parseValue:(NSString *)value __attribute__((swift_name("parse(value:)")));

/**
 * Represents a pattern `* / *` to match any content type.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.ContentType.Companion.Any)
 */
@property (readonly) OICCKtor_httpContentType *Any __attribute__((swift_name("Any")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.1")
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinKVariance")))
@interface OICCKotlinKVariance : OICCKotlinEnum<OICCKotlinKVariance *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) OICCKotlinKVariance *invariant __attribute__((swift_name("invariant")));
@property (class, readonly) OICCKotlinKVariance *in __attribute__((swift_name("in")));
@property (class, readonly) OICCKotlinKVariance *out __attribute__((swift_name("out")));
+ (OICCKotlinArray<OICCKotlinKVariance *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<OICCKotlinKVariance *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinKTypeProjection.Companion")))
@interface OICCKotlinKTypeProjectionCompanion : OICCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) OICCKotlinKTypeProjectionCompanion *shared __attribute__((swift_name("shared")));
- (OICCKotlinKTypeProjection *)contravariantType:(id<OICCKotlinKType>)type __attribute__((swift_name("contravariant(type:)")));
- (OICCKotlinKTypeProjection *)covariantType:(id<OICCKotlinKType>)type __attribute__((swift_name("covariant(type:)")));
- (OICCKotlinKTypeProjection *)invariantType:(id<OICCKotlinKType>)type __attribute__((swift_name("invariant(type:)")));
@property (readonly) OICCKotlinKTypeProjection *STAR __attribute__((swift_name("STAR")));
@end

__attribute__((swift_name("KotlinByteIterator")))
@interface OICCKotlinByteIterator : OICCBase <OICCKotlinIterator>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (OICCByte *)next __attribute__((swift_name("next()")));
- (int8_t)nextByte __attribute__((swift_name("nextByte()")));
@end

#pragma pop_macro("_Nullable_result")
#pragma clang diagnostic pop
NS_ASSUME_NONNULL_END
